<?php
/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
wc_print_notices();

do_action( 'woocommerce_before_cart' ); ?>
<form id="ly_rest_cart_form" action="" method="post">
<?php do_action( 'woocommerce_before_cart_table' );
	do_action( 'woocommerce_before_cart_contents' );
	$cop_vals = array();
	$cop_auths = array();
	$por_authos = array();
	foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
		$_product	= wc_get_product( $cart_item['product_id'] );
		$product_id	= apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
	
		if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key )) {
			$auth = get_post_field('post_author', $product_id);
			$por_authos[$auth][] = $product_id;
		}
	}

	foreach ( WC()->cart->get_applied_coupons() as $code ) {
		$coupon = new WC_Coupon( $code );
		$cop_vals[$coupon->id] = get_post_field('post_author', $coupon->id);
		$cop_auths[get_post_field('post_author', $coupon->id)] = $coupon->id;
	}

	foreach ($por_authos as $por_autho => $pid) {
		$seller_info = frozr_get_store_info($por_autho);
		$pre_order = frozr_is_rest_open($por_autho) == false ? ' <span class="frozr_pre_order_label">'.__('Pre-order','frozrdash').'</span>' : '';
		$div_total = array();
	?>
	<div class="row ly_section single_rest_order">
	<div class="sec-content"><a class="cart_view_rest" data-id="<?php echo $por_autho; ?>" href="<?php echo frozr_get_store_url( $por_autho ); ?>"><span class="sec-title"><i class="material-icons">store</i><span><?php echo $seller_info['store_name'] . $pre_order; ?></span></span></a></div>
	<div class="products-details">
		<ul class="rest_cart_items_list">
		<?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
		$_product	= apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
		$product_id	= apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
		$pauth		= get_post_field('post_author', $product_id);
		if ($pauth == $por_autho) {
			$cop_val = get_post_field('post_author', $product_id);
			$auth_cop_cal = (! empty ($cop_auths[$cop_val]) ) ? $cop_auths[$cop_val]: '';
			$delv_val = get_post_meta($auth_cop_cal, 'free_shipping', true);

			if ( empty ($cop_vals[$auth_cop_cal]) || $cop_vals[$auth_cop_cal] != $cop_val || $delv_val != 'yes' || frozr_delivery_settings($pauth, 'shipping_fee',true) != 0) {
				if ($seller_info['deliveryby'] == 'item' && $cart_item['order_l_type'] == 'delivery') {
					$div_total[] = $cart_item['quantity'];					
				} elseif ($seller_info['deliveryby'] != 'item' && $cart_item['order_l_type'] == 'delivery') {
					$div_total[0] = 'bycart';
				}
			} else {
				$div_total[0] = 'free';
			}
			?>
			<li class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
			<div class="product-name"><?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
				// Meta data
				echo wc_get_formatted_cart_item_data( $cart_item );
				// Backorder notification
				if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
					echo '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'frozrdash' ) . '</p>';
				} ?>
			</div>
			<div class="product-quantity">
				<?php
				echo '<div class="frozr_cart_qty">';
				if ( $_product->is_sold_individually() ) {
					$product_quantity = sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key );
				} else {
					$product_quantity = woocommerce_quantity_input( array(
						'input_name'  => "cart[{$cart_item_key}][qty]",
						'input_value' => $cart_item['quantity'],
						'max_value'   => $_product->backorders_allowed() ? '' : $_product->get_stock_quantity(),
						'min_value'   => '0'
					), $_product, false );
				}
				
				echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item );
				echo '<div class="frozr_cart_update"><input type="submit" class="frozr_minicart_item_update" name="update_cart" value="'.__('Update','frozrdash').'"/></div>';
				echo '</div>';
				?>
				<div class="product-subtotal"><?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?></div>
				<div class="product-remove">
					<?php echo apply_filters( 'woocommerce_cart_item_remove_link', sprintf(
						'<a href="%s" title="%s" class="remove" aria-label="%s" data-product_id="%s" data-product_sku="%s"><i class="material-icons">close</i></a>',
						esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
						__( 'Remove this item', 'frozrdash' ),
						__( 'Remove this item', 'frozrdash' ),
						esc_attr( $product_id ),
						esc_attr( $_product->get_sku() )
					), $cart_item_key ); ?>
				</div>
			</div>
			</li>
	<?php } } ?>
		</ul>
	</div>
	<div class="shipping-subtotal">
	<div class="frozr_order_sub_wrapper">
		<div class="sec_title"><?php _e('Total delivery fee','frozrdash'); ?></div>
		<div class="sec_details"><?php $total_div = array_sum($div_total);
		$default_shipping = frozr_delivery_settings($por_autho, 'shipping_fee');
		$default_adl_shipping = frozr_delivery_settings($por_autho, 'shipping_pro_adtl_cost');
		if (isset($div_total[0]) && $div_total[0] == 'free') {
			echo __('Free Delivery','frozrdash');
		} elseif (isset($div_total[0]) && $div_total[0] == 'bycart' || $total_div == 1) {
			echo wc_price( $default_shipping );
		} elseif ( $total_div == 0) {
			echo __('N/A','frozrdash');
		} elseif ($total_div > 1) {
			$_adl_fees_add = ($total_div - 1) * $default_adl_shipping;
			echo wc_price( $default_shipping + $_adl_fees_add );
		} ?></div>
	</div>
	</div>
	</div>
	<?php
	}
	do_action( 'woocommerce_cart_contents' );
	if ( wc_coupons_enabled() ) { ?>
	<div class="row ly_section coupon">
		<div class="sec-content">
			<span class="sec-title"><i class="material-icons">redeem</i><span><?php _e( 'Coupon', 'frozrdash' ); ?></span></span>
		</div>
		<div class="sec-action">
			<input type="text" name="coupon_code" class="cart_coupon_input" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'frozrdash' ); ?>" />
			<input type="submit" class="btn waves-effect waves-light apply_coupon_code" name="apply_coupon" value="<?php esc_attr_e( 'Apply Coupon', 'frozrdash' ); ?>" />
		</div>
		<?php do_action( 'woocommerce_cart_coupon' ); ?>
	</div>
	<?php }
	do_action( 'woocommerce_cart_actions' );
	do_action( 'woocommerce_after_cart_contents' );
	do_action( 'woocommerce_after_cart_table' );
	wp_nonce_field( 'woocommerce-cart' ); ?>
</form>
<div class="cart-collaterals">
<?php do_action( 'woocommerce_cart_collaterals' ); ?>
</div>
<?php do_action( 'woocommerce_after_cart' );