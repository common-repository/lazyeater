<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
* woocommerce_before_single_product hook.
*
* @hooked wc_print_notices - 10
*/
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
echo get_the_password_form();
return;
}
global $product;
$product_author= get_post_field( 'post_author', $post->ID );
$post_thumbnail_id = $product->get_image_id();
$attachment_ids = $product->get_gallery_image_ids();
?>
<div class="frozr_product_top_info">
	<div class="frozr_product_sharing"><?php woocommerce_template_single_sharing(); ?></div>
	<div class="single_add_to_cart"><a href="#0" class="frozr_item_add_to_cart" data-id="<?php the_ID(); ?>"><i class="material-icons">add</i><?php echo __('Add to cart','frozrdash'); ?></a></div>
</div>
<?php frozr_seller_disabled_notice($product_author);
if ( $attachment_ids || has_post_thumbnail() ) { ?>
<div class="frozr_product_image_wrapper"><?php
if ( has_post_thumbnail() ) {
	$main_img = wp_get_attachment_image_src( $post_thumbnail_id, 'full' );
	$link = $main_img[0];
} else {
	$link = esc_url( wc_placeholder_img_src() );
}
echo '<div class="frozr_product_image_full" style="background-image:url('.$link.');"></div>';
if ( $attachment_ids && has_post_thumbnail() ) {
	$attachment_ids[] = $post_thumbnail_id;
	echo '<div class="frozr_product_gallery_single_image_wrapper">';
	foreach ( $attachment_ids as $attachment_id ) {
		$full_src          = wp_get_attachment_image_src( $attachment_id, 'full' );
		$image             = wp_get_attachment_image( $attachment_id, 'thumbnail', false, array(
			'title'                   => get_post_field( 'post_title', $attachment_id ),
			'data-caption'            => get_post_field( 'post_excerpt', $attachment_id ),
			'data-src'                => $full_src[0],
			'data-large_image'        => $full_src[0],
			'data-large_image_width'  => $full_src[1],
			'data-large_image_height' => $full_src[2],
			'class'                   => 'frozr_product_single_image',
		));
		echo $image;
	}
	echo '</div>';
}
?>
</div>
<?php } ?>
<div class="single-page-content">
<div class="frozr_single_product_summary">
	<div class="frozr_single_excerpt">
	<?php woocommerce_template_single_excerpt(); ?>
	</div>
	<?php woocommerce_template_single_meta(); ?>
	<div class="frozr_single_price">
	<?php woocommerce_template_single_price();
	woocommerce_template_single_rating(); ?>
	</div>
</div>
</div>
<div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
	/**
	 * woocommerce_after_single_product_summary hook.
	 *
	 * @hooked woocommerce_output_product_data_tabs - 10
	 * @hooked woocommerce_upsell_display - 15
	 * @hooked woocommerce_output_related_products - 20
	 */
	do_action( 'woocommerce_after_single_product_summary' );
	?>
</div>
<?php do_action( 'woocommerce_after_single_product' );