<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
get_header( 'shop' );
$order_types = frozr_default_accepted_orders_types();
$discts = get_terms( 'product_cat', 'fields=names&hide_empty=0' );
$ingres = get_terms( 'ingredient', 'fields=names&hide_empty=0' ); ?>
<div data-role="page" id="shop<?php echo mt_rand(); ?>" data-id="shop" class="content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php woocommerce_page_title(); ?></div>
<?php frozr_fixed_cart(true); ?>
<?php frozr_general_search_result(); ?>
<?php frozr_user_favs(); ?>
<main class="site-main" role="main">
<?php if ( have_posts() ) {
wc_print_notices();
woocommerce_catalog_ordering();
woocommerce_product_loop_start();
if ( wc_get_loop_prop( 'total' ) ) {
	while ( have_posts() ) {
		the_post();
		/**
		 * Hook: woocommerce_shop_loop.
		 *
		 * @hooked WC_Structured_Data::generate_product_data() - 10
		 */
		do_action( 'woocommerce_shop_loop' );
		wc_get_template_part( 'content', 'product' );
	}
}
woocommerce_product_loop_end();
/**
 * Hook: woocommerce_after_shop_loop.
 *
 * @hooked woocommerce_pagination - 10
 */
do_action( 'woocommerce_after_shop_loop' );
} else {
/**
 * Hook: woocommerce_no_products_found.
 *
 * @hooked wc_no_products_found - 10
 */
do_action( 'woocommerce_no_products_found' );
}
?>
</main>
</div>
<?php get_footer( 'shop' );