<?php
/**
 * Review order table
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/review-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$cop_vals = array();
$cop_auths = array();
$por_authos = array();
foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
	$_product	= wc_get_product( $cart_item['product_id'] );
	$product_id	= apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

	if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key )) {
		$auth = get_post_field('post_author', $product_id);
		$por_authos[$auth][] = $product_id;
	}
}

foreach ( WC()->cart->get_applied_coupons() as $code ) {
	$coupon = new WC_Coupon( $code );
	$cop_vals[$coupon->id] = get_post_field('post_author', $coupon->id);
	$cop_auths[get_post_field('post_author', $coupon->id)] = $coupon->id;
}

foreach ($por_authos as $por_autho => $pid) {
	$seller_info = frozr_get_store_info($por_autho);
	$pre_order = frozr_is_rest_open($por_autho) == false ? ' <span class="frozr_pre_order_label">'.__('Pre-order','frozrdash').'</span>' : '';
	$div_total = array();
?>
<div class="row ly_section single_rest_order">
<div class="sec-content"><a class="cart_view_rest" data-id="<?php echo $por_autho; ?>" href="<?php echo frozr_get_store_url( $por_autho ); ?>"><span class="sec-title"><i class="material-icons">store</i><span><?php echo $seller_info['store_name'] . $pre_order; ?></span></span></a></div>
<div class="products-details">
	<ul class="rest_cart_items_list">
	<?php $total_pre = array(); foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
	$_product	= apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
	$product_id	= apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
	$pauth		= get_post_field('post_author', $product_id);
	if ($pauth == $por_autho) {
		$item_id = $product_id;
		$cop_val = get_post_field('post_author', $product_id);
		$auth_cop_cal = (! empty ($cop_auths[$cop_val]) ) ? $cop_auths[$cop_val]: '';
		$delv_val = get_post_meta($auth_cop_cal, 'free_shipping', true);
		$pretime = norsani()->item->frozr_get_product_preparation_time($product_id,false);
		if ($pretime > 0) {
			$total_pre[] = $pretime;
		}
		if ( empty ($cop_vals[$auth_cop_cal]) || $cop_vals[$auth_cop_cal] != $cop_val || $delv_val != 'yes' || frozr_delivery_settings($pauth, 'shipping_fee',true) != 0) {
			if ($seller_info['deliveryby'] == 'item' && $cart_item['order_l_type'] == 'delivery') {
				$div_total[] = $cart_item['quantity'];					
			} elseif ($seller_info['deliveryby'] != 'item' && $cart_item['order_l_type'] == 'delivery') {
				$div_total[0] = 'bycart';
			}
		} else {
			$div_total[0] = 'free';
		}
		?>
		<li class="frozr_product_name">
		<div class="product-name">
			<?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;'; ?>
			<?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <strong class="product-quantity">' . sprintf( '&times; %s', $cart_item['quantity'] ) . '</strong>', $cart_item, $cart_item_key ); ?>
			<?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>
		</div>
		<div class="frozr_product_total">
			<?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?>
		</div>
		</li>
<?php } } ?>
	</ul>
</div>
<div class="shipping-subtotal">
	<?php
	$default_shipping = frozr_delivery_settings($por_autho, 'shipping_fee');
	$default_adl_shipping = frozr_delivery_settings($por_autho, 'shipping_pro_adtl_cost');
	$total_div = array_sum($div_total); ?>
	<div class="frozr_order_sub_wrapper">
	<div class="sec_title"><?php _e('Total delivery fee','frozrdash'); ?></div>
	<div class="sec_details"><?php
	if (isset($div_total[0]) && $div_total[0] == 'free') {
		echo __('Free Delivery','frozrdash');
	} elseif (isset($div_total[0]) && $div_total[0] == 'bycart' || $total_div == 1) {
		echo wc_price( $default_shipping ).' (~'.frozr_get_distance($por_autho,null,true).')';
	} elseif ($total_div == 0) {
		echo __('N/A','frozrdash');
	} elseif ($total_div > 1) {
		$_adl_fees_add = ($total_div - 1) * $default_adl_shipping;
		echo wc_price( $default_shipping + $_adl_fees_add ).' (~'.frozr_get_distance($por_autho,null,true).')';
	} ?></div>
	</div>
	<div class="frozr_order_sub_wrapper">
	<div class="sec_title"><?php _e('Estimate preparation time','frozrdash'); ?></div>
	<div class="sec_details"><?php
	$total_time = norsani()->order->frozr_cal_total_pretime($total_pre,$por_autho);
	if ($total_time) {
		echo $total_time .' '. __('Minutes','frozrdash');
	} else {
		$total_time = 0;
		echo __('Immediately','frozrdash');
	} ?><input type="hidden" value="<?php echo $total_time; ?>" name="frozr_ord_pre_duration_<?php echo $por_autho; ?>"/></div>
	</div>
	<div class="frozr_order_sub_wrapper">
	<div class="sec_title"><?php _e('Process at','frozrdash'); ?></div>
	<div class="sec_details">
	<?php frozr_get_order_pretime_options($por_autho,$item_id); ?>
	</div>
	</div>
</div>
</div>
<?php } ?>
<table class="frozr_checkout_order_total">
	<tbody>
	<tr class="cart-subtotal">
		<th><?php _e( 'Subtotal', 'frozrdash' ); ?></th>
		<td><?php wc_cart_totals_subtotal_html(); ?></td>
	</tr>

	<?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
		<tr class="cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
			<th><?php wc_cart_totals_coupon_label( $coupon ); ?></th>
			<td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
		</tr>
	<?php endforeach; ?>

	<?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>

		<?php do_action( 'woocommerce_review_order_before_shipping' ); ?>

		<?php wc_cart_totals_shipping_html(); ?>

		<?php do_action( 'woocommerce_review_order_after_shipping' ); ?>

	<?php endif; ?>

	<?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
		<tr class="fee">
			<th><?php echo esc_html( $fee->name ); ?></th>
			<td><?php wc_cart_totals_fee_html( $fee ); ?></td>
		</tr>
	<?php endforeach; ?>

	<?php if ( wc_tax_enabled() && ! WC()->cart->display_prices_including_tax() ) : ?>
		<?php if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) : ?>
			<?php foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>
				<tr class="tax-rate tax-rate-<?php echo sanitize_title( $code ); ?>">
					<th><?php echo esc_html( $tax->label ); ?></th>
					<td><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
				</tr>
			<?php endforeach; ?>
		<?php else : ?>
			<tr class="tax-total">
				<th><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></th>
				<td><?php wc_cart_totals_taxes_total_html(); ?></td>
			</tr>
		<?php endif; ?>
	<?php endif; ?>

	<?php do_action( 'woocommerce_review_order_before_order_total' ); ?>

	<tr class="order-total">
		<th><?php _e( 'Total', 'frozrdash' ); ?></th>
		<td><?php wc_cart_totals_order_total_html(); ?></td>
	</tr>

	<?php do_action( 'woocommerce_review_order_after_order_total' ); ?>

	</tbody>
</table>