<?php
/**
 * My Account navigation
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/navigation.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_account_navigation' );
$current_user = get_user_by( 'id', get_current_user_id() );

?>
<p><?php
	/* translators: 1: user display name 2: logout url */
	printf(
		__( 'Hello %1$s', 'frozrdash'),
		'<strong>' . esc_html( $current_user->display_name ) . '</strong>'
	);
?></p>
<nav class="woocommerce-MyAccount-navigation">
	<ul>
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<li class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?>">
				<i class="material-icons"><?php if ($endpoint == 'ly-store'){echo 'store';} elseif ($endpoint == 'ly-dashboard'){echo 'home';} elseif($endpoint == 'vendor_orders') {echo 'receipt';} elseif($endpoint == 'orders') {echo 'shopping_cart';} elseif($endpoint == 'downloads') {echo 'file_download';} elseif($endpoint == 'edit-account'){echo 'account_box';} elseif($endpoint == 'customer-logout') {echo 'lock_outline';} ?></i>
				<a <?php if ($endpoint == 'customer-logout') {echo 'data-ajax="false"';} ?> href="<?php if ($endpoint == 'ly-store') {echo frozr_get_store_url(get_current_user_id());} elseif ($endpoint == 'customer-logout') {echo wp_logout_url( home_url() );} elseif ($endpoint == 'vendor_orders'){echo home_url() . '/dashboard/orders/'; } elseif ($endpoint == 'ly-dashboard'){echo home_url() . '/dashboard/home/'; } else {echo esc_url( wc_get_account_endpoint_url( $endpoint ) );} ?>"><?php echo esc_html( $label ); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>

<?php do_action( 'woocommerce_after_account_navigation' );