<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header( 'shop' );
$product_author= get_post_field( 'post_author', $post->ID );
frozr_redirect_if_disabled_seller($product_author);
?>	
<div data-role="page" id="shop_single<?php echo mt_rand(); ?>" class="frozr_single_item content-area">
<?php frozr_fixed_cart(true); ?>
<?php frozr_general_search_result(); ?>
<?php frozr_user_favs(); ?>
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo get_the_title($post->ID); ?></div>
<?php woocommerce_output_content_wrapper();
while ( have_posts() ) : the_post();
wc_get_template_part( 'content', 'single-product' );
endwhile; // end of the loop.
do_action( 'woocommerce_after_main_content' );
do_action( 'woocommerce_sidebar' ); ?>
</div>
<?php get_footer( 'shop' );