<?php
/**
 * Custom loops for FrozrDash
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage FrozrDash
 * @since FrozrDash 1.0
 */

function frozr_portfolio_posts_body($post_type, $cat, $get_protfolio_category, $protfolio_posts_title ='', $protfolio_posts_desc ='', $portfolio_title_icon ='', $loop_type = '', $bgcolor = '') {
	
	global $post;
	
	$content = '';
	$title_icon = !empty ($portfolio_title_icon) ? '<i class="material-icons">'.$portfolio_title_icon.'</i>&nbsp;' : '';
	
	$protfolio_query = new WP_Query( array('post_type' =>$post_type, 'posts_per_page'=> -1, $cat=>$get_protfolio_category, 'ignore_sticky_posts'=> 1));
	
	if ( $protfolio_query->have_posts() ) :
	$content .= '<div class="cd_projects_wrapper" style="background-color:'.$bgcolor.'">';
		$content .= '<div class="frozr_portfolio_header">';
			if ( !empty($protfolio_posts_title) ) { $content .= '<h2>'.$title_icon.apply_filters( 'frozr_portfolio_title', $protfolio_posts_title ).'</h2>';}
			if ( !empty($protfolio_posts_desc) ) { $content .= '<p>'. apply_filters( 'frozr_portfolio_description', $protfolio_posts_desc) . '</p>';}
		$content .= '</div>';
		$content .= '<ul class="cd_slider">';
			$count=0;
			while ( $protfolio_query->have_posts() ) : $protfolio_query->the_post();
			if ($count==0) {
				if ($loop_type == 'videos') {
					$class='class="current videos"';
				} else {
					$class='class="current"';
				}
			} else {
				if ($loop_type == 'videos') {
					$class='class="videos"';
				} else {
					$class="";
				}
			}
			$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large');
			$content .= '<li '.$class.'>';
				if ($loop_type == 'videos') {
					$media_upload_mp4 = get_post_meta( $post->ID, '_fro_mp4_url', true );

					$vedio  = '<div class="media_mp4">';
					$vedio .= '<video width="100%" height="100%" controls="controls">';
					$vedio .= '<source src="' . esc_url($media_upload_mp4) . '" type="video/mp4">';
					$vedio .= __('Your browser does not support the video tag', 'frozrdash' );
					$vedio .= '</video></div>';
				$tclass = '';
				} else {
				$vedio = '';
				$tclass = 'style="background: url('.$large_image_url[0].') no-repeat center center #fff;background-size: cover;"';
				}
				$content .= '<a href="'. get_the_permalink().'" title="'. the_title_attribute(array( "before" => __("View","frozr"), "after" => "", "echo" => false)). '">';
					$content .= '<div class="frozr_pf_product_image" '.$tclass.'>'.$vedio.'</div>';
					$content .= '<div class="frozr_pf_product_info">';
						$content .= the_title('<h5>', '</h5>', false);
						$content .= '<p>'.$post->post_excerpt.'</p>';
					$content .= '</div>';
				$content .= '</a>';
			$content .= '</li>';
			$count++;
			endwhile;
		$content .= '</ul>';
	$content .= '</div><!--cd_projects_wrapper-->';
	wp_reset_query();
	endif;
	
	return $content;
}