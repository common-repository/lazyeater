<?php
/**
 * Custom template tags for FrozrDash
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage FrozrDash
 * @since FrozrDash 1.0
 */
 
if ( function_exists( 'child_frozr_footer' ) ) :
function frozr_footer() {child_frozr_footer();}
else :
/**
 * Display theme footer.
 *
 * @since FrozrDash 1.0
 */
function frozr_footer() {
?>
<footer id="colophon" class="site-footer" role="footer"><div class="frozr_custom_menu"><?php wp_nav_menu(array('theme_location' => 'footer','fallback_cb'=>false)); ?></div>
<div class="site-info"><?php echo get_theme_mod('frozr_footer_txt',frozr_customize_partial_footer_txt()); ?></div><!-- .site-info --></footer><!-- .site-footer -->
<?php
}
endif;
add_action('wp_footer','frozr_footer');

/*website header*/
if ( function_exists( 'child_frozr_theme_header' ) ) :
function frozr_theme_header() {child_frozr_theme_header();}
else :
function frozr_theme_header() { ?>
<header id="masthead" class="site-header" role="banner">
<div class="site-branding">
<?php
frozr_the_custom_logo();

if ( is_front_page() && is_home() ) : ?>
	<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
<?php else : ?>
	<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
<?php endif;

$description = get_bloginfo( 'description', 'display' );
if ( $description || is_customize_preview() ) : ?>
	<p class="site-description"><?php echo $description; ?></p>
<?php endif; ?>
</div><!-- .site-branding -->
</header><!-- .site-header -->
<?php
}
endif;

if ( function_exists( 'child_frozr_comment_nav' ) ) :
function frozr_comment_nav() {child_frozr_comment_nav();}
else :
/**
 * Display navigation to next/previous comments when applicable.
 *
 * @since FrozrDash 1.0
 */
function frozr_comment_nav() {
// Are there comments to navigate through?
if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
?>
<nav class="navigation comment-navigation" role="navigation">
	<h2 class="screen-reader-text"><?php _e( 'Comment navigation', 'frozrdash' ); ?></h2>
	<div class="nav-links">
		<?php
			if ( $prev_link = get_previous_comments_link( __( 'Older Comments', 'frozrdash' ) ) ) :
				printf( '<div class="nav-previous">%s</div>', $prev_link );
			endif;

			if ( $next_link = get_next_comments_link( __( 'Newer Comments', 'frozrdash' ) ) ) :
				printf( '<div class="nav-next">%s</div>', $next_link );
			endif;
		?>
	</div><!-- .nav-links -->
</nav><!-- .comment-navigation -->
<?php
endif;
}
endif;

if ( function_exists( 'child_frozr_entry_meta' ) ) :
function frozr_entry_meta() {child_frozr_entry_meta();}
else :
/**
 * Prints HTML with meta information for the categories, tags.
 *
 * @since FrozrDash 1.0
 */
function frozr_entry_meta() {
if ( is_sticky() && is_home() && ! is_paged() ) {
	printf( '<span class="sticky-post">%s</span>', __( 'Featured', 'frozrdash' ) );
}

$format = get_post_format();
if ( current_theme_supports( 'post-formats', $format ) ) {
	printf( '<span class="entry-format">%1$s<a href="%2$s">%3$s</a></span>',
		sprintf( '<span class="screen-reader-text">%s </span>', _x( 'Format', 'Used before post format.', 'frozrdash' ) ),
		esc_url( get_post_format_link( $format ) ),
		get_post_format_string( $format )
	);
}

if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		get_the_date(),
		esc_attr( get_the_modified_date( 'c' ) ),
		get_the_modified_date()
	);

	printf( '<span class="posted-on"><span class="screen-reader-text">%1$s </span><a href="%2$s" rel="bookmark">%3$s</a></span>',
		_x( 'Posted on', 'Used before publish date.', 'frozrdash' ),
		esc_url( get_permalink() ),
		$time_string
	);
}

if ( 'post' == get_post_type() ) {
	if ( is_singular() || is_multi_author() ) {
		printf( '<span class="byline"><span class="author vcard"><span class="screen-reader-text">%1$s </span><a class="url fn n" href="%2$s">%3$s</a></span></span>',
			_x( 'Author', 'Used before post author name.', 'frozrdash' ),
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			get_the_author()
		);
	}

	$categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'frozrdash' ) );
	if ( $categories_list && frozr_categorized_blog() ) {
		printf( '<span class="cat-links"><span class="screen-reader-text">%1$s </span>%2$s</span>',
			_x( 'Categories', 'Used before category names.', 'frozrdash' ),
			$categories_list
		);
	}

	$tags_list = get_the_tag_list( '', _x( ', ', 'Used between list items, there is a space after the comma.', 'frozrdash' ) );
	if ( $tags_list && ! is_wp_error( $tags_list ) ) {
		printf( '<span class="tags-links"><span class="screen-reader-text">%1$s </span>%2$s</span>',
			_x( 'Tags', 'Used before tag names.', 'frozrdash' ),
			$tags_list
		);
	}
}

if ( is_attachment() && wp_attachment_is_image() ) {
	// Retrieve attachment metadata.
	$metadata = wp_get_attachment_metadata();

	printf( '<span class="full-size-link"><span class="screen-reader-text">%1$s </span><a href="%2$s">%3$s &times; %4$s</a></span>',
		_x( 'Full size', 'Used before full size attachment link.', 'frozrdash' ),
		esc_url( wp_get_attachment_url() ),
		$metadata['width'],
		$metadata['height']
	);
}

if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
	echo '<span class="comments-link">';
	/* translators: %s: post title */
	comments_popup_link( sprintf( __( 'Leave a comment<span class="screen-reader-text"> on %s</span>', 'frozrdash' ), get_the_title() ) );
	echo '</span>';
}
}
endif;

if ( function_exists( 'child_frozr_categorized_blog' ) ) :
function frozr_categorized_blog() {child_frozr_categorized_blog();}
else :
/**
 * Determine whether blog/site has more than one category.
 *
 * @since FrozrDash 1.0
 *
 * @return bool True of there is more than one category, false otherwise.
 */
function frozr_categorized_blog() {
if ( false === ( $all_the_cool_cats = get_transient( 'frozr_categories' ) ) ) {
	// Create an array of all the categories that are attached to posts.
	$all_the_cool_cats = get_categories( array(
		'fields'     => 'ids',
		'hide_empty' => 1,

		// We only need to know if there is more than one category.
		'number'     => 2,
	) );

	// Count the number of categories that are attached to the posts.
	$all_the_cool_cats = count( $all_the_cool_cats );

	set_transient( 'frozr_categories', $all_the_cool_cats );
}

if ( $all_the_cool_cats > 1 || is_preview() ) {
	// This blog has more than 1 category so frozr_categorized_blog should return true.
	return true;
} else {
	// This blog has only 1 category so frozr_categorized_blog should return false.
	return false;
}
}
endif;

/**
 * Flush out the transients used in {@see frozr_categorized_blog()}.
 *
 * @since FrozrDash 1.0
 */
function frozr_category_transient_flusher() {
	// Like, beat it. Dig?
	delete_transient( 'frozr_categories' );
}
add_action( 'edit_category', 'frozr_category_transient_flusher' );
add_action( 'save_post',     'frozr_category_transient_flusher' );

if ( function_exists( 'child_frozr_post_thumbnail' ) ) :
function frozr_post_thumbnail() {child_frozr_post_thumbnail();}
else :
/**
 * Display an optional post thumbnail.
 *
 * Wraps the post thumbnail in an anchor element on index views, or a div
 * element when on single views.
 *
 * @since FrozrDash 1.0
 */
function frozr_post_thumbnail() {
	if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
		return;
	}
	$post_thumbnail_id = get_post_thumbnail_id( $post->ID );
	$full_image_link = wp_get_attachment_image_src($post_thumbnail_id, 'large');
	
	if ( is_singular() ) : ?>
	<div class="post-thumbnail" style="background-image: url('<?php echo $full_image_link[0]; ?>')"></div><!-- .post-thumbnail -->
	<?php else : ?>
	<a class="post-thumbnail" href="<?php the_permalink(); ?>" style="background-image: url('<?php echo $full_image_link[0]; ?>')" aria-hidden="true">&nbsp;</a>
	<?php endif; // End is_singular()
}
endif;

if ( function_exists( 'child_frozr_get_link_url' ) ) :
function frozr_get_link_url() {child_frozr_get_link_url();}
else :
/**
 * Return the post URL.
 *
 * Falls back to the post permalink if no URL is found in the post.
 *
 * @since FrozrDash 1.0
 *
 * @see get_url_in_content()
 *
 * @return string The Link format URL.
 */
function frozr_get_link_url() {
	$has_url = get_url_in_content( get_the_content() );

	return $has_url ? $has_url : apply_filters( 'the_permalink', get_permalink() );
}
endif;

if (! is_admin()) :
if ( function_exists( 'child_frozr_excerpt_more' )) :
function frozr_excerpt_more() {child_frozr_excerpt_more();}
else :
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... and a 'Continue reading' link.
 *
 * @since FrozrDash 1.0
 *
 * @return string 'Continue reading' link prepended with an ellipsis.
 */
function frozr_excerpt_more( $more ) {
	$link = sprintf( '<a href="%1$s" class="more-link">%2$s</a>',
		esc_url( get_permalink( get_the_ID() ) ),
		/* translators: %s: Name of current post */
		sprintf( __( 'Continue reading %s', 'frozrdash' ), '<span class="screen-reader-text">' . get_the_title( get_the_ID() ) . '</span>' )
		);
	return ' &hellip; ' . $link;
}
endif;
add_filter( 'excerpt_more', 'frozr_excerpt_more' );
endif;

if ( function_exists( 'child_frozr_the_custom_logo' ) ) :
function frozr_the_custom_logo() {child_frozr_the_custom_logo();}
else :
/**
 * Displays the optional custom logo.
 *
 * Does nothing if the custom logo is not available.
 *
 * @since FrozrDash 1.5
 */
function frozr_the_custom_logo() {
	if ( function_exists( 'the_custom_logo' ) ) {
		the_custom_logo();
	}
}
endif;

if ( function_exists( 'child_frozr_fixed_cart' ) ) :
function frozr_fixed_cart() {child_frozr_fixed_cart();}
else :
/**
 * Displays the fixed WooCommerce cart.
 *
 *
 * @since FrozrDash 1.5
 */
function frozr_fixed_cart($show_on_mobile = false) { ?>
<?php if (class_exists( 'Frozr_Norsani' ) && $show_on_mobile == false && frozr_mobile() || class_exists( 'Frozr_Norsani' ) && $show_on_mobile == true && !frozr_mobile() && !frozr_theme_is_one_column()) {
return false;
} ?>
<div class="frozr_mini_cart_wrapper<?php if (class_exists( 'Frozr_Norsani' ) && frozr_mobile() || frozr_theme_is_one_column()){echo ' frozr_mobile_cart';} ?>">
<div class="frozr_cart_mini">
<div class="frozr_total_mini_cart"><?php wc_cart_totals_order_total_html(); ?></div>
<div class="frozr_min_cart_nav">
<a href="<?php echo esc_url( wc_get_checkout_url() );?>" title="<?php _e('Checkout','frozrdash'); ?>" class="frozr_checkout"><i class="material-icons">exit_to_app</i><span><?php _e('Checkout','frozrdash'); ?></span></a>
<a href="#!0" title="View Cart" class="frozr_view_cart"><i class="material-icons">open_in_browser</i><span><?php _e('View','frozrdash'); ?></span></a>
</div>
</div>
</div>
<?php
}
endif;
if ( function_exists( 'child_frozr_fixed_cart_body' ) ) :
function frozr_fixed_cart_body() {child_frozr_fixed_cart_body();}
else :
/**
 * Displays the fixed WooCommerce cart body.
 * @since FrozrDash 1.5
 */
function frozr_fixed_cart_body() { ?>
<div class="frozr_cart_full<?php if (class_exists('Frozr_Norsani') && frozr_mobile() || frozr_theme_is_one_column()){echo ' frozr_mobile_cart';} ?>">
<?php if ( WC()->cart->is_empty() ) { ?>
<div class="empty_cart">
<i class="material-icons emmpty_cart_icon">shopping_basket</i>
<?php woocommerce_mini_cart(); ?>
</div>
<?php } else {
echo '<h3>'.__('Cart','frozrdash').'</h3>';
woocommerce_mini_cart();
} ?>
</div>
<a href="#!0" title="Close" class="frozr_close_cart"><i class="material-icons">close</i></a>
<?php
}
endif;

add_action('norsani_vendors_page', 'frozr_norsani_vendors_page', 10, 1);
if ( function_exists( 'child_frozr_norsani_vendors_page' ) ) :
function frozr_norsani_vendors_page($vendor_type) {child_frozr_norsani_vendors_page($vendor_type);}
else :
function frozr_norsani_vendors_page($vendor_type) {
$vendor_current_type = !empty($vendor_type) ? $vendor_type : 'all';
$order_types = frozr_default_accepted_orders_types();
$user_loc_un = frozr_norsani_cookies('locun');
$locs =  $user_loc_un ? $user_loc_un : __('Unset','frozrdash');
$locs_text =  $user_loc_un ? __('Update Location','frozrdash') : __('Set Location','frozrdash');
$location_update_link = '<a class="frozr_no_vend_location_set" href="#" title="'. __('Set Location','frozrdash').'">'. $locs_text .'</a>';
?>
<div data-role="page" id="<?php echo mt_rand(); ?>vendors_x_<?php echo $vendor_current_type; ?>" class="content-area vendors_archive">
<?php frozr_fixed_cart(true); ?>
<?php frozr_general_search_result(); ?>
<?php frozr_user_favs(); ?>
<div data-id="finde" style="display:none"><?php echo frozr_vendor_archive_title($vendor_current_type); ?></div>
<div class="filter_box">
	<div class="inner_filter">
		<div class="filter_pointer order_type_pointer"><i></i><span><?php _e('Order Type','frozrdash'); ?></span></div>
		<ul id="rest_type_filter" class="owl-carousel home_filter owl-theme">
			<li class="item" data-value="any"><?php _e('Any','frozrdash'); ?></li>
			<?php foreach ($order_types as $order_type) { ?>
			<li class="item" data-value="<?php echo $order_type; ?>"><?php echo frozr_get_order_type_name($order_type); ?></li>
			<?php } ?>
		</ul>
	</div>
	<div class="inner_filter">
		<div class="filter_pointer vendorclass_pointer"><i></i><span><?php _e('Classification', 'frozrdash'); ?></span></div>
		<ul id="rest_vendorclass_filter" class="owl-carousel home_filter owl-theme">
			<li class="item" data-value="any"><?php _e('Any','frozrdash'); ?></li>
		</ul>
	</div>
</div>
<main class="site-main" role="main">
<div class="vendors_tools">
	<div class="rests_filters_btn"><a class="orderby_top_rated_rests" href="#!"><i class="material-icons">star_rate</i></a></div>
	<div class="rests_filters_btn"><a class="orderby_fav_rests" href="#!"><i class="material-icons">favorite</i></a></div>
	<div class="rests_filters_btn reco_rest_btn"><a class="orderby_reco_rests" href="#!"><i class="material-icons">thumb_up</i></a></div>
	<div class="rests_filters_btn active"><a class="orderby_all_rests" href="#!"><i class="material-icons">store</i></a></div>
	<div class="rests_filters_btn"><a class="rests_search" href="#!"><i class="material-icons">search</i></a></div>
	<div class="rests_filters_btn"><a class="rest_filters" href="#!"><i class="material-icons">tune</i></a></div>
</div>
<div class="frozr_rests_list"></div>
<div class="vendors_nothing_found">
<i class="material-icons">store</i>
<span><?php _e('Loading vendors list...','frozrdash'); ?></span>
</div>
<div class="filter_nothing_found">
<i class="material-icons">store</i>
<span><?php _e('No vendors found :(','frozrdash'); ?></span>
<span class="frozr_current_location_vend_list"><?php echo apply_filters('frozr_your_current_location_text', __('Your Current location is: ','frozrdash')) . '<span class="frozr_current_location_text"><strong>' . $locs . '</strong> '.$location_update_link.'</span>'; ?></span>
</div>
</main><!-- .site-main -->
</div><!-- .content-area -->
<?php
}
endif;

add_action('norsani_dashboard_sellers_page', 'frozr_norsani_dashboard_sellers_page');
if ( function_exists( 'child_frozr_norsani_dashboard_sellers_page' ) ) :
function frozr_norsani_dashboard_sellers_page() {child_frozr_norsani_dashboard_sellers_page();}
else :
function frozr_norsani_dashboard_sellers_page() { ?>
<div data-role="page" id="ly_dashboard_sellers_<?php echo mt_rand(); ?>" class="ly_dashboard sellers_page content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo __('Vendors','frozrdash'); frozr_inline_help_db('dash_vendors'); ?></div>
<main class="site-main" role="main">
<div id="sellers_dash_page" class="content-area-sellers-page">
<div class="ly_dash_listing_header">
<div class="frozr_filter_info_wrapper">
<span class="frozr_filter_info"></span>
<i class="material-icons">arrow_drop_down_circle</i>
</div>
<?php norsani()->sellers->sellers_page_nav(); ?>
</div>
<?php do_action('frozr_before_seller_page'); ?>
<?php norsani()->sellers->frozr_sellers_page_body(); ?>
<?php do_action('frozr_after_seller_page'); ?>
</div>
</main>
</div>
<?php
}
endif;

add_action('norsani_dashboard_settings_page', 'frozr_norsani_dashboard_settings_page');
if ( function_exists( 'child_frozr_norsani_dashboard_settings_page' ) ) :
function frozr_norsani_dashboard_settings_page() {child_frozr_norsani_dashboard_settings_page();}
else :
function frozr_norsani_dashboard_settings_page() { ?>
<div data-role="page" id="ly_dashboard_settings" class="settings_page content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo __('Settings','frozrdash'); ?></div>
<main class="site-main" role="main">
<div id="seller-settings" class="content-area-user-settings">
<?php do_action('frozr_before_dashboard_settings'); ?>
<?php norsani()->vendor->frozr_output_vendor_settings(); ?>
<?php do_action('frozr_after_dashboard_settings'); ?>
</div><!-- #seller-settings .content-area-user-settings -->
</main>
</div>
<?php
}
endif;

add_action('norsani_dashboard_coupons_page', 'frozr_norsani_dashboard_coupons_page');
if ( function_exists( 'child_frozr_norsani_dashboard_coupons_page' ) ) :
function frozr_norsani_dashboard_coupons_page() {child_frozr_norsani_dashboard_coupons_page();}
else :
function frozr_norsani_dashboard_coupons_page() {
if ( isset( $_GET['post'] ) && $_GET['action'] == 'edit' || isset( $_GET['view'] ) && $_GET['view'] == 'add_coupons') {
	$get_post = isset($_GET['post']) ? $_GET['post'] : '';
	$page_title = __('Coupon','frozrdash') .' #'. $get_post;
} else {
	$page_title = __('Coupons','frozrdash');
} ?>
<div data-role="page" id="ly_dashboard_coupons_<?php echo mt_rand(); ?>" class="coupons_page content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo $page_title; if(!isset( $_GET['post'] )) {frozr_inline_help_db('dash_coupons');} ?></div>
<main class="site-main" role="main">
<div id="coupons" class="content-area-coupons-list">			
<?php do_action('frozr_before_dashboard_coupons'); ?>
<div class="ly_dash_listing_header">
<?php norsani()->coupon->frozr_coupons_header_nav(); ?>
</div>
<?php
if ( isset( $_GET['post'] ) && $_GET['action'] == 'edit' || isset( $_GET['view'] ) && $_GET['view'] == 'add_coupons') {
	norsani()->coupon->frozr_add_coupons_form();
} else {
	norsani()->coupon->frozr_list_user_coupons();
}
do_action('frozr_after_dashboard_coupons'); ?>
</div><!-- #coupons .content-area-coupons-list -->
</main>
</div>
<?php
}
endif;

add_action('norsani_dashboard_withdraw_page', 'frozr_norsani_dashboard_withdraw_page');
if ( function_exists( 'child_frozr_norsani_dashboard_withdraw_page' ) ) :
function frozr_norsani_dashboard_withdraw_page() {child_frozr_norsani_dashboard_withdraw_page();}
else :
function frozr_norsani_dashboard_withdraw_page() { ?>
<div data-role="page" id="ly_dashboard_withdraw_<?php echo mt_rand(); ?>" class="ly_dashboard withdraw_page content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo __('Withdraw','frozrdash'); frozr_inline_help_db('dash_withdraw'); ?></div>
<main class="site-main" role="main">
<div id="withdraw" class="content-area-withdraw-page">
<div class="ly_dash_listing_header">
<div class="frozr_filter_info_wrapper">
<span class="frozr_filter_info"></span>
<i class="material-icons">arrow_drop_down_circle</i>
</div>
<?php norsani()->withdraw->frozr_withdraws_page_nav(); ?>
</div>
<?php do_action('frozr_before_dashboard_withdraw'); ?>
<div class="frozr_withdraws_body_wrapper">
<?php norsani()->withdraw->frozr_withdraws_page_body(); ?>
</div>
<?php do_action('frozr_after_dashboard_withdraw'); ?>
</div><!-- #withdraw .content-area-withdraw-page -->
</main>
</div>
<?php
}
endif;

add_action('norsani_dashboard_orders_page', 'frozr_norsani_dashboard_orders_page',10,1);
if ( function_exists( 'child_frozr_norsani_dashboard_orders_page' ) ) :
function frozr_norsani_dashboard_orders_page() {child_frozr_norsani_dashboard_orders_page();}
else :
function frozr_norsani_dashboard_orders_page($order_id) {
if ( $order_id ) {
	$page_title = __('Order','frozrdash') .' #'. $order_id;
} else {
	$page_title = __('Orders','frozrdash');
} ?>
<div data-role="page" id="ly_dashboard_orders_<?php echo mt_rand(); ?>" class="ly_dashboard orders_page content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo $page_title; if (!$order_id) {frozr_inline_help_db('dash_orders');} ?></div>
<main class="site-main" role="main">
<div id="orders" class="content-area-orders-list" data-orderid="<?php echo $order_id; ?>">
<?php do_action('frozr_before_dahsboard_orders'); ?>
<div class="ly_dash_listing_header">
<?php if ( $order_id ) { ?>
<a href="<?php echo home_url( '/dashboard/orders/'); ?>" class="ol_order_title"><?php _e( '&larr; Orders', 'frozrdash' ); ?></a>
<?php } else { ?>
<div class="frozr_filter_info_wrapper">
<span class="frozr_filter_info"></span>
<i class="material-icons">arrow_drop_down_circle</i>
</div>
<?php norsani()->order->frozr_order_listing_status_filter();
} ?>
</div>
<?php if ( $order_id ) {
frozr_get_template( 'orders/order-details.php');
} else {
norsani()->order->frozr_orders_table();
}
?>
<?php do_action('frozr_after_dahsboard_orders'); ?>
</div><!-- #orders .content-area_orders_list -->
</main>
</div>
<?php
}
endif;

add_action('norsani_dashboard_products_page', 'frozr_norsani_dashboard_products_page');
if ( function_exists( 'child_frozr_norsani_dashboard_products_page' ) ) :
function frozr_norsani_dashboard_products_page() {child_frozr_norsani_dashboard_products_page();}
else :
function frozr_norsani_dashboard_products_page() {
global $post, $product, $wp_query;
$page_title = __('Items','frozrdash');
?>
<div data-role="page" id="ly_dashboard_products_<?php echo mt_rand(); ?>" class="ly_dashboard products_page content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo $page_title; frozr_inline_help_db('dash_items'); ?></div>
<main class="site-main" role="main">
<div id="products_list" class="content-area-product-list">
<?php do_action( 'frozr_before_listing_product' ); ?>
<div class="ly_dash_listing_header">
<div class="frozr_filter_info_wrapper">
<span class="frozr_filter_info"></span>
<i class="material-icons">arrow_drop_down_circle</i>
</div>
<?php norsani()->item->frozr_product_listing_status_filter(); ?>
</div>
<table class="product-listing-table ui-responsive table-stroke dash_tables" data-role="table">
<thead>
	<tr class="table_collumns">
	<th data-priority="8" class="frozr_dashitems_header_image"><?php _e( 'Image', 'frozrdash' ); ?></th>
	<th data-priority="1" class="frozr_dashitems_header_name"><?php _e( 'Name', 'frozrdash' ); ?></th>
	<th data-priority="4" class="frozr_dashitems_header_status hide_on_mobile"><?php _e( 'Status', 'frozrdash' ); ?></th>
	<th data-priority="2" class="frozr_dashitems_header_price hide_on_mobile"><?php _e( 'Price', 'frozrdash' ); ?></th>
	<th data-priority="7" class="frozr_dashitems_header_sales hide_on_mobile"><?php _e( 'Sales', 'frozrdash' ); ?></th>
	<th data-priority="3" class="frozr_dashitems_header_views hide_on_mobile"> <?php _e( 'Views', 'frozrdash' ); ?></th>
	<th data-priority="3" class="frozr_dashitems_header_actions"> <?php _e( 'Actions', 'frozrdash' ); ?></th>
	<?php do_action('frozr_after_items_listing_table_header'); ?>
	</tr>
</thead>
<tbody>
	<?php
	if ( have_posts() ) {
		while (have_posts()) {
		the_post();
		$tr_class = ($post->post_status == 'pending' ) ? ' pending_review' : '';
		?>
		<tr id="product_<?php echo $post->ID; ?>" class="frozr_dash_product<?php echo $tr_class; ?>">
		<?php norsani()->item->frozr_get_dash_item($post); ?>
		</tr>
		<?php } ?>
	<?php } else { ?>
	<tr>
	<td colspan="<?php if (frozr_mobile()) {echo '3';} else {echo '7';} ?>"><div class="pl_not_found"><?php _e( 'No item found', 'frozrdash' ); ?></div></td>
	</tr>
	<?php } ?>
</tbody>
</table>
<?php
if ( $wp_query->max_num_pages > 1 ) {
frozr_lazy_nav_below(true);
}
wp_reset_query();
do_action( 'frozr_after_listing_product' ); ?>
</div><!-- #products_list .content-area_product_list -->
</main>
</div>
<?php
}
endif;

add_action('norsani_dashboard_home_page', 'frozr_norsani_dashboard_page');
if ( function_exists( 'child_frozr_norsani_dashboard_page' ) ) :
function frozr_norsani_dashboard_page() {child_frozr_norsani_dashboard_page();}
else :
function frozr_norsani_dashboard_page() {
if (isset($_GET['tour'])) { ?> 
<div class="frozr_dash_info_wrapper frozr_tour_welcome"><div class="tour_box_arrow"></div><div class="frozr_tour_info"><p><?php printf(apply_filters('frozr_dash_tour_welcome_msg',__('Welcome and congratulations for becoming a vendor on %s.','frozrdash')), get_bloginfo( 'name' )); ?></p><p><?php echo __('Would you like a quick startup tour?','frozrdash'); ?></p></div><span class="frozr_tour_actions"><span><a href="#!" data-next="dash" class="frozr_tour_next"><?php echo __('Yes','frozrdash'); ?></a><a href="#!" data-next="" class="frozr_tour_prev"><?php echo __('Back','frozrdash'); ?></a></span><a href="#!" class="frozr_close_tour"><?php echo __('No, thanks','frozrdash'); ?></a></span></div>
<?php } ?>
<div data-role="page" id="ly_dashboard_<?php echo mt_rand(); ?>" class="dashboard_home<?php echo isset($_GET['tour']) ? ' request_tour': ''; ?> content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo __('Dashboard','frozrdash'); ?></div>
<main class="site-main" role="main">
<div id="dashboard" class="content-area-dashboard">
<?php
do_action('frozr_before_dash_sales_report');
frozr_output_totals('f-green');
do_action('frozr_after_dash_sales_report');
?>
<div class="js-masonry" data-masonry-options='{ "isAnimated": true, "itemSelector": ".content-area-dashboard .js-masonry > *", "isOriginLeft": <?php echo frozr_wp_ltr(); ?> }' >
<?php
do_action('frozr_before_user_dashboard');
if (!is_super_admin()) {
frozr_dash_rest_balance();
do_action('frozr_after_dash_rest_balance');
}
frozr_dash_orders();
do_action('frozr_after_dash_orders');
frozr_dash_top_items();
do_action('frozr_after_dash_top_items');
frozr_dash_top_customers();
do_action('frozr_after_user_dashboard');
?>
</div>
<?php do_action('frozr_after_dashboard_content'); ?>
</div>
</main>
</div>
<?php
}
endif;

add_action('norsani_dashboard_item_edit_page', 'frozr_norsani_item_edit_page',10,2);
if ( function_exists( 'child_frozr_norsani_item_edit_page' ) ) :
function frozr_norsani_item_edit_page() {child_frozr_norsani_item_edit_page();}
else :
function frozr_norsani_item_edit_page($post_id, $new_post) {
if ($new_post){
	$page_title = __('New Item','frozrdash');
} else {
	$page_title = __('Editing','frozrdash') .' #'. $post_id;
}
?>
<div data-role="page" id="item_edit_<?php echo $post_id; ?>" class="item_edit_page content-area">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo $page_title; ?></div>
<main class="site-main" role="main">
<div id="product-edit" class="content-area-product-edit">
<?php norsani()->item->frozr_edit_add_item_body($post_id, $new_post); ?>
</div><!-- #product-edit .content-area-product-edit -->
</main>
</div>
<?php
}
endif;

add_action('norsani_single_vendor_page', 'frozr_norsani_single_vendor_page',10,1);
if ( function_exists( 'child_frozr_norsani_single_vendor_page' ) ) :
function frozr_norsani_single_vendor_page() {child_frozr_norsani_single_vendor_page();}
else :
function frozr_norsani_single_vendor_page($store_user) {

$store_info = frozr_get_store_info( $store_user->ID );
$rest_tbls = get_user_meta($store_user->ID, '_rest_tables', true);
$ord_typ = ($store_info['deliveryby'] == 'order') ? __('order','frozrdash') : __('product','frozrdash');
$orders_accept = ! empty ($store_info['accpet_order_type']) ? $store_info['accpet_order_type'] : frozr_default_accepted_orders_types();
$check_geo_service = frozr_is_using_geolocation(true);
$current_location = frozr_norsani_cookies('locun');
$rest_address = norsani()->vendor->frozr_get_vendor_address($store_user->ID);
$rest_geo_address = get_user_meta($store_user->ID, 'rest_address_geo', true) ? get_user_meta($store_user->ID, 'rest_address_geo', true) : '';
$peak_orders = 0 != get_user_meta($store_user->ID, 'frozr_peak_number', true) ? get_user_meta($store_user->ID, 'frozr_peak_number', true) : 0;
$current_processing_orders = frozr_count_user_object('wc-processing', 'shop_order',$store_user->ID);
?>
<div data-role="page" id="vendor_<?php echo $store_user->ID; ?>" data-vendor="<?php echo $store_user->ID; ?>" class="frozr_rest_store_page">
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php if (isset( $store_info['store_name'] )) { echo $store_info['store_name'];}; ?></div>
<?php frozr_seller_disabled_notice($store_user->ID); ?>
<?php frozr_fixed_cart(true); ?>
<?php frozr_general_search_result(); ?>
<?php frozr_user_favs(); ?>
<main class="site-main" role="main">
<?php if (isset( $_GET['make_review'] )) {
	$rest_array = array();
	$rest_rate_orders = array();
	$rest_array = get_user_meta( intval($store_user->ID), 'rest_rating', true );
	if (is_array($rest_array)) {
		foreach($rest_array as $n => $v) {
		$rest_rate_orders[] = $n;
		}
	}
	if (!in_array(intval($_GET['make_review']),$rest_rate_orders)) {
		frozr_store_rating_form($store_user->ID, intval($_GET['make_review']));
	}
}
if ($store_info['allow_email'] == 1) { ?>
<?php $sellerstore = !empty($store_info['store_name']) ? $store_info['store_name'] : __('Vendor','frozrdash'); ?>
<div id="rest_contact">
	<span class="vendor_form_group_label"><i class="material-icons">email</i>&nbsp;<?php echo __('Send Message to','frozrdash'); ?>&nbsp;<span><?php echo $sellerstore; ?></span></span>
	<ul class="frozr_vendor_address_det">
		<?php if ($rest_address) { ?>
		<li><i class="material-icons">place</i>&nbsp;<?php echo $rest_address; ?></li>
		<?php } ?>
		<?php if ( isset( $store_info['phone'] ) && !empty( $store_info['phone'] ) ) { ?>
		<li><i class="material-icons">call</i>
		<a href="tel:<?php echo esc_html( $store_info['phone'] ); ?>"><?php echo esc_html( $store_info['phone'] ); ?></a>
		</li>
		<?php } ?>
		<?php if ( isset( $store_info['show_email'] ) && $store_info['show_email'] == 'yes' ) { ?>
		<li><i class="material-icons">email</i>
		<a href="mailto:<?php echo antispambot( $store_user->user_email ); ?>"><?php echo antispambot( $store_user->user_email ); ?></a>
		</li>
		<?php } ?>
	</ul>
	<?php if ( isset( $store_info['allow_email'] ) && $store_info['allow_email'] == 1 ) {
	norsani()->vendor->frozr_vendor_email_form($store_user->ID,false,false,true);
	} ?>
</div>
<?php } ?>
<div class="frozr_rest_store_profile_frame">
<div class="frozr_store_images" <?php if ( isset( $store_info['banner'] ) && !empty( $store_info['banner'] ) ) { echo "style=\"background-image: url('".wp_get_attachment_url( $store_info['banner'] )."');\"background-size:cover;background-repeat:no-repeat;"; } ?>>
	<?php echo (isset( $store_info['gravatar'] ) && !empty( $store_info['gravatar'] )) ? "<div class=\"frozr_rest_page_logo\" style=\"background-image: url('".wp_get_attachment_url(absint( $store_info['gravatar'] ))."');\"background-size:contain;background-repeat:no-repeat;></div>" : ''; ?>
	<ul class="rest-social<?php echo empty($store_info['gravatar']) ? ' frozr_no_logo_vendor' :'';?>">
	<?php do_action('frozr_before_vendor_store_socials'); ?>
	<?php if ( isset( $store_info['socialfb'] ) && !empty( $store_info['socialfb'] ) ) { ?>
	<li><a href="<?php echo esc_url( $store_info['socialfb'] ); ?>" class="frozr_store_social" target="_blank"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width=".9em" height=".8em" viewBox="0 0 16.48 31.676" enable-background="new 0 0 16.48 31.676" xml:space="preserve"><path fill="#FFFFFF" stroke="#FFFFFF" stroke-width="1.5" d="M15.473,11.599h-4.561c-0.266,0-0.48-0.215-0.48-0.48V8.085c0-0.033,0.003-0.066,0.01-0.098c0.345-2.65,3.735-2.787,5.062-2.738V1.221c-1.698-0.323-8.76-1.295-10.312,4.493C5.187,5.751,5.178,5.795,5.156,5.843C5.068,6.11,5.011,6.773,4.973,7.539c-0.072,1.468-0.063,3.254-0.061,3.579c0.001,0.264-0.212,0.479-0.476,0.48L0.96,11.599v4.438h3.72c0.265,0,0.48,0.215,0.48,0.479v14.2h5.156v-14.2c0-0.265,0.215-0.479,0.479-0.479h4.244L15.473,11.599L15.473,11.599z M11.392,10.64H16l0.045,0.003c0.264,0.025,0.456,0.258,0.432,0.521l-0.523,5.361c-0.006,0.262-0.218,0.471-0.479,0.471h-4.198v14.2c0,0.265-0.215,0.479-0.48,0.479H4.68c-0.265,0-0.48-0.215-0.48-0.479v-14.2H0.48c-0.265,0-0.48-0.215-0.48-0.479v-5.397c0-0.265,0.215-0.479,0.48-0.479h3.475c0-0.718,0.008-2.031,0.063-3.146c0.041-0.833,0.11-1.575,0.223-1.934C4.247,5.53,4.255,5.5,4.267,5.471c1.94-7.253,11.17-5.256,11.79-5.115c0.136,0.021,0.252,0.098,0.325,0.207c0.052,0.077,0.082,0.169,0.082,0.269c0,1.649,0.041,3.333-0.004,4.978c-0.026,0.263-0.262,0.454-0.525,0.427c-0.012-0.001-4.236-0.483-4.542,1.876V10.64L11.392,10.64z"/></svg></a></li>
	<?php } ?>
	<?php if ( isset( $store_info['socialtwitter'] ) && !empty( $store_info['socialtwitter'] ) ) { ?>
	<li><a href="<?php echo esc_url( $store_info['socialtwitter'] ); ?>" class="frozr_store_social" target="_blank"><svg version="1.1" id="Layer_1" xmlns:x="&ns_extend;" xmlns:i="&ns_ai;" xmlns:graph="&ns_graphs;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width=".9em" height=".8em" viewBox="0 0 31.676 25.929" enable-background="new 0 0 31.676 25.929" xml:space="preserve"> <path fill="#FFFFFF" stroke="#FFFFFF" stroke-width="1.5" d="M28.542,6.934c0.006,0.186,0.01,0.362,0.01,0.526c0,4.321-1.594,8.806-4.572,12.272 c-2.984,3.472-7.355,5.924-12.903,6.174c-0.33,0.015-0.644,0.022-0.937,0.022c-1.791,0-3.525-0.26-5.168-0.741 c-1.698-0.498-3.296-1.235-4.753-2.17c-0.222-0.143-0.287-0.439-0.144-0.662c0.102-0.158,0.283-0.237,0.459-0.217 c1.612,0.19,3.223,0.062,4.747-0.364c1.134-0.317,2.222-0.799,3.23-1.438c-0.969-0.206-1.861-0.618-2.629-1.188 c-1.124-0.835-1.98-2.011-2.418-3.374c-0.08-0.252,0.059-0.521,0.31-0.603c0.079-0.024,0.16-0.028,0.236-0.014 c0.224,0.042,0.446,0.071,0.667,0.088c-0.754-0.428-1.411-0.992-1.942-1.65c-0.981-1.216-1.539-2.753-1.502-4.344 c0.005-0.265,0.224-0.475,0.487-0.47c0.081,0.002,0.157,0.023,0.224,0.061l0.004,0.002c0.325,0.18,0.67,0.331,1.03,0.447 C2.223,8.436,1.711,7.415,1.461,6.339C1.082,4.7,1.309,2.928,2.203,1.395C2.335,1.165,2.629,1.088,2.857,1.22 c0.058,0.033,0.106,0.077,0.144,0.128c1.536,1.879,3.457,3.433,5.641,4.54c1.946,0.986,4.103,1.62,6.384,1.813 c-0.043-0.311-0.063-0.617-0.063-0.921c0-1.562,0.545-3.034,1.473-4.206c0.928-1.171,2.236-2.04,3.764-2.396 C20.697,0.063,21.216,0,21.75,0c0.951,0,1.863,0.2,2.693,0.559c0.773,0.335,1.473,0.81,2.064,1.39 c0.594-0.13,1.174-0.305,1.734-0.519c0.65-0.248,1.275-0.551,1.865-0.9c0.229-0.135,0.523-0.06,0.656,0.169 c0.076,0.128,0.086,0.278,0.037,0.408c-0.252,0.78-0.643,1.498-1.141,2.125c-0.098,0.124-0.201,0.244-0.307,0.361 c0.568-0.159,1.121-0.358,1.652-0.594c0.242-0.106,0.523,0.003,0.631,0.244c0.068,0.155,0.047,0.326-0.041,0.458 c-0.438,0.658-0.936,1.275-1.48,1.841C29.63,6.046,29.105,6.512,28.542,6.934L28.542,6.934z M27.591,7.46 c0-0.27-0.004-0.518-0.014-0.74c-0.008-0.156,0.063-0.312,0.197-0.409c0.59-0.425,1.143-0.906,1.65-1.432 c0.133-0.139,0.264-0.28,0.391-0.425l-0.262,0.074c-0.627,0.173-1.268,0.3-1.918,0.377c-0.182,0.021-0.367-0.063-0.467-0.23 c-0.135-0.227-0.063-0.521,0.164-0.656c0.604-0.362,1.139-0.833,1.576-1.384c0.16-0.199,0.305-0.409,0.438-0.628 c-0.252,0.114-0.506,0.221-0.764,0.319c-0.688,0.263-1.404,0.47-2.143,0.615C26.285,2.972,26.117,2.924,26,2.8 c-0.543-0.578-1.201-1.046-1.936-1.364c-0.707-0.305-1.49-0.475-2.314-0.475c-0.465,0-0.91,0.053-1.334,0.151 c-1.313,0.305-2.436,1.051-3.23,2.054c-0.795,1.004-1.264,2.27-1.264,3.613c0,0.439,0.049,0.886,0.154,1.331 c0.008,0.043,0.012,0.087,0.01,0.132c-0.012,0.264-0.236,0.468-0.5,0.455C12.94,8.565,10.443,7.875,8.21,6.742 c-2.091-1.06-3.953-2.508-5.491-4.249C2.216,3.656,2.118,4.932,2.395,6.125c0.321,1.386,1.148,2.661,2.432,3.521 c0.136,0.087,0.225,0.242,0.22,0.415c-0.007,0.265-0.228,0.473-0.491,0.466c-0.549-0.018-1.081-0.101-1.588-0.24 c-0.252-0.069-0.5-0.153-0.74-0.251c0.127,1.084,0.571,2.112,1.256,2.959c0.823,1.02,1.995,1.777,3.38,2.055 c0.171,0.036,0.318,0.164,0.367,0.345c0.069,0.255-0.081,0.518-0.336,0.587c-0.487,0.133-1,0.215-1.523,0.234 c-0.232,0.008-0.468,0.006-0.705-0.011c0.411,0.863,1.029,1.61,1.789,2.175c0.943,0.701,2.105,1.124,3.363,1.147 c0.14,0.002,0.277,0.065,0.37,0.184c0.162,0.208,0.125,0.509-0.083,0.672c-1.373,1.075-2.925,1.854-4.567,2.313 c-1.005,0.281-2.044,0.442-3.096,0.479c0.894,0.441,1.83,0.809,2.801,1.094c1.551,0.455,3.194,0.699,4.898,0.699 c0.324,0,0.623-0.006,0.896-0.019c5.256-0.235,9.393-2.556,12.215-5.84C26.08,15.819,27.591,11.563,27.591,7.46L27.591,7.46z"/></svg></a></li>
	<?php } ?>
	<?php if ( isset( $store_info['socialyoutube'] ) && !empty( $store_info['socialyoutube'] ) ) { ?>
	<li><a href="<?php echo esc_url( $store_info['socialyoutube'] ); ?>" class="frozr_store_social" target="_blank"><svg version="1.1" id="Layer_1" xmlns:x="&ns_extend;" xmlns:i="&ns_ai;" xmlns:graph="&ns_graphs;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width=".9em" height=".8em" viewBox="0 0 31.68 23.154" enable-background="new 0 0 31.68 23.154" xml:space="preserve"> <path fill="#FFFFFF" stroke="#FFFFFF" stroke-width="1.5" d="M30.438,4.723c-0.125-1.066-0.31-1.743-0.506-2.184c-0.173-0.388-0.35-0.573-0.492-0.686l-0.021-0.018 c-0.24-0.179-0.596-0.306-1.048-0.401c-0.509-0.107-1.134-0.171-1.85-0.22c-1.188-0.081-2.771-0.145-4.584-0.188 c-1.789-0.043-3.876-0.065-6.097-0.065c-2.223,0-4.308,0.022-6.097,0.065C7.93,1.07,6.348,1.134,5.16,1.215 c-0.716,0.049-1.34,0.112-1.85,0.22c-0.466,0.099-0.83,0.23-1.071,0.419C2.097,1.965,1.922,2.15,1.748,2.539 C1.552,2.979,1.367,3.656,1.241,4.725L1.24,4.732C1.054,6.325,0.96,8.948,0.96,11.577c0,2.634,0.094,5.262,0.28,6.854 c0.126,1.067,0.311,1.744,0.507,2.185c0.173,0.389,0.349,0.573,0.491,0.685c0.241,0.188,0.605,0.321,1.073,0.42l0.019,0.005 c0.506,0.104,1.123,0.167,1.829,0.216c1.193,0.08,2.782,0.145,4.604,0.188c1.784,0.042,3.862,0.065,6.076,0.065 s4.293-0.023,6.077-0.065c1.822-0.044,3.412-0.108,4.604-0.188c0.715-0.049,1.337-0.112,1.848-0.221 c0.466-0.099,0.83-0.23,1.071-0.42l0.021-0.017c0.139-0.112,0.305-0.298,0.471-0.668c0.196-0.44,0.381-1.116,0.506-2.183 c0.188-1.593,0.281-4.221,0.281-6.855S30.625,6.314,30.438,4.723L30.438,4.723z M30.805,2.149c0.232,0.521,0.448,1.292,0.586,2.465 c0.192,1.636,0.289,4.304,0.289,6.963c0,2.66-0.097,5.327-0.289,6.964c-0.138,1.173-0.354,1.943-0.586,2.464 c-0.244,0.548-0.515,0.839-0.745,1.025l-0.028,0.023c-0.366,0.287-0.859,0.477-1.465,0.604c-0.561,0.119-1.227,0.188-1.982,0.24 c-1.178,0.079-2.781,0.144-4.646,0.188c-1.892,0.045-3.979,0.069-6.099,0.069c-2.119,0-4.208-0.024-6.099-0.069 c-1.863-0.044-3.467-0.108-4.645-0.188c-0.749-0.052-1.409-0.119-1.968-0.237l-0.015-0.003C2.51,22.53,2.018,22.342,1.65,22.054 c-0.237-0.186-0.521-0.478-0.775-1.049c-0.232-0.521-0.448-1.291-0.586-2.462C0.096,16.904,0,14.237,0,11.577 c0-2.652,0.096-5.312,0.287-6.949l0.002-0.016C0.427,3.44,0.642,2.67,0.875,2.149C1.129,1.577,1.413,1.285,1.65,1.1 c0.368-0.287,0.861-0.475,1.465-0.603C3.678,0.379,4.342,0.31,5.096,0.259c1.174-0.08,2.77-0.145,4.625-0.188 C11.617,0.024,13.712,0,15.84,0c2.127,0,4.223,0.024,6.12,0.07c1.854,0.044,3.451,0.108,4.625,0.188 c0.754,0.051,1.419,0.12,1.98,0.238C29.153,0.621,29.636,0.803,30,1.076L30.032,1.1C30.267,1.284,30.549,1.575,30.805,2.149 L30.805,2.149z M11.655,16.408l-0.001-9.662c0-0.266,0.215-0.48,0.48-0.48c0.085,0,0.165,0.022,0.233,0.061l9.254,4.825 c0.235,0.122,0.326,0.412,0.205,0.646c-0.055,0.104-0.141,0.18-0.24,0.222l-9.231,4.813c-0.234,0.122-0.523,0.031-0.646-0.202 C11.673,16.559,11.656,16.483,11.655,16.408L11.655,16.408z M12.614,7.537v8.082l7.75-4.041L12.614,7.537L12.614,7.537z"/></svg></a></li>
	<?php } ?>
	<?php if ( isset( $store_info['socialinsta'] ) && !empty( $store_info['socialinsta'] ) ) { ?>
	<li><a href="<?php echo esc_url( $store_info['socialinsta'] ); ?>" class="frozr_store_social" target="_blank"><svg version="1.1" id="Layer_1" xmlns:x="&ns_extend;" xmlns:i="&ns_ai;" xmlns:graph="&ns_graphs;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width=".9em" height=".8em" viewBox="0 0 31.68 31.679" enable-background="new 0 0 31.68 31.679" xml:space="preserve"> <path fill="#FFFFFF" stroke="#FFFFFF" stroke-width="1.5" d="M15.459,0.921c-1.909,0-3,0.005-3.813,0.019c-0.793,0.014-1.328,0.037-2.127,0.073 C8.724,1.049,8.058,1.13,7.477,1.248C6.9,1.363,6.4,1.516,5.933,1.698C5.457,1.882,5.017,2.099,4.595,2.37 c-0.42,0.27-0.824,0.595-1.227,0.998C2.963,3.774,2.639,4.177,2.37,4.594C2.099,5.016,1.883,5.457,1.698,5.932 C1.517,6.4,1.363,6.9,1.248,7.476C1.131,8.058,1.05,8.724,1.014,9.519c-0.037,0.824-0.061,1.367-0.074,2.207 c-0.012,0.773-0.017,1.952-0.017,4.114c0,2.162,0.004,3.341,0.017,4.115c0.014,0.839,0.037,1.382,0.074,2.206 c0.037,0.796,0.117,1.461,0.234,2.043c0.116,0.576,0.269,1.076,0.45,1.544c0.185,0.475,0.401,0.916,0.672,1.338 c0.27,0.42,0.595,0.822,0.997,1.226l0.002,0.002c0.403,0.402,0.806,0.728,1.226,0.997c0.422,0.271,0.862,0.487,1.338,0.672 c0.468,0.182,0.968,0.335,1.544,0.45c0.582,0.117,1.248,0.198,2.043,0.233c0.824,0.038,1.367,0.062,2.207,0.075 c0.773,0.013,1.952,0.017,4.114,0.017s3.341-0.004,4.114-0.017c0.84-0.014,1.382-0.037,2.207-0.075 c0.795-0.035,1.461-0.116,2.043-0.233c0.576-0.115,1.076-0.269,1.543-0.45c0.477-0.185,0.916-0.401,1.338-0.672 c0.418-0.269,0.82-0.594,1.227-0.999c0.402-0.401,0.729-0.806,0.998-1.226c0.271-0.422,0.488-0.863,0.672-1.338 c0.182-0.468,0.335-0.968,0.451-1.544c0.117-0.582,0.197-1.247,0.233-2.043c0.036-0.8,0.06-1.333,0.073-2.127 c0.014-0.813,0.02-1.903,0.02-3.813l-0.002-0.761c0.002-1.91-0.004-3-0.018-3.813c-0.014-0.793-0.037-1.328-0.073-2.127 c-0.036-0.795-0.116-1.461-0.233-2.043C30.317,6.9,30.164,6.4,29.982,5.932c-0.184-0.476-0.4-0.916-0.672-1.338 c-0.268-0.417-0.594-0.82-0.998-1.226c-0.406-0.405-0.809-0.73-1.227-0.999c-0.422-0.271-0.861-0.488-1.338-0.672 c-0.467-0.182-0.967-0.335-1.543-0.45c-0.582-0.117-1.248-0.198-2.043-0.234c-0.799-0.037-1.334-0.06-2.128-0.073 c-0.812-0.014-1.903-0.019-3.813-0.02L15.459,0.921L15.459,0.921z M11.632,0.021c0.812-0.014,1.908-0.02,3.827-0.02L16.221,0 c1.919,0.002,3.015,0.007,3.827,0.021c0.832,0.014,1.363,0.037,2.152,0.073c0.841,0.038,1.553,0.125,2.184,0.252 c0.637,0.127,1.186,0.295,1.695,0.493c0.535,0.208,1.03,0.452,1.504,0.755c0.477,0.307,0.932,0.672,1.381,1.122 s0.814,0.903,1.121,1.381c0.303,0.473,0.547,0.968,0.754,1.503c0.199,0.51,0.366,1.059,0.494,1.695 c0.127,0.631,0.214,1.343,0.252,2.184c0.037,0.79,0.059,1.321,0.073,2.152c0.015,0.812,0.019,1.907,0.021,3.827l0.001,0.761 c-0.003,1.92-0.007,3.016-0.021,3.828c-0.015,0.831-0.036,1.362-0.073,2.152c-0.038,0.84-0.125,1.553-0.252,2.184 c-0.128,0.636-0.295,1.185-0.494,1.695c-0.207,0.535-0.451,1.029-0.754,1.503c-0.305,0.474-0.67,0.928-1.121,1.379 c-0.449,0.451-0.904,0.816-1.381,1.124c-0.474,0.303-0.969,0.546-1.504,0.754c-0.51,0.199-1.059,0.366-1.695,0.494 c-0.631,0.127-1.343,0.213-2.184,0.252c-0.815,0.037-1.355,0.061-2.232,0.074c-0.942,0.016-2.113,0.02-4.128,0.02 c-2.014,0-3.186-0.004-4.129-0.02c-0.876-0.014-1.416-0.037-2.231-0.074c-0.841-0.039-1.553-0.125-2.184-0.252 c-0.636-0.128-1.185-0.295-1.695-0.494c-0.536-0.207-1.031-0.451-1.503-0.754c-0.474-0.305-0.928-0.671-1.379-1.122l-0.001-0.002 C2.265,28.51,1.9,28.056,1.595,27.583c-0.303-0.474-0.547-0.968-0.755-1.503c-0.198-0.511-0.366-1.06-0.494-1.695 c-0.126-0.631-0.213-1.344-0.252-2.184c-0.037-0.816-0.061-1.356-0.074-2.232C0.005,19.026,0,17.854,0,15.84 s0.005-3.186,0.021-4.128c0.014-0.877,0.037-1.417,0.074-2.232C0.133,8.638,0.22,7.926,0.347,7.295 C0.475,6.659,0.642,6.111,0.84,5.601c0.208-0.536,0.452-1.03,0.755-1.503C1.902,3.62,2.268,3.166,2.717,2.716 C3.17,2.265,3.624,1.9,4.098,1.595C4.57,1.292,5.065,1.048,5.601,0.84c0.51-0.198,1.059-0.366,1.695-0.493 C7.927,0.22,8.639,0.132,9.48,0.094C10.27,0.058,10.801,0.036,11.632,0.021L11.632,0.021z M26.356,7.631 c0,0.635-0.259,1.211-0.675,1.629l-0.002,0.001c-0.418,0.417-0.994,0.675-1.63,0.675s-1.212-0.258-1.63-0.675L22.418,9.26 c-0.417-0.418-0.676-0.994-0.676-1.629c0-0.636,0.259-1.212,0.676-1.629L22.419,6c0.418-0.417,0.994-0.675,1.63-0.675 S25.261,5.583,25.679,6l0.002,0.002C26.097,6.419,26.356,6.995,26.356,7.631L26.356,7.631z M25.029,8.61 c0.25-0.25,0.404-0.597,0.404-0.979c0-0.383-0.154-0.729-0.404-0.979c-0.25-0.25-0.597-0.405-0.979-0.405S23.32,6.402,23.07,6.651 c-0.25,0.25-0.404,0.596-0.404,0.979c0,0.382,0.154,0.729,0.404,0.979c0.25,0.25,0.597,0.404,0.979,0.404S24.779,8.86,25.029,8.61 L25.029,8.61z M15.84,21.427c-1.543,0-2.94-0.625-3.951-1.637c-1.011-1.011-1.636-2.408-1.636-3.951c0-1.543,0.625-2.94,1.636-3.951 c1.011-1.011,2.408-1.637,3.951-1.637s2.94,0.625,3.95,1.637c1.012,1.011,1.637,2.408,1.637,3.951c0,1.542-0.625,2.94-1.637,3.951 C18.781,20.802,17.383,21.427,15.84,21.427L15.84,21.427z M12.542,19.138c0.844,0.844,2.01,1.366,3.298,1.366 s2.454-0.522,3.298-1.366c0.845-0.844,1.367-2.01,1.367-3.298c0-1.288-0.522-2.455-1.367-3.298c-0.844-0.844-2.01-1.366-3.298-1.366 s-2.455,0.522-3.298,1.366c-0.844,0.844-1.366,2.01-1.366,3.298C11.176,17.128,11.698,18.294,12.542,19.138L12.542,19.138z M15.84,8.404c-2.053,0-3.913,0.833-5.258,2.178c-1.345,1.345-2.178,3.205-2.178,5.258s0.832,3.913,2.178,5.257 c1.345,1.346,3.205,2.178,5.258,2.178c2.054,0,3.913-0.832,5.258-2.178c1.346-1.345,2.178-3.204,2.178-5.257 s-0.833-3.913-2.178-5.258C19.753,9.236,17.894,8.404,15.84,8.404L15.84,8.404z M9.93,9.929c1.512-1.513,3.602-2.448,5.91-2.448 c2.308,0,4.397,0.935,5.911,2.448c1.512,1.513,2.447,3.603,2.447,5.911s-0.936,4.398-2.447,5.91 c-1.514,1.513-3.604,2.449-5.911,2.449c-2.308,0-4.398-0.937-5.91-2.449c-1.512-1.512-2.448-3.602-2.448-5.91 S8.418,11.442,9.93,9.929L9.93,9.929z M15.84,2.771c1.978,0,3.12,0.004,4.046,0.019c0.857,0.013,1.383,0.036,2.188,0.073 c0.781,0.035,1.385,0.119,1.863,0.22c0.485,0.103,0.848,0.227,1.139,0.339c0.389,0.151,0.725,0.318,1.036,0.521 c0.313,0.204,0.6,0.441,0.891,0.732l0.002,0.002c0.291,0.291,0.528,0.577,0.731,0.891c0.203,0.312,0.371,0.647,0.521,1.036 c0.113,0.291,0.236,0.654,0.34,1.139c0.102,0.479,0.186,1.082,0.221,1.863c0.037,0.805,0.059,1.331,0.072,2.188 c0.015,0.926,0.02,2.068,0.02,4.046s-0.005,3.12-0.02,4.046c-0.014,0.855-0.035,1.383-0.072,2.188 c-0.035,0.781-0.119,1.385-0.221,1.863c-0.104,0.484-0.227,0.848-0.34,1.139c-0.15,0.389-0.318,0.725-0.521,1.035 c-0.203,0.314-0.441,0.602-0.732,0.893c-0.287,0.289-0.574,0.525-0.892,0.732c-0.312,0.203-0.647,0.37-1.036,0.521 c-0.291,0.112-0.653,0.236-1.139,0.34c-0.479,0.102-1.082,0.185-1.863,0.22c-0.805,0.036-1.331,0.06-2.189,0.073 c-0.926,0.014-2.068,0.019-4.044,0.019c-1.976,0-3.118-0.005-4.044-0.019c-0.858-0.014-1.384-0.037-2.189-0.073 c-0.781-0.035-1.384-0.118-1.863-0.22c-0.485-0.104-0.849-0.228-1.139-0.34c-0.389-0.151-0.724-0.318-1.036-0.521 c-0.317-0.207-0.604-0.443-0.893-0.732c-0.288-0.287-0.525-0.574-0.731-0.893c-0.203-0.312-0.37-0.646-0.521-1.035 c-0.113-0.291-0.236-0.654-0.339-1.139c-0.102-0.479-0.185-1.082-0.221-1.863c-0.037-0.806-0.059-1.332-0.072-2.189 c-0.015-0.927-0.019-2.068-0.019-4.044c0-1.976,0.004-3.118,0.019-4.044c0.013-0.858,0.036-1.384,0.072-2.189 c0.036-0.781,0.119-1.384,0.221-1.863C3.187,7.258,3.31,6.895,3.423,6.604C3.574,6.215,3.741,5.88,3.944,5.568 C4.151,5.25,4.388,4.964,4.676,4.676c0.292-0.291,0.58-0.528,0.893-0.732C5.88,3.741,6.216,3.573,6.604,3.422 C6.895,3.31,7.258,3.186,7.744,3.083c0.479-0.102,1.082-0.185,1.863-0.22c0.805-0.037,1.331-0.06,2.188-0.073 C12.721,2.775,13.862,2.771,15.84,2.771L15.84,2.771z M19.873,3.709c-0.749-0.012-1.904-0.015-4.032-0.015 c-2.127,0-3.284,0.003-4.032,0.015c-0.819,0.013-1.347,0.036-2.163,0.073C8.928,3.814,8.374,3.891,7.935,3.984 C7.503,4.076,7.187,4.183,6.937,4.28C6.607,4.408,6.327,4.547,6.069,4.715C5.813,4.882,5.575,5.08,5.329,5.327 c-0.25,0.251-0.449,0.49-0.613,0.742C4.548,6.327,4.408,6.607,4.281,6.936C4.184,7.187,4.076,7.502,3.984,7.934 C3.891,8.373,3.815,8.927,3.782,9.646c-0.037,0.815-0.06,1.344-0.072,2.161c-0.012,0.749-0.015,1.903-0.015,4.033 c0,2.13,0.003,3.285,0.015,4.033c0.013,0.817,0.035,1.346,0.072,2.162c0.033,0.717,0.109,1.271,0.203,1.711 c0.091,0.432,0.199,0.747,0.296,0.998c0.127,0.329,0.267,0.609,0.435,0.867c0.165,0.252,0.364,0.491,0.613,0.74 c0.25,0.25,0.488,0.449,0.741,0.613c0.258,0.168,0.538,0.307,0.867,0.436c0.25,0.097,0.566,0.204,0.998,0.296 c0.439,0.093,0.993,0.169,1.711,0.202c0.815,0.037,1.344,0.061,2.161,0.072c0.748,0.012,1.903,0.016,4.034,0.016 c2.13,0,3.285-0.004,4.034-0.016c0.816-0.012,1.345-0.035,2.16-0.072c0.719-0.033,1.272-0.109,1.711-0.202 c0.432-0.092,0.748-0.199,0.998-0.296c0.329-0.129,0.609-0.268,0.867-0.436c0.253-0.164,0.492-0.363,0.741-0.613 c0.248-0.246,0.446-0.484,0.613-0.74c0.167-0.258,0.308-0.538,0.435-0.867c0.098-0.251,0.205-0.566,0.297-0.998 c0.093-0.439,0.169-0.993,0.201-1.711c0.037-0.816,0.061-1.345,0.073-2.162c0.012-0.75,0.015-1.905,0.015-4.033 s-0.003-3.283-0.015-4.032c-0.013-0.818-0.036-1.347-0.073-2.163c-0.032-0.718-0.108-1.272-0.201-1.711 c-0.092-0.432-0.199-0.747-0.297-0.998c-0.127-0.329-0.268-0.609-0.435-0.867c-0.167-0.256-0.365-0.495-0.612-0.741l-0.001-0.001 c-0.246-0.247-0.485-0.445-0.741-0.612c-0.258-0.167-0.538-0.307-0.867-0.435c-0.25-0.098-0.566-0.205-0.998-0.296 c-0.438-0.093-0.992-0.17-1.711-0.202C21.219,3.745,20.691,3.722,19.873,3.709L19.873,3.709z"/></svg></a></li>
	<?php } ?>
	<?php do_action('frozr_after_vendor_store_socials'); ?>
	</ul>
	</div>
	<div class="frozr_store_header">
	<?php if ( isset( $store_info['store_name'] ) ) { ?>
	<h1 class="store-name"><?php echo esc_html( $store_info['store_name'] ); ?></h1>
	<?php } ?>
	<div class="frozr_store_status<?php echo (frozr_is_rest_open($store_user->ID) == false) ? ' closed' : ' open'; ?>"><?php echo norsani()->vendor->frozr_rest_status($store_user->ID); ?></div>
	<span class="rest_fav_wrap"><i class="material-icons add_fav add_rest" data-id="<?php echo $store_user->ID; ?>">favorite_border</i></span>
	<?php if ($store_info['allow_email'] == 1) { ?>
	<a href="#!" class="frozr_store_contact_btn"><i class="material-icons">email</i></a>
	<?php } ?>
	</div>
	<div class="frozr_store_details">
	<ul class="list-inline rest-info">
	<?php do_action('frozr_before_vendor_store_info'); ?>
	<li class="frozr_vendor_rating_wrapper"><i class="material-icons">thumb_up</i>&nbsp;<span class="frozr_vendor_rating_info"><?php echo norsani()->vendor->frozr_get_readable_seller_rating( $store_user->ID ); ?></span></li>
	<?php $location_link_class = !empty($_SERVER['HTTPS']) ? 'frozr_set_loc_pop_link' : 'frozr_no_set_loc_link';
	$location_set_link = '<a class="'.$location_link_class.'" href="#" title="'. __('Set your location','frozrdash').'">'. __('set your location','frozrdash').'</a>';
	if (!$current_location && $check_geo_service) {
	$dele_fee_text = '<a class="'.$location_link_class.'" href="#" title="'. __('Set your location to see the delivery fee.','frozrdash').'">'. __('Delivery fee?','frozrdash').'</a>';
	$distance_value = '<a class="'.$location_link_class.'" href="#" title="'. __('Set your location to see the estimated delivery duration to your location.','frozrdash').'">'. __('Delivery duration?','frozrdash').'</a>';
	$distance_help = $dele_fee_help = sprintf(__('You must %s to get the estimated delivery time and fee to your location.','frozrdash'),$location_set_link);
	} else {
	$distance_value = __('Calculating time..','frozrdash');
	$dele_fee_text = __('Calculating fee..','frozrdash');
	$distance_help = __('Delivery duration is being calculated, please wait..','frozrdash');
	$dele_fee_help = __('Delivery fee is being calculated, please wait..','frozrdash');
	}
	if ($rest_geo_address && in_array('delivery', $orders_accept)) { ?>
	<li><div id="<?php echo $store_user->ID; ?>_distance" data-vendor="<?php echo $store_user->ID; ?>" data-address="<?php echo $rest_geo_address; ?>" class="frozr_rest_del_time_wrapper frozr_div_with_help"><div class="frozr_distance_info"><i class="material-icons">timer</i>&nbsp;<span class="frozr_distance_text"><?php echo $distance_value; ?></span></div><div class="frozr_popup_help_wrapper"><a href="#" title="<?php echo __('More Info..','frozrdash'); ?>"><i class="material-icons">help_outline</i></a><span class="frozr_popup_help_text"><?php echo $distance_help; ?></span></div></div></li>
	<li><div class="frozr_del_fee_wrapper frozr_div_with_help" data-ordtyp="<?php echo $ord_typ; ?>" data-fee="<?php echo frozr_delivery_settings($store_user->ID,'shipping_fee',true); ?>"><div class="frozr_del_fee_info"><i class="material-icons">motorcycle</i>&nbsp;<span class="frozr_del_fee_text"><?php echo $dele_fee_text; ?></span></div><div class="frozr_popup_help_wrapper"><a href="#" title="<?php echo __('More Info..','frozrdash'); ?>"><i class="material-icons">help_outline</i></a><span class="frozr_popup_help_text"><?php echo $dele_fee_help; ?></span></div></div></li>
	<li><i class="material-icons">add_shopping_cart</i>&nbsp;<?php echo __('Min. delivery order:','frozrdash').' '; if($store_info['min_order_amt'] == 0) { echo __('Any','frozrdash'); } elseif(!empty($store_info['min_order_amt'])) { echo get_woocommerce_currency_symbol().($store_info['min_order_amt']); } else {echo "N/A";} frozr_inline_help_db('min_del_order'); ?></li>
	<?php } ?>
	<?php if ($rest_address) { ?>
	<li><div class="frozr_vend_address"><i class="material-icons">place</i>&nbsp;<?php echo $rest_address; ?></div></li>	
	<?php } ?>
	<?php if (intval($peak_orders) > 0 && intval($current_processing_orders) > intval($peak_orders)) { ?>
	<li><div class="frozr_div_with_help"><div class="frozr_vendor_peak_time"><i class="material-icons">traffic</i>&nbsp;<?php echo __('Busy','frozrdash'); ?></div><div class="frozr_popup_help_wrapper"><a href="#" title="<?php echo __('More Info..','frozrdash'); ?>"><i class="material-icons">help_outline</i></a><span class="frozr_popup_help_text"><?php echo __('This vendor has received many orders to proceed. Preparation time and delivery fee could vary during this time.','frozrdash'); if (in_array('delivery', $orders_accept) && frozr_delivery_settings($store_user->ID,'shipping_fee_peak',true) > 0) {echo ' </br>'.__('Delivery fees during this time is','frozrdash') . ' ' . frozr_delivery_settings($store_user->ID,'shipping_fee_peak',true) .' '. __('per','frozrdash').' '.$ord_typ.' '.__('Multiplied by the total distance to your location.','frozrdash');} ?></span></div></div></li>	
	<?php } ?>
	<?php if ('' != $rest_geo_address) {?>
	<a href="https://www.google.com/maps/dir/?api=1&destination=<?php echo $rest_geo_address; ?>" class="frozr_store_directions"><i class="material-icons">directions</i><?php _e('Get Directions','frozrdash'); ?></a>
	<?php } ?>
	<?php do_action('frozr_after_vendor_store_info'); ?>
	</ul>
	<?php ob_start();
	$restypes = apply_filters('frozr_vendor_store_cusine_terms',wp_get_object_terms( $store_user->ID, 'vendorclass', array("fields" => "names") ));
	if (is_array($restypes)) { ?>
	<ul class="list-inline rest-cusines">
		<li>
		<i class="material-icons">label</i><?php
		$countags = 1;
		$countary = count($restypes);
		foreach ( $restypes as $restype ) {
		$comma = $countary != $countags ? ',':'';
		$link = get_term_link( $restype, 'vendorclass' ); ?>
		<span><?php echo $restype.$comma; ?></span>
		<?php $countags++; } ?>
		</li>
		<?php do_action('frozr_after_vendor_store_cusines'); ?>
	</ul>
	<?php } echo apply_filters('frozr_rest_store_vendorclass',ob_get_clean(), $store_user->ID); ?>
	</div>
</div> <!-- .profile-frame -->
<?php do_action('frozr_after_rest_header', $store_user); ?>
<?php do_action('frozr_before_vendor_store', $store_user->ID); ?>
<?php norsani()->vendor->frozr_rest_notice_output($store_user->ID); ?>
<?php do_action('frozr_before_vendor_store_coupons',$store_user->ID); ?>
<?php norsani()->vendor->frozr_show_shop_coupons($store_user->ID); ?>
<?php do_action('frozr_after_vendor_store_coupons',$store_user->ID); ?>
<div class="store-page-wrap transitions-enabled">	
<?php frozr_store_loop($store_user->ID); ?>
<div class="frozr_vendor_store_notices frozr_hide"></div>
</div><!-- #content .site-content -->
<?php do_action('frozr_after_vendor_store', $store_user->ID); ?>
</main><!-- .site-main -->
</div><!-- .content-area -->
<?php do_action('frozr_after_store_inloops_body', $store_user->ID, $rest_address);
}
endif;

add_action('frozr_before_user_front_options', 'frozr_dash_seller_settings_menu');
if ( function_exists( 'child_frozr_dash_seller_settings_menu' ) ) :
function frozr_dash_seller_settings_menu() {child_frozr_dash_seller_settings_menu();}
else :
function frozr_dash_seller_settings_menu() {?>
<div class="frozr_tab_filter_info_wrapper">
<span class="frozr_tab_filter_info"><?php _e('General settings','frozrdash'); ?></span>
<i class="material-icons">arrow_drop_down_circle</i>
</div>
<?php
}
endif;

/*custom location form*/
add_action('frozr_after_geo_location_input','frozr_after_user_location_input',10);
if ( function_exists( 'child_frozr_after_user_location_input' ) ) :
function frozr_after_user_location_input() {child_frozr_after_user_location_input();}
else :
function frozr_after_user_location_input() {
if (!empty($_SERVER['HTTPS'])) {
echo '<a class="frozr_set_loc_pop_link" href="#" title="'.__('Set your location to see the delivery fee.','frozrdash').'">'. __('Use Geo-location','frozrdash').'</a>';
}
}
endif;

/*vendor loop*/
if ( function_exists( 'child_frozr_store_loop' ) ) :
function frozr_store_loop() {child_frozr_store_loop();}
else :
function frozr_store_loop($userid) {
ob_start();

$categories = get_terms( array('taxonomy' => 'product_cat') );
$meal_types = get_user_meta($userid, '_rest_meal_types', true);
$nw = new DateTime(date('H:i', strtotime(current_time('mysql'))));
$filterd_opts = is_array($meal_types) ? array_filter($meal_types[0]) : array();
if (is_array($meal_types) && !empty($filterd_opts)) {
	$count_menus = 0;
	$loop_size = count($meal_types);
	$count_loop = 0;
	$time_selected = false;
	echo '<div class="frozr_store_item_menus"><ul class="frozr_store_page_menu_wrapper owl-carousel">';
	foreach ($meal_types as $mvals){
	$count_loop++;
	$startime = new DateTime($mvals['start']);
	$endtime = new DateTime($mvals['end']);
	if (intval(date('H:i',strtotime($mvals['start'])))== 0 && intval(date('H:i',strtotime($mvals['end']))) == 0) {
		$timing = __('All Time','frozrdash');
	} else {
		$timing = date('h:i A',strtotime($mvals['start'])) . ' ' . __('to','frozrdash').' ' .date('h:i A',strtotime($mvals['end']));
	}
		if ($startime <= $nw && $nw < $endtime && !$time_selected || $count_loop == $loop_size && !$time_selected) {
			echo '<li class="rest_menu_item fl_activated" data-pos="'.$count_menus.'" data-wrapper="'.sanitize_title(wp_unslash($mvals['title'])).'">' . sanitize_title(wp_unslash($mvals['title'])) . ' <span>'.$timing.'</span></li>';
			$time_selected = true;
		} else {
			echo '<li class="rest_menu_item" data-wrapper="'.sanitize_title(wp_unslash($mvals['title'])).'">' . sanitize_title(wp_unslash($mvals['title'])) . ' <span>'.$timing.'</span></li>';
		}			
		$count_menus++;
	}
	echo '</ul></div>';
}
foreach ($categories as $category ) {

$args = apply_filters('frozr_store_cats_loop_args',array (
	'author' => $userid,
	'posts_per_page' => -1,
	'post_type'		=> 'product',
	'product_cat'	=> $category->slug,
	'post_status'	=> array('publish','offline')
));

/* The Query*/
$query = new WP_Query( $args );

/* The Loop*/
if ( $query->have_posts() ) {
?>
<div id="gal_<?php echo sanitize_title(wp_unslash($category->slug)); ?>" class="frozr_rest_store_items_group">
<h2 class="rests_list_title"><?php echo $category->name; ?></h2>
<ul class="rests_list_header"><li></li><li class="rest_names_header"><?php echo __('Name','frozrdash'); ?></li>
<li><?php echo __('Rating','frozrdash'); ?></li>
<li class="frozr_items_header_menu hide_on_mobile"><?php echo __('Menu','frozrdash'); ?></li>
<li><i class="material-icons">favorite</i></li>
<li><i class="material-icons">add_shopping_cart</i></li>
</ul>
<?php
while ( $query->have_posts() ) { $query->the_post();
global $product, $post;
frozr_single_item_row($post, $product, 'store');
}
?>
</div>
<?php
}}
}
endif;

if ( function_exists( 'child_frozr_general_search_result' ) ) :
function frozr_general_search_result() {child_frozr_general_search_result();}
else :
/**
 * Displays the search results.
 * @since FrozrDash 1.5
 */
function frozr_general_search_result() {
?>
<div class="frozr_gen_src_wrapper">
<ul class="frozr_gen_src_tabs">
<li class="frozr_gen_tab_rests active"><a title="<?php echo __('Vendors','frozrdash'); ?>" href="#!"><?php echo __('Vendors','frozrdash'); ?></a></li>
<li class="frozr_gen_tab_items"><a title="<?php echo __('Items','frozrdash'); ?>" href="#!"><?php echo __('Items','frozrdash'); ?></a></li>
</ul>
<div class="frozr_gen_rslt_items frozr_hide">
<div class="frozr_gen_rslt_items_list"></div>
</div>
<div class="frozr_gen_rslt_rests"></div>
</div>
<?php
}
endif;

if ( function_exists( 'child_frozr_user_favs' ) ) :
function frozr_user_favs() {child_frozr_user_favs();}
else :
/**
 * Displays the favorite vendors and items.
 * @since FrozrDash 1.5
 */
function frozr_user_favs() { ?>
<div class="frozr_usr_fav_wrapper frozr_hide">
<div class="frozr_gen_fav_pagetitle frozr_hide"><i class="material-icons">arrow_back</i>&nbsp;<?php _e('Your favorites', 'frozrdash'); ?></div>

<ul class="frozr_usr_fav_tabs">
<li class="frozr_usr_fav_rests"><a title="<?php echo __('Vendors','frozrdash'); ?>" href="#!"><?php echo __('Vendors','frozrdash'); ?></a></li>
<li class="frozr_usr_fav_items active"><a title="<?php echo __('Items','frozrdash'); ?>" href="#!"><?php echo __('Items','frozrdash'); ?></a></li>
</ul>
<div class="frozr_usr_fav_rslt_items">
<div class="frozr_usr_fav_rslt_items_list"></div>
</div>
<div class="frozr_usr_fav_rslt_rests frozr_hide"></div>
</div>
<?php
}
endif;

if ( function_exists( 'child_frozr_single_item_row' ) ) :
function frozr_single_item_row() {child_frozr_single_item_row();}
else :
/*single item row*/
function frozr_single_item_row($post, $product, $type='normal') {
$product_obj = wc_get_product($product->get_id());
$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($product_obj->get_id()), 'full');
$thumbnail = isset($large_image_url[0]) ? $large_image_url[0] : '';
$profile_info = frozr_get_store_info($post->post_author);
$rating_check = wc_get_rating_html( $product_obj->get_average_rating(), $product_obj->get_rating_count() ) ? ' has_rating' : ' no_rating';
$menu_type = ( null != (get_post_meta( $product_obj->get_id(), 'product_meal_type', true )) ) ? get_post_meta( $product_obj->get_id(), 'product_meal_type', true ) : array();
/*item cats*/
$discts = get_terms( 'product_cat', 'fields=names&hide_empty=0' );
$itemcats = wp_get_post_terms( $product_obj->get_id(), 'product_cat', array("fields" => "names") );
$itemcats_slug = array();
$unavailable_item = '';
if ($post->post_status == 'offline') {
	$unavailable_item = '<span class="frozr_product_unavailable">'.__('This product is currently unavailable.','frozrdash').'</span>';
}
if (is_array($itemcats)) {
	foreach ( $itemcats as $itemcat ) {
		$itemcats_slug[] = $itemcat;
	}
	$item_cats = join( ' ', $itemcats_slug );
} elseif ( ! empty( $discts ) && ! is_wp_error( $discts )) {
	$item_cats = $itemcats;
}
?>
<div class="items_list_single" data-inputid="#select_rest_items_cat_<?php echo $post->post_author; ?>" data-mealtyp="<?php echo implode(',',$menu_type); ?>" data-mealtyparray="<?php echo isset($menu_type[1]) ? 'array' : 'noarray'; ?>" data-isarray="<?php echo isset($itemcats[1]) ? 'array' : 'noarray'; ?>" data-cat="<?php echo implode(',',$itemcats); ?>" data-filtertext="<?php echo get_the_title($post->ID); ?>" data-proid="<?php echo $product_obj->get_id(); ?>">
	<a class="frozr_navto_item" href="<?php echo esc_url( get_permalink($product_obj->get_id()) ); ?>"><span class="rest_item_img" style="background-image:url('<?php echo $thumbnail; ?>');"></span></a>
	<?php	if($type=='specials'){echo'<span class="item_loop_price">'.$product_obj->get_price_html().'</span>';}	?>
	<span class="item_det">
	<div class="frozr_item_details"><a class="frozr_navto_item frozr_item_title" href="<?php echo esc_url( get_permalink($product_obj->get_id()) ); ?>"><?php echo esc_attr( $post->post_title ); ?></a><?php echo $unavailable_item; ?></div>
	<?php if ($type != 'store') { ?>
	<span class="frozr_item_author"><a title="<?php echo __('Visit Store','frozrdash'); ?>" href="<?php echo frozr_get_store_url($post->post_author); ?>"><?php echo $profile_info['store_name']; ?></a></span>
	<?php } ?>
	</span>
	<span class="item_loop_rating<?php echo $rating_check; ?>"><?php if($rating_check == ' no_rating') {echo '<div class="woocommerce-product-rating"><a class="star-rating" href="#" title="'.__('No Rating Yet!','frozrdash').'"></a></div>';} else { woocommerce_template_single_rating();} ?></span>
	<span class="item_loop_menu hide_on_mobile"><?php echo implode(', ', $menu_type); ?></span>
	<?php	if($type!='store'){ ?>
	<span class="item_cats hide_on_mobile"><?php echo $item_cats; ?></span>
	<?php	} if($type=='specials'){echo'<div class="frozr_item_list_actions">';}	?>
	<span class="item_fav"><i class="material-icons add_fav add_item" data-id="<?php echo $post->ID; ?>">favorite_border</i></span>
	<span class="item_atc"><a href="#0" class="frozr_item_add_to_cart" data-id="<?php echo $product_obj->get_id(); ?>"><i class="material-icons">add</i></a>
	<?php	if($type!='specials'){echo'<span class="item_loop_price">'.$product_obj->get_price_html().'</span>';}	?>
	</span>
	<?php	if($type=='specials'){echo'</div>';}	?>
</div>
<?php
}
endif;

add_filter('woocommerce_product_loop_start', 'frozr_product_loops_header');
if ( function_exists( 'child_frozr_product_loops_header' ) ) :
function frozr_product_loops_header() {child_frozr_product_loops_header();}
else :
function frozr_product_loops_header($loop_start) {
	ob_start(); ?>
	<ul class="rests_list_header"><li></li><li class="rest_names_header"><?php echo __('Name','frozrdash'); ?></li>
	<li><?php echo __('Rating','frozrdash'); ?></li>
	<li class="frozr_items_header_menu hide_on_mobile"><?php echo __('Menu','frozrdash'); ?></li>
	<li class="frozr_items_header_item hide_on_mobile"><?php echo __('Category','frozrdash'); ?></li>
	<li><i class="material-icons">favorite</i></li>
	<li><i class="material-icons">add_shopping_cart</i></li>
	</ul>
	<ul class="products columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?>">
	<?php $loop_start = ob_get_clean();
	return $loop_start;
}
endif;

/*Get today's specials*/
if (class_exists( 'WooCommerce' ) && class_exists( 'Frozr_Norsani' ) && !frozr_mobile() && !frozr_theme_is_one_column()) {
add_action('frozr_sidebar_before_cart', 'frozr_get_today_specials', 10);
} else {
add_action('frozr_after_home_content', 'frozr_get_today_specials', 10);
}
if ( function_exists( 'child_frozr_get_today_specials' ) ) :
function frozr_get_today_specials() {child_frozr_get_today_specials();}
else :
function frozr_get_today_specials() {
	$theme_color = get_theme_mod('color_scheme');
	$icon_color = '';
	if ($theme_color == 'pink' || $theme_color == 'blue') {
	$icon_color = ' frozr_light_specials';
	}
	
	/*Get special items*/
	$items_args = array(
	'posts_per_page'=> -1,
	'offset'		=> 0,
	'post_type'		=> 'product',
	'post_status'	=> 'publish',
	'meta_key'		=> 'frozr_special_item',
	'meta_value'	=> 1,
	'orderby'		=> 'post_date',
	'order'			=> 'DESC'
	);
	
	$items_array = get_posts( $items_args );
	$count = -1;
	$sp_items_count = count($items_array);
	if ($sp_items_count > 1 && frozr_tablet()) {
	$count = -2;
	}
	if ($sp_items_count > 0) {
	echo '<div class="frozr_special_items_wrapper'.$icon_color.'"><div class="frozr_specials_header"><span class="frozr_specials_header_icon"></span><h2 class="frozr_specials_title">'.__('Today\'s Special Products','frozrdash').'</h2></div>';
	echo '<div class="frozr_slides_content"><i class="material-icons frozr_specials_left">keyboard_arrow_left</i><ul class="frozr_specials_list">';
	foreach ( $items_array as $item ) {
		global $product;
		if ($count < 0) {
		$active_class = ' active';
		} else {
		$active_class = '';
		}
		$product = wc_get_product($item->ID);
		if (norsani()->item->frozr_is_item_special($item->ID)) {
			echo '<li class="frozr_specials_item'.$active_class.'">';
			frozr_single_item_row($item,$product,'specials');
			echo '</li>';
		}
		$count++;
	}
	echo '</ul><i class="material-icons frozr_specials_right">keyboard_arrow_right</i></div></div>';
	}
}
endif;