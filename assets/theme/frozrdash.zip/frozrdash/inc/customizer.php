<?php
/**
 * FrozrDash Customizer functionality
 *
 * @package WordPress
 * @subpackage FrozrDash
 * @since FrozrDash 1.0
 */

/**
 * Add postMessage support for site title and description for the Customizer.
 *
 * @since FrozrDash 1.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function frozr_customize_register( $wp_customize ) {
	$color_scheme = frozr_get_color_scheme();

	$wp_customize->get_setting( 'blogname' )->transport			= 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport	= 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector' => '.site-title a',
			'container_inclusive' => false,
			'render_callback' => 'frozr_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector' => '.site-description',
			'container_inclusive' => false,
			'render_callback' => 'frozr_customize_partial_blogdescription',
		));
		$wp_customize->selective_refresh->add_partial( 'frozr_footer_txt', array(
			'selector' => '.site-info',
			'container_inclusive' => false,
			'render_callback' => 'frozr_customize_partial_footer_txt',
		));
	}
	$wp_customize->add_section(
		'frozr_theme_options', array(
			'title'	   => __( 'Theme Options', 'frozrdash' ),
			'priority' => 120,
		)
	);
	$wp_customize->add_setting(
		'frozr_ajax_nav', array(
			'default'			=> 0,
			'sanitize_callback' => 'esc_attr',
		)
	);
	$wp_customize->add_control( 'frozr_ajax_nav', array(
		'label'	   => __( "Disable navigating using Ajax?", "frozrdash" ),
		'description'	 => __( 'Select this box if you use plugins that will crash when using Ajax for pages navigation.', 'frozrdash' ),
		'section'  => 'frozr_theme_options',
		'type'	   => 'checkbox',
		'priority' => 1,
	));
	$wp_customize->add_setting(
		'page_layout', array(
			'default'			=> 'two-column',
			'sanitize_callback' => 'frozr_sanitize_page_layout',
		)
	);
	$wp_customize->add_control(
		'page_layout', array(
			'label'			  => __( 'Page Layout', 'frozrdash' ),
			'section'		  => 'frozr_theme_options',
			'type'			  => 'radio',
			'description'	  => __( 'The two-column layout is only applied on wide screens. In mobile it will only show one column.', 'frozrdash' ),
			'choices'		  => array(
				'one-column' => __( 'One Column', 'frozrdash' ),
				'two-column' => __( 'Two Column', 'frozrdash' ),
			)
		)
	);
	$wp_customize->add_section(
		'frozr_preloader', array(
			'title'	   => __( 'Preload Page', 'frozrdash' ),
			'priority' => 130,
		)
	);
	$wp_customize->add_setting( 'frozr_preload_text', array(
		'default'			=> get_bloginfo( 'name' ),
		'sanitize_callback' => 'wp_kses_post',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( 'frozr_preload_text', array(
		'label'	   => __( 'Page Text', 'frozrdash' ),
		'section'  => 'frozr_preloader',
		'type'	   => 'text',
		'priority' => 1,
	));
	$wp_customize->add_setting( 'frozr_preload_text_size', array(
		'default'			=> 42,
		'sanitize_callback' => 'esc_attr',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( 'frozr_preload_text_size', array(
		'label'	   => __( 'Page Text size in (Pixels)', 'frozrdash' ),
		'section'  => 'frozr_preloader',
		'type'	   => 'number',
		'priority' => 1,
	));
	
	$wp_customize->add_section(
		'frozr_footer', array(
			'title'	   => __( 'Footer', 'frozrdash' ),
			'priority' => 130,
		)
	);
	$wp_customize->add_setting( 'frozr_footer_txt', array(
		'default'			=> frozr_customize_partial_footer_txt(),
		'sanitize_callback' => 'wp_kses_post',
	));
	$wp_customize->add_control( 'frozr_footer_txt', array(
		'label'	   => __( 'Footer Text', 'frozrdash' ),
		'section'  => 'frozr_footer',
		'type'	   => 'textarea',
		'priority' => 1,
	));	
	
	// Add color scheme setting and control.
	$wp_customize->add_setting( 'color_scheme', array(
		'default'			=> 'default',
		'sanitize_callback' => 'frozr_sanitize_color_scheme',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( 'color_scheme', array(
		'label'	   => __( 'Base Color Scheme', 'frozrdash' ),
		'section'  => 'colors',
		'type'	   => 'select',
		'choices'  => frozr_get_color_scheme_choices(),
		'priority' => 1,
	));

	// Add custom sidebar background color setting and control.
	$wp_customize->add_setting( 'header_background_color', array(
		'default'			=> $color_scheme[1],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'header_background_color', array(
		'label'		  => __( 'Header Background Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));

	// Add custom header text color setting and control.
	$wp_customize->add_setting( 'frozrdash_header_textcolor', array(
		'default'			=> $color_scheme[6],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'frozrdash_header_textcolor', array(
		'label'		  => __( 'Header Text Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));

	// Add custom header background color setting and control.
	$wp_customize->add_setting( 'sidebar_background_color', array(
		'default'			=> $color_scheme[2],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'sidebar_background_color', array(
		'label'		  => __( 'Sidebar Background Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Add custom sidebar text color setting and control.
	$wp_customize->add_setting( 'sidebar_textcolor', array(
		'default'			=> $color_scheme[5],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'sidebar_textcolor', array(
		'label'		  => __( 'Sidebar Text Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Add custom top Nav background color setting and control.
	$wp_customize->add_setting( 'top_nav_background_color', array(
		'default'			=> $color_scheme[7],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'top_nav_background_color', array(
		'label'		  => __( 'Top Navigation Background Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Add custom Top Nav text color setting and control.
	$wp_customize->add_setting( 'top_nav_textcolor', array(
		'default'			=> $color_scheme[8],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'top_nav_textcolor', array(
		'label'		  => __( 'Top Navigation Text Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Add custom secondary buttons color setting and control.
	$wp_customize->add_setting( 'fro_secnd_btn_color', array(
		'default'			=> $color_scheme[9],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fro_secnd_btn_color', array(
		'label'		  => __( 'Secondary buttons Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Add custom secondary buttons text color setting and control.
	$wp_customize->add_setting( 'fro_secnd_btn_textcolor', array(
		'default'			=> $color_scheme[10],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fro_secnd_btn_textcolor', array(
		'label'		  => __( 'Secondary buttons Text Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Add custom filters buttons color setting and control.
	$wp_customize->add_setting( 'fro_filters_btn_color', array(
		'default'			=> $color_scheme[11],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fro_filters_btn_color', array(
		'label'		  => __( 'Filter buttons Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Add custom filters buttons text color setting and control.
	$wp_customize->add_setting( 'fro_filters_btn_textcolor', array(
		'default'			=> $color_scheme[12],
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'			=> 'postMessage',
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fro_filters_btn_textcolor', array(
		'label'		  => __( 'Filter buttons Text Color', 'frozrdash' ),
		'section'	  => 'colors',
	)));
	
	// Remove the core header textcolor control, as it shares the sidebar text color.
	$wp_customize->remove_control( 'header_textcolor' );
}
add_action( 'customize_register', 'frozr_customize_register', 11 );

/**
 * Render the site title for the selective refresh partial.
 *
 * @since FrozrDash 1.5
 * @see frozr_customize_register()
 *
 * @return void
 */
function frozr_customize_partial_blogname() {
	bloginfo( 'name' );
}
/**
 * Render the site tagline for the selective refresh partial.
 *
 * @since FrozrDash 1.5
 * @see frozr_customize_register()
 *
 * @return void
 */
function frozr_customize_partial_blogdescription() {
	bloginfo( 'description' );
}
function frozr_customize_partial_footer_txt() {
	return "<a href=\"https://wordpress.org/\">".sprintf( __( 'Proudly powered by %s', 'frozrdash' ), 'WordPress' )."</a>";
}
function frozr_sanitize_page_layout( $input ) {
	$valid = array(
		'one-column' => __( 'One Column', 'frozrdash' ),
		'two-column' => __( 'Two Column', 'frozrdash' ),
	);

	if ( array_key_exists( $input, $valid ) ) {
		return $input;
	}

	return '';
}

/**
 * Register color schemes for FrozrDash.
 *
 * Can be filtered with {@see 'frozr_color_schemes'}.
 *
 * The order of colors in a colors array:
 * 1. Main Background Color.
 * 2. Sidebar Background Color.
 * 3. Box Background Color.
 * 4. Main Text and Link Color.
 * 5. Sidebar Text and Link Color.
 * 6. Meta Box Background Color.
 *
 * @since FrozrDash 1.0
 *
 * @return array An associative array of color scheme options.
 */
function frozr_get_color_schemes() {
	/**
	 * Filter the color schemes registered for use with FrozrDash.
	 *
	 * The default schemes include 'default', 'dark', 'yellow', 'pink', 'purple', and 'blue'.
	 *
	 * @since FrozrDash 1.0
	 *
	 * @param array $schemes {
	 *	   Associative array of color schemes data.
	 *
	 *	   @type array $slug {
	 *		   Associative array of information for setting up the color scheme.
	 *
	 *		   @type string $label	Color scheme label.
	 *		   @type array	$colors HEX codes for default colors prepended with a hash symbol ('#').
	 *								Colors are defined in the following order: Main background, sidebar
	 *								background, box background, main text and link, sidebar text and link,
	 *								meta box background.
	 *	   }
	 * }
	 */
	return apply_filters( 'frozr_color_schemes', array(
		'default' => array(
			'label'	 => __( 'Default', 'frozrdash' ),
			'colors' => array(
				'#f1f1f1',
				'#ffffff',
				'#ffffff',
				'#ffffff',
				'#333333',
				'#333333',
				'#333333',
				'#202020',
				'#f1f1f1',
				'#E71D36',
				'#ffffff',
				'#2EC4B6',
				'#000000',
			),
		),
		'dark'	  => array(
			'label'	 => __( 'Dark', 'frozrdash' ),
			'colors' => array(
				'#111111',
				'#202020',
				'#202020',
				'#202020',
				'#bebebe',
				'#bebebe',
				'#bebebe',
				'#1b1b1b',
				'#bebebe',
				'#F34213',
				'#000000',
				'#E0CA3C',
				'#000000',
			),
		),
		'yellow'  => array(
			'label'	 => __( 'Yellow', 'frozrdash' ),
			'colors' => array(
				'#FFFDED',/*bg*/
				'#FCE762',/*header bg*/
				'#FCE762',/*sidebar bg*/
				'#ffffff',/*boxes bg*/
				'#000000',/*boxes txt*/
				'#000000',/*sidebar txt*/
				'#000000',/*header txt*/
				'#201335',/*top nav bg*/
				'#ffffff',/*top nav txt*/
				'#4F4789',/*sec btn color*/
				'#ffffff',/*sec btn txt*/
				'#FFB17A',/*filters btn color*/
				'#000000',/*filters btn txt*/
			),
		),
		'pink'	  => array(
			'label'	 => __( 'Pink', 'frozrdash' ),
			'colors' => array(
				'#E8E9EB',/*bg*/
				'#EF6461',/*header bg*/
				'#EF6461',/*sidebar bg*/
				'#ffffff',/*boxes bg*/
				'#000000',/*boxes txt*/
				'#000000',/*sidebar txt*/
				'#000000',/*header txt*/
				'#E4B363',/*top nav bg*/
				'#000000',/*top nav txt*/
				'#E0DFD5',/*sec btn color*/
				'#000000',/*sec btn txt*/
				'#313638',/*filters btn color*/
				'#ffffff',/*filters btn txt*/
			),
		),
		'green'	 => array(
			'label'	 => __( 'Green', 'frozrdash' ),
			'colors' => array(
				'#f7fff7',/*bg*/
				'#4ecdc4',/*header bg*/
				'#4ecdc4',/*sidebar bg*/
				'#ffffff',/*boxes bg*/
				'#000000',/*boxes txt*/
				'#000000',/*sidebar txt*/
				'#000000',/*header txt*/
				'#1a535c',/*top nav bg*/
				'#ffffff',/*top nav txt*/
				'#FF6B6B',/*sec btn color*/
				'#000000',/*sec btn txt*/
				'#FFE66D',/*filters btn color*/
				'#000000',/*filters btn txt*/
			),
		),
		'purple'  => array(
			'label'	 => __( 'Purple', 'frozrdash' ),
			'colors' => array(
				'#EADEDA',/*bg*/
				'#D90368',/*header bg*/
				'#D90368',/*sidebar bg*/
				'#ffffff',/*boxes bg*/
				'#000000',/*boxes txt*/
				'#ffffff',/*sidebar txt*/
				'#ffffff',/*header txt*/
				'#820263',/*top nav bg*/
				'#ffffff',/*top nav txt*/
				'#2E294E',/*sec btn color*/
				'#ffffff',/*sec btn txt*/
				'#FFD400',/*filters btn color*/
				'#000000',/*filters btn txt*/
			),
		),
		'blue'	 => array(
			'label'	 => __( 'Blue', 'frozrdash' ),
			'colors' => array(
				'#ffffff',/*bg*/
				'#3E92CC',/*header bg*/
				'#3E92CC',/*sidebar bg*/
				'#f3f3f3',/*boxes bg*/
				'#000000',/*boxes txt*/
				'#000000',/*sidebar txt*/
				'#000000',/*header txt*/
				'#0A2463',/*top nav bg*/
				'#ffffff',/*top nav txt*/
				'#D8315B',/*sec btn color*/
				'#ffffff',/*sec btn txt*/
				'#1E1B18',/*filters btn color*/
				'#ffffff',/*filters btn txt*/
			),
		),
	) );
}

if ( ! function_exists( 'frozr_get_color_scheme' ) ) :
/**
 * Get the current FrozrDash color scheme.
 *
 * @since FrozrDash 1.0
 *
 * @return array An associative array of either the current or default color scheme hex values.
 */
function frozr_get_color_scheme() {
	$color_scheme_option = get_theme_mod( 'color_scheme', 'default' );
	$color_schemes		 = frozr_get_color_schemes();

	if ( array_key_exists( $color_scheme_option, $color_schemes ) ) {
		return $color_schemes[ $color_scheme_option ]['colors'];
	}

	return $color_schemes['default']['colors'];
}
endif; // frozr_get_color_scheme

if ( ! function_exists( 'frozr_get_color_scheme_choices' ) ) :
/**
 * Returns an array of color scheme choices registered for FrozrDash.
 *
 * @since FrozrDash 1.0
 *
 * @return array Array of color schemes.
 */
function frozr_get_color_scheme_choices() {
	$color_schemes				  = frozr_get_color_schemes();
	$color_scheme_control_options = array();

	foreach ( $color_schemes as $color_scheme => $value ) {
		$color_scheme_control_options[ $color_scheme ] = $value['label'];
	}

	return $color_scheme_control_options;
}
endif; // frozr_get_color_scheme_choices

if ( ! function_exists( 'frozr_sanitize_color_scheme' ) ) :
/**
 * Sanitization callback for color schemes.
 *
 * @since FrozrDash 1.0
 *
 * @param string $value Color scheme name value.
 * @return string Color scheme name.
 */
function frozr_sanitize_color_scheme( $value ) {
	$color_schemes = frozr_get_color_scheme_choices();

	if ( ! array_key_exists( $value, $color_schemes ) ) {
		$value = 'default';
	}

	return $value;
}
endif; // frozr_sanitize_color_scheme

/**
 * Enqueues front-end CSS for color scheme.
 *
 * @since FrozrDash 1.0
 *
 * @see wp_add_inline_style()
 */
function frozr_color_scheme_css() {

	$color_scheme = frozr_get_color_scheme();
	$header_background_color = get_theme_mod( 'header_background_color', $color_scheme[1] );
	$sidebar_background_color = get_theme_mod( 'sidebar_background_color', $color_scheme[2] );
	$box_background_color = get_theme_mod( 'box_background_color', $color_scheme[3] );
	$textcolor = get_theme_mod( 'textcolor', $color_scheme[4] );
	$sidebar_textcolor = get_theme_mod( 'sidebar_textcolor', $color_scheme[5] );
	$frozrdash_header_textcolor = get_theme_mod( 'frozrdash_header_textcolor', $color_scheme[6] );
	$top_nav_background_color = get_theme_mod( 'top_nav_background_color', $color_scheme[7] );
	$top_nav_textcolor = get_theme_mod( 'top_nav_textcolor', $color_scheme[8] );
	$fro_secnd_btn_color = get_theme_mod( 'fro_secnd_btn_color', $color_scheme[9] );
	$fro_secnd_btn_textcolor = get_theme_mod( 'fro_secnd_btn_textcolor', $color_scheme[10] );
	$fro_filters_btn_color = get_theme_mod( 'fro_filters_btn_color', $color_scheme[11] );
	$fro_filters_btn_textcolor = get_theme_mod( 'fro_filters_btn_textcolor', $color_scheme[12] );

	// Convert main and sidebar text hex color to rgba.
	$color_textcolor_rgb			= frozr_hex2rgb( $color_scheme[4] );
	$color_sidebar_textcolor_rgb	= frozr_hex2rgb( $color_scheme[5] );
	$colors = array(
		'background_color'				=> $color_scheme[0],
		'header_background_color'		=> $header_background_color,
		'sidebar_background_color'		=> $sidebar_background_color,
		'box_background_color'			=> $box_background_color,
		'textcolor'						=> $textcolor,
		'secondary_textcolor'			=> vsprintf( 'rgba( %1$s, %2$s, %3$s, 0.7)', $color_textcolor_rgb ),
		'border_color'					=> vsprintf( 'rgba( %1$s, %2$s, %3$s, 0.1)', $color_textcolor_rgb ),
		'border_focus_color'			=> vsprintf( 'rgba( %1$s, %2$s, %3$s, 0.3)', $color_textcolor_rgb ),
		'sidebar_textcolor'				=> $sidebar_textcolor,
		'frozrdash_header_textcolor'	=> $frozrdash_header_textcolor,
		'sidebar_border_color'			=> vsprintf( 'rgba( %1$s, %2$s, %3$s, 0.1)', $color_sidebar_textcolor_rgb ),
		'sidebar_border_focus_color'	=> vsprintf( 'rgba( %1$s, %2$s, %3$s, 0.3)', $color_sidebar_textcolor_rgb ),
		'secondary_sidebar_textcolor'	=> vsprintf( 'rgba( %1$s, %2$s, %3$s, 0.7)', $color_sidebar_textcolor_rgb ),
		'top_nav_background_color'		=> $top_nav_background_color,
		'top_nav_textcolor'				=> $top_nav_textcolor,
		'fro_secnd_btn_color'			=> $fro_secnd_btn_color,
		'fro_secnd_btn_textcolor'		=> $fro_secnd_btn_textcolor,
		'fro_filters_btn_color'			=> $fro_filters_btn_color,
		'fro_filters_btn_textcolor'		=> $fro_filters_btn_textcolor,
		'preload_txt_size'				=> get_theme_mod('frozr_preload_text_size',42),
	);

	$color_scheme_css = frozr_get_color_scheme_css( $colors );

	wp_add_inline_style( 'frozr-style', $color_scheme_css );
}
add_action( 'wp_enqueue_scripts', 'frozr_color_scheme_css' );

/**
 * Binds JS listener to make Customizer color_scheme control.
 *
 * Passes color scheme data as colorScheme global.
 *
 * @since FrozrDash 1.0
 */
function frozr_customize_control_js() {
	wp_enqueue_script( 'color-scheme-control', get_template_directory_uri() . '/js/color-scheme-control.js', array( 'customize-controls', 'iris', 'underscore', 'wp-util' ), '20141216', true );
	wp_localize_script( 'color-scheme-control', 'colorScheme', frozr_get_color_schemes() );
}
add_action( 'customize_controls_enqueue_scripts', 'frozr_customize_control_js' );

/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 *
 * @since FrozrDash 1.0
 */
function frozr_customize_preview_js() {
	wp_enqueue_script( 'frozr-customize-preview', get_template_directory_uri() . '/js/customize-preview.js', array( 'customize-preview' ), '20141216', true );
	wp_localize_script( 'frozr-customize-preview', 'frozr_dash_customize', array(
		'preload_pg_txt'	=>	frozr_get_preload_text(),
	) );}
add_action( 'customize_preview_init', 'frozr_customize_preview_js' );

/**
 * Returns CSS for the color schemes.
 *
 * @since FrozrDash 1.0
 *
 * @param array $colors Color scheme colors.
 * @return string Color scheme CSS.
 */
function frozr_get_color_scheme_css( $colors ) {
	$colors = wp_parse_args( $colors, array(
		'background_color'				=> '',
		'header_background_color'		=> '',
		'sidebar_background_color'		=> '',
		'box_background_color'			=> '',
		'textcolor'						=> '',
		'secondary_textcolor'			=> '',
		'border_color'					=> '',
		'border_focus_color'			=> '',
		'sidebar_textcolor'				=> '',
		'frozrdash_header_textcolor'	=> '',
		'sidebar_border_color'			=> '',
		'sidebar_border_focus_color'	=> '',
		'secondary_sidebar_textcolor'	=> '',
		'top_nav_background_color'		=> '',
		'top_nav_textcolor'				=> '',
		'fro_secnd_btn_color'			=> '',
		'fro_secnd_btn_textcolor'		=> '',
		'fro_filters_btn_color'			=> '',
		'fro_filters_btn_textcolor'		=> '',
		'preload_txt_size'				=> '',
	));

$css = <<<CSS
/* Color Scheme */
/* Background Color */body,#preload_page,.frozr_cart_full,.progress{background-color:{$colors['background_color']};}
/*Top nav background color*/.add_fav.fav_item,.frozr_site_navbar,table.product-listing-table thead,.dash_tables thead,.progress .indeterminate,.cd-loader{background-color:{$colors['top_nav_background_color']};}
p.frozr_status_inst > span,.item_ly_options > div,.frozr_vendor_address_det{border-color:{$colors['top_nav_background_color']};}
.frozr_site_navbar,table.product-listing-table thead,.dash_tables thead,.frozr_site_navbar a,.frozr_site_navbar a:hover,.frozr_site_navbar a:focus,.add_fav.fav_item{color:{$colors['top_nav_textcolor']};}
.frozr_upsel_wrapper h2 i{color:{$colors['top_nav_background_color']};}
/*Secondary buttons*/a[data-change="publish"],.frozr_gen_src_tabs .active a:focus,.frozr_order_quick_view,.frozr_upsel_list_wrapper > i,.frozr_vendor_current_status.online span,.frozr_pre_order_label,.frozr_vendor_notices_status.active a,.print_summary_report,.frozr_usr_fav_tabs .active a,.frozr_gen_src_tabs .active a,a.frozr_store_contact_btn > i,.single_add_to_cart a.frozr_item_add_to_cart,.frozr_dash_add_new a,span.dash_with_link,.frozr-remove-gravatar-image,.frozr-gravatar-drag,a.close.frozr-remove-banner-image,a.frozr_clear_loc_map,a.frozr_close_cart,.woocommerce-error, .woocommerce-error a{background-color:{$colors['fro_secnd_btn_color']};color:{$colors['fro_secnd_btn_textcolor']};}
span.dash_with_link a{color:{$colors['fro_secnd_btn_textcolor']};}
.owl-item.active .item.zero_results{color:{$colors['fro_secnd_btn_color']};}
input:focus,select:focus{outline:1px solid {$colors['fro_secnd_btn_color']};}
/*filter buttons*/.frozr_store_status.open,.show_custom,.rests_filters_btn.active i,.frozr_special_items_wrapper,.frozr_special_items_wrapper a,.frozr_dash_notice,li.frozr_reg_active_menu,.frozr_content_loader:before,frozr_content_loader,.frozr_error_box,.woocommerce-message,.woocommerce-message a,.sticky-post,.widget_calendar tbody a,.pagination .prev,.pagination .next,mark,ins,.woocommerce div.product .woocommerce-tabs ul.tabs li.active,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,.tagator_tag,ul.rest-social > li a,.frozr_mini_cart_wrapper.frozr_mobile_cart,.frozr_mini_cart_wrapper.frozr_mobile_cart a,.frozr_single_store_notice,.frozr_single_store_notice a,span.frozr_add_special.active a,.frozr_add_special.active{background-color:{$colors['fro_filters_btn_color']};color:{$colors['fro_filters_btn_textcolor']};}
.owl-item.active .item,.frozr_popup_help_wrapper a,.frozr_vendor_peak_time,span.item_status_label.offline,.owl-item.active .rest_menu_item,p.frozr_status_inst a{color:{$colors['fro_filters_btn_color']};}
/* Header Background Color */.site-header{background-color:{$colors['header_background_color']};}
/* Sidebar Background Color */body:before,#sidebar,.progress .determinate,.frozr_vendor_auto_change_status.active a{background-color:{$colors['sidebar_background_color']};}
/* vendor status */.frozr_site_navbar .frozr_vendor_online{color:{$colors['sidebar_background_color']};}
/* Box Background Color */.frozr_no_results,.frozr_location_set_wrapper,.frozr_pagination,.frozr_product_image_wrapper,ul.products,.frozr_reg_thankyou,.frozr_page_default_content,.frozr_reg_navigation,.frozr_registration_form,.rest_rating_form_wrapper,.post-navigation,.pagination,.edit_wid,.frozr_dash_popup_open,.frozr_gen_rslt_items,.frozr_gen_rslt_rests,.frozr_rests_list,.frozr_usr_fav_rslt_items,.frozr_usr_fav_rslt_rests,.related.products,.upsells.products,.hentry,.pagination,.post-navigation,.page-content,.single-page-content,.woocommerce div.product .woocommerce-tabs .panel,.widecolumn,.comments-area,.frozr_user_menu,.frozr_vendor_status_menu_wrapper,.frozr_screenshots_popup,.item_atc_popup,fieldset.form-field.order_l_type_field,.frozr_gen_help_box,.frozrdash_general_popup,.frozr_rest_store_items_group,div#seller_reg_page .entry-content,div#rest_contact,.dash_totals.frozr_dashboard_announcements,.frozr_rest_store_profile_frame,.order_satus_change,ul.ly_dash_listing_status_filter,form.custom_start_end,.top_sellers_notice.style_box.fa-trophy,.common_pop,.frozr_tab_filter_info_wrapper,ul.tablist-left,.group-opts,.form-group.gen_item_opts,.woocommerce_options_panel,span.frozr_dash_order_customer_det,.withdraw_vendor_pop,div#withdraw_mgs,.frozr_dash_new_withdraw,.withdraw-current-balance,.vendor_coupons_wrapper,.frozr_store_notice_wrapper,.form-group-settings.submit-frozr-settings,ul.wc_payment_methods.payment_methods.methods li > div,.frozr_store_item_menus,.frozr_gen_src,.filter_box,form.coupons_form,.ly_dash_listing_header,.table.product-listing-table,.dash_tables,.dash_totals,.order_table> div,.or_notes > div,.page-header,ul.ly_dash_listing_status_filter,.page-content,.comments-area,.widecolumn,.woocommerce-mini-cart-item.mini_cart_item{background-color:{$colors['box_background_color']};}
/* Box Background Color */button,button:hover,button:focus,.loc_form_wrapper .frozr_set_loc_pop_link,.loc_form_wrapper .frozr_set_loc_pop_link:hover,.loc_form_wrapper .frozr_set_loc_pop_link:focus,.button,.button:hover,.button:focus,.frozr_lazy_dash_nav_btn a,a.add_note.button,input[type="button"],input[type="reset"],input[type="submit"],.pagination .prev,.pagination .next,.widget_calendar tbody a,.widget_calendar tbody a:hover,.widget_calendar tbody a:focus,.page-links a,.page-links a:hover,.page-links a:focus,.sticky-post{color:{$colors['box_background_color']};}
/* Main Text Color */.loc_form_wrapper .frozr_set_loc_pop_link,.frozr_lazy_dash_nav_btn a,button,.button,a.add_note.button,input[type="button"],input[type="reset"],input[type="submit"],.pagination .prev,.pagination .next,.widget_calendar tbody a,.page-links a,.sticky-post{background-color:{$colors['textcolor']};}
/* Main Text Color */body,select,.frozr_dash_popup_open,.frozr_dash_popup_open a,.frozr_gen_src,.frozr_location_set_wrapper,.frozr_location_set_wrapper a,.frozr_location_set_wrapper a:hover,.frozr_location_set_wrapper a:focus,.item_atc_popup,.item_atc_popup a,.item_atc_popup a:hover,.item_atc_popup a:focus,.frozr_gen_help_box,.frozr_gen_help_box a,.frozr_gen_help_box a:hover,.frozr_gen_help_box a:focus,.frozrdash_general_popup,.frozrdash_general_popup a,.frozrdash_general_popup a:hover,.frozrdash_general_popup a:focus,#preload_page,blockquote cite,blockquote small,a,.dropdown-toggle:after,.image-navigation a:hover,.image-navigation a:focus,.comment-navigation a:hover,.comment-navigation a:focus,.entry-footer a:hover,.entry-footer a:focus,.comment-metadata a:hover,.comment-metadata a:focus,.pingback .edit-link a:hover,.pingback .edit-link a:focus,.comment-list .reply a:hover,.comment-list .reply a:focus,.site-info a:hover,.site-info a:focus,.woocommerce-mini-cart-item.mini_cart_item a,.woocommerce-mini-cart-item.mini_cart_item{color:{$colors['textcolor']};}
/* Main Text Color */.entry-content a,.entry-summary a,.page-content a,.comment-content a,.pingback .comment-body > a,.author-description a,.taxonomy-description a,.textwidget a,.entry-footer a:hover,.comment-metadata a:hover,.pingback .edit-link a:hover,.comment-list .reply a:hover,.site-info a:hover{border-color:{$colors['textcolor']};}
/* Secondary Text Color */button:hover,.button:hover,.button:focus,button:focus,input[type="button"]:hover,input[type="button"]:focus,input[type="reset"]:hover,input[type="reset"]:focus,input[type="submit"]:hover,input[type="submit"]:focus,.pagination .prev:hover,.pagination .prev:focus,.pagination .next:hover,.pagination .next:focus,.widget_calendar tbody a:hover,.widget_calendar tbody a:focus,.page-links a:hover,.page-links a:focus{background-color:{$colors['textcolor']};background-color:{$colors['secondary_textcolor']};}
/* Secondary Text Color */blockquote,.logged-in-as a:hover,.comment-author a:hover{border-color:{$colors['textcolor']};border-color:{$colors['secondary_textcolor']};}
/* Border Color */hr,.dropdown-toggle:hover,.dropdown-toggle:focus{background-color:{$colors['textcolor']};background-color:{$colors['border_color']};}
/* Border Color */pre,abbr[title],table,th,td,input,select,textarea,.main-navigation ul,.main-navigation li,.post-navigation,.post-navigation div + div,.pagination,.comment-navigation,.widget li,.widget_categories .children,.widget_nav_menu .sub-menu,.widget_pages .children,.site-header,.hentry + .hentry,.author-info,.entry-content .page-links a,.page-links > span,.page-header,.comments-area,.comment-list + .comment-respond,.comment-list article,.comment-list .pingback,.comment-list .trackback,.comment-list .reply a,.tagator_element,.attr_name,.no-comments{border-color:{$colors['textcolor']};border-color:{$colors['border_color']};}
/* Border Focus Color */a:focus,.button:focus,button:focus,input:focus{outline-color:{$colors['textcolor']};outline-color:{$colors['border_focus_color']};}
input:focus,.tagator_element:focus,textarea:focus{border-color:{$colors['textcolor']};border-color:{$colors['border_focus_color']};}
/* Sidebar Link Color */.secondary-toggle:before{color:{$colors['sidebar_textcolor']};}
.site-title a,.site-description{color:{$colors['frozrdash_header_textcolor']};}
/* Sidebar Text Color */.site-title a:hover,.site-title a:focus{color:{$colors['secondary_sidebar_textcolor']};}
/* Sidebar Border Color */.secondary-toggle{border-color:{$colors['sidebar_textcolor']};border-color:{$colors['sidebar_border_color']};}
/* Sidebar Border Focus Color */.secondary-toggle:hover,.secondary-toggle:focus{border-color:{$colors['sidebar_textcolor']};border-color:{$colors['sidebar_border_focus_color']};}
.site-title a{outline-color: {$colors['sidebar_textcolor']};outline-color: {$colors['sidebar_border_focus_color']};}
/* Sidebar Background Color */.widget button,.widget input[type="button"],.widget input[type="reset"],.widget input[type="submit"],.widget_calendar tbody a,.widget_calendar tbody a:hover,.widget_calendar tbody a:focus{color:{$colors['header_background_color']};}
/* Sidebar Link Color */.secondary a,.frozr_vendor_auto_change_status.active a,.frozr_mini_cart_wrapper,.frozr_mini_cart_wrapper a,.frozr_dash_menu_wrapper a,.dropdown-toggle:after,.widget-title,.widget blockquote cite,.widget blockquote small{color:{$colors['sidebar_textcolor']};}
.widget button,.widget input[type="button"],.widget input[type="reset"],.widget input[type="submit"],.widget_calendar tbody a{background-color:{$colors['sidebar_textcolor']};}
.textwidget a{border-color:{$colors['sidebar_textcolor']};}
/* Sidebar Text Color */.secondary a:hover,.secondary a:focus,.main-navigation .menu-item-description,.widget blockquote,.widget .wp-caption-text,.widget .gallery-caption{color:{$colors['secondary_sidebar_textcolor']};}
.widget button:hover,.widget button:focus,.widget input[type="button"]:hover,.widget input[type="button"]:focus,.widget input[type="reset"]:hover,.widget input[type="reset"]:focus,.widget input[type="submit"]:hover,.widget input[type="submit"]:focus,.widget_calendar tbody a:hover,.widget_calendar tbody a:focus{background-color:{$colors['secondary_sidebar_textcolor']};}
.widget blockquote{border-color:{$colors['secondary_sidebar_textcolor']};}
/* Sidebar Border Color */.main-navigation ul,.main-navigation li,.widget input,.widget textarea,.widget table,.widget th,.widget td,.widget pre,.widget li,.widget_categories .children,.widget_nav_menu .sub-menu,.widget_pages .children,.widget abbr[title]{border-color:{$colors['sidebar_border_color']};}
.dropdown-toggle:hover,.dropdown-toggle:focus,.widget hr{background-color:{$colors['sidebar_border_color']};}
.widget input:focus,.widget textarea:focus{border-color:{$colors['sidebar_border_focus_color']};}
.sidebar a:focus,.dropdown-toggle:focus{outline-color:{$colors['sidebar_border_focus_color']};}
#preload_page h1{font-size:{$colors['preload_txt_size']}px;}	
CSS;
return $css;
}

/**
 * Output an Underscore template for generating CSS for the color scheme.
 *
 * The template generates the css dynamically for instant display in the Customizer
 * preview.
 *
 * @since FrozrDash 1.0
 */
function frozr_color_scheme_css_template() {
	$colors = array(
		'background_color'				=> '{{ data.background_color }}',
		'header_background_color'		=> '{{ data.header_background_color }}',
		'sidebar_background_color'		=> '{{ data.sidebar_background_color }}',
		'box_background_color'			=> '{{ data.box_background_color }}',
		'textcolor'						=> '{{ data.textcolor }}',
		'secondary_textcolor'			=> '{{ data.secondary_textcolor }}',
		'border_color'					=> '{{ data.border_color }}',
		'border_focus_color'			=> '{{ data.border_focus_color }}',
		'sidebar_textcolor'				=> '{{ data.sidebar_textcolor }}',
		'frozrdash_header_textcolor'	=> '{{ data.frozrdash_header_textcolor }}',
		'sidebar_border_color'			=> '{{ data.sidebar_border_color }}',
		'sidebar_border_focus_color'	=> '{{ data.sidebar_border_focus_color }}',
		'secondary_sidebar_textcolor'	=> '{{ data.secondary_sidebar_textcolor }}',
		'top_nav_background_color'		=> '{{ data.top_nav_background_color }}',
		'top_nav_textcolor'				=> '{{ data.top_nav_textcolor }}',
		'fro_secnd_btn_color'			=> '{{ data.fro_secnd_btn_color }}',
		'fro_secnd_btn_textcolor'		=> '{{ data.fro_secnd_btn_textcolor }}',
		'fro_filters_btn_color'			=> '{{ data.fro_filters_btn_color }}',
		'fro_filters_btn_textcolor'		=> '{{ data.fro_filters_btn_textcolor }}',
	);
	?>
	<script type="text/html" id="tmpl-frozr-color-scheme">
		<?php echo frozr_get_color_scheme_css( $colors ); ?>
	</script>
	<?php
}
add_action( 'customize_controls_print_footer_scripts', 'frozr_color_scheme_css_template' );