<?php
/**
 * Template Name: Frozr front page
 *
 * This is a custom Page template for displaying Frozr Blog Page.
 * 
 *
 * @package Norsani
 * @subpackage Themes
 * @since FrozrDash 1.0
 */

// calling the header.php
get_header(); ?>
<div data-role="page" id="front_page<?php echo mt_rand(); ?>" class="content-area front_page">
<?php frozr_fixed_cart(true); ?>
<?php frozr_general_search_result(); ?>
<?php frozr_user_favs(); ?>
<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo get_the_title($post->ID); ?></div>
<main class="site-main" role="main">
<?php while ( have_posts() ) : the_post(); ?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php frozr_post_thumbnail(); ?>
<header class="entry-header">
<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
</header>
<div class="entry-content">
<?php the_content(); ?>
<input type="text" class="frozr_home_search_btn" placeholder="<?php echo __('Start typing to search vendors & products...','frozrdash'); ?>" />
</div>
<?php do_action('frozr_after_home_content'); ?>
</article>
<?php endwhile; ?>
</main>
</div>
<?php get_footer();