<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package Norsani
 * @subpackage Themes
 * @since FrozrDash 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js<?php if (frozr_theme_is_one_column() && !frozr_mobile()) {echo ' frozr_one_col';} ?>">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width">
<!-- Chrome, Firefox OS and Opera -->
<meta name="theme-color" content="<?php echo get_theme_mod('top_nav_background_color','#ffffff'); ?>">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<!--[if lt IE 9]>
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
<![endif]-->
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_customize_support_script(); ?>
<div id="preload_page"><div class="frozr_preloader_inner"><?php	if($logo_url=frozr_get_logo_img_url()){echo	'<div class="frozr_preloader_logo" style="background-image:url('.$logo_url.');"></div>';}	?><h1><?php echo frozr_get_preload_text(); ?></h1></div></div>
<div class="frozr_general_wrapper">
<div id="sidebar" class="sidebar">
	<?php if (!frozr_theme_is_one_column() || frozr_mobile()) {frozr_theme_header();} ?>
	<?php frozr_get_vendor_dashboard_menu(); ?>
	<div class="frozr_main_sidebar">
	<?php get_sidebar(); ?>
	</div>
	<?php do_action('frozr_sidebar_before_cart'); ?>
	<?php if (!frozr_theme_is_one_column() || frozr_mobile()) { ?>
	<?php frozr_fixed_cart(); ?>
	<?php } ?>
</div><!-- .sidebar -->
<div id="general_page" class="hfeed site <?php echo (is_super_admin()) ? 'admin_bar_active' : ''; ?>" style="opacity:0">
<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'frozrdash' ); ?></a>
<?php if ( is_user_logged_in() ) { ?>
<div class="frozr_user_menu">
<div class="frozr_popup_arrow"></div>
<?php do_action( 'woocommerce_account_navigation' ); ?>
</div>
<?php if ( user_can( get_current_user_id(), 'frozer' ) && class_exists('Frozr_Norsani') && frozr_is_seller_enabled(get_current_user_id()) ) { ?>
<div class="frozr_vendor_status_menu_wrapper">
<div class="frozr_popup_arrow"></div>
<audio id="frozr_new_order_buzz" controls style="display:none;">
<source src="https://notificationsounds.com/notification-sounds/definite-555/download/ogg" type="audio/ogg">
<source src="https://notificationsounds.com/notification-sounds/definite-555/download/mp3" type="audio/mpeg">
<source src="https://notificationsounds.com/notification-sounds/definite-555/download/m4r" type="audio/m4r"></audio>
<?php do_action('frozr_norsani_vendor_status_main_menu'); ?>
</div>
<?php } ?>
<?php } ?>
<div id="content" class="site-content">
<div class="frozr_site_navbar">
	<?php if (frozr_theme_is_one_column() && !frozr_mobile()) {frozr_theme_header();} ?>
	<a href="#sidebar" class="secondary-toggle">
		<i class="material-icons">menu</i>
	</a>
	<div class="rests_src_box">
		<form class="frozr_search_vendors">
		<div class="frozr_input_group">
		<input type="text" name="frozr_rests_src" placeholder="<?php _e('Start typing to search vendors...','frozrdash'); ?>">
		</div>
		</form>
	</div>
	<div class="frozr_page_title"><div class="main_title"></div><div class="external_page_title frozr_hide"></div></div>
	<div class="general_fav_btn"><a title="<?php _e('My Favorite Vendors & Products','frozrdash'); ?>" href="#!"><i class="material-icons">favorite</i></a></div>
	<div class="frozr_general_src_btn"><a title="<?php _e('Search Vendors & Products ...','frozrdash'); ?>" href="#!"><i class="material-icons">search</i></a></div>
	<div class="frozr_gen_src_box">
		<form class="frozr_gen_search_form">
		<div class="frozr_input_group">
		<input type="text" class="frozr_gen_src" name="frozr_gen_src" placeholder="<?php _e('Start typing to Search Vendors & Products ...','frozrdash'); ?>">
		</div>
		</form>
		<i class="material-icons">close</i>
	</div>
	<div class="frozr_gen_help_box"></div>
	<div class="frozr_location_set_wrapper"><?php if (class_exists('Frozr_Norsani')) {frozr_user_location_form('gen');} ?></div>
	<div class="item_atc_popup"></div>
	<div class="frozr_navbar_actions">
		<?php if ( user_can( get_current_user_id(), 'frozer' ) && class_exists('Frozr_Norsani') && frozr_is_seller_enabled(get_current_user_id()) ) { ?>
		<a href="#!" data-wrapper="frozr_vendor_status_menu_wrapper" class="frozr_vendor_status_link frozr_user_menu_trigger <?php if (frozr_is_rest_open(get_current_user_id())) { echo 'frozr_vendor_online';} ?>"><i class="material-icons">store</i></a>
		<?php } ?>
		<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" data-wrapper="frozr_user_menu" class="frozr_my_account_link <?php if (is_user_logged_in()) { echo 'frozr_user_menu_trigger';} ?>"><i class="material-icons">account_circle</i></a>
	</div>
	<div class="frozrdash_general_popup"></div>
	<?php do_action('frozr_after_header_site_navbar'); ?>
</div>
<?php frozr_fixed_cart_body();