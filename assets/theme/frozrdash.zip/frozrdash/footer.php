<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package Norsani
 * @subpackage Themes
 * @since FrozrDash 1.0
 */
?>
</div><!-- .site-content -->
</div><!-- .site -->

<?php wp_footer(); ?>
</div><!-- .frozr_general_wrapper -->
</body>
</html>