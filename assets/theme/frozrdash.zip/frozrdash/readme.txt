=== FrozrDash ===
Requires at least: 4.4
Tested up to: 4.9
Stable tag: 1.13
== Copyright ==

Mahmud Hamid Copyright 2017-2018 Mahmudhamid.com This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Changelog ==
= 1.13 =
* Fixed main menu layout bug.
* Fixed special items error.
= 1.12 =
* Fixed sanitize_title to vendor types option to avoid multi-language strings.
* Fixed WooCommerce Widgets layout.
* Added vendor address on shop page.
* Fixed few icons layout.
= 1.11 =
* Fixed few important layout issues.
= 1.10 =
* Fixed customer orders list date and total fields.
* Removed parent orders from customer orders list.
* Fixed product rating error on special products loop.
* Improved front-end dashboard layout.
* Decrease the load size of the theme.
* Fixed product qty field layout on Firefox.
* Update old WooCommerce files in FrozrDash.
= 1.9 =
* Modified "Vendor Type" slide filter to show possible delivery vendors only.
* Fixed item and vendor favorite function.
* Fixed add to cart function error.
* Fixed page content after new orders check.
* Fixed page content after location set.
* Fixed "Sort by Distance" button layout on RTL.
* Fixed few layout bugs for system buttons.
* Updated language files.
= 1.8 =
* Enhanced the general search function.
* Added "sort vendors by distance" feature.
* Updated main style file.
* Updated language files.
= 1.7 =
* Update language files and added dutch (Belgium) language.
* Added theme-color meta tag to change mobile browser tab color.
* Fixed order's quick view layout in mobile screens.
* Fixed type filters layout.
* Fixed the Custom color picks function.
= 1.6 =
* Fixed vendor type saving function.
= 1.5 =
* Added Swedish translation.
* Fixed pages transition on IOS.
* Removed vendor-registration template file.
* Updated language files.
= 1.4 =
* Added German, Arabic, Spanish, French, Indian, Italian, Malay, Portuguese, Russian, and Turkish translations.
* Fixed few spelling mistakes.
= 1.3 =
* Added RTL theme option.
* Fixed some phrases mistakes.
* Fixed footer layout.
* Added hover effect for main navigation.
= 1.2 =
* Fixed long text layout in front-end dashboard pages.
* Fixed admin front-end sellers page pagination layout.
= 1.1 =
* Allowed the featured vendors list to default fallback if no vendors found related to the user current page.
* Close popups and remian in same page when click the browser/device back button.
* Fixed few layout issues on mobile.
* Fixes special items box sliding issue on ajax page loading.
= 1.0 =
* Released: July 02, 2018 

Initial release