/**
 * Live-update changed settings in real time in the Customizer preview.
 */

( function( $ ) {
	var $style = $( '#frozr-color-scheme-css' ),
		api = wp.customize,
		preload_time,
		preload_txt = frozr_dash_customize.preload_pg_txt,
		preload_txt_size;
	
	if ( ! $style.length ) {
		$style = $( 'head' ).append( '<style type="text/css" id="frozr-color-scheme-css" />' ).find( '#frozr-color-scheme-css' );
	}

	// Site title.
	api( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );

	// Site tagline.
	api( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

	// preload page txt.
	api( 'frozr_preload_text', function( value ) {
		value.bind( function( to ) {
			preload_txt = to;
			$('#preload_page h1').html(to);
		});
	});
	
	// preload page txt size.
	api( 'frozr_preload_text_size', function( value ) {
		value.bind( function( to ) {
			preload_txt_size = to;
			$('#preload_page h1').css('font-size',to+'px');
		});
	});
	
	/*Norsani Menus*/
	api( 'color_scheme', function( value ) {
		value.bind( function( to ) {
			var icon_color = 'dark';
			var specials_icon = '';
			if (to == 'purple' || to == 'dark') {
				icon_color = 'light';
			}
			if (to == 'pink' || to == 'blue') {
				specials_icon = 'frozr_light_specials';
			}
			
			$('.frozr_special_items_wrapper').removeClass('frozr_light_specials').addClass(specials_icon);
			$('.nor_br_menu > a > span').removeClass().addClass('nor_br_menu_icon_'+icon_color);
			$('.nor_bc_menu > a > span').removeClass().addClass('nor_bc_menu_icon_'+icon_color);
			$('.nor_bg_menu > a > span').removeClass().addClass('nor_bg_menu_icon_'+icon_color);
			$('.nor_bft_menu > a > span').removeClass().addClass('nor_bft_menu_icon_'+icon_color);
		});
	});

	// Color Scheme CSS.
	api.bind( 'preview-ready', function() {
		api.preview.bind( 'frozr-preload-highlight', function( data ) {
			clearTimeout(preload_time);
			if ( true === data.expanded ) {
				$('body.home').prepend('<div id="preload_page" class="hideload"><h1 style="font-size:'+preload_txt_size+'px;">'+preload_txt+'</h1></div>');
				preload_time = setTimeout(function(){$('#preload_page').removeClass('hideload');}, 100);
			} else {
				$('#preload_page').addClass('hideload');
				preload_time = setTimeout(function(){$('#preload_page').remove();}, 1000);
			}
		});
		api.preview.bind( 'update-color-scheme-css', function( css ) {
			$style.html( css );
		} );
	} );
} )( jQuery );