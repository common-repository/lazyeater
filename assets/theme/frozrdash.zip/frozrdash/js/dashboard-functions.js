/* global screenReaderTextDash */
/**
 * Theme vendor dashboard functions file.
 *
 */

( function( $ ) {
var show_dash_actions_time,
	show_dash_pop_time,
	show_order_customer_time,
	show_dash_settings_tabs_time,
	show_withdraw_msg_form_time,
	show_withdraw_edit_form_time,
	show_withdraw_payment_det_time,
	show_hide_dash_filters_time,
	withdraw_msg_hide_time,
	dash_tour_show_time,
	dash_tour_show_info_time,
	check_orders_box_remove_time,
	check_orders_hide_box_time,
	checking_for_orders_message_time,
	frozr_vendor_status_link_remove_time,
	$document,
	checkedWithdraws = 0,
	active_page_id,
	check_order_call,
	refresh = null;
	
var Frozr_Dashboard_Scripts = {
	init: function() {
		var self = this;
		
		/*get the document*/
		$document = $( document );

		/*Disable ajax linking on wp-admin bar*/
		$document.ready(function(){
			$('#wpadminbar a', document).attr('data-ajax', 'false');
		});
		
		if (screenReaderText.norsani_exisit != 1) {
			return false;
		}
		
		$( document.body )
		/*General*/
		.on('click', 'a', self.close_tours)
		.on("click", self.close_filters)
		/*Dashboard*/
		.on('change', '.delivey_by_options input', self.show_hide_del_additional_fee)
		.on('click','.frozr_add_special a', self.add_item_to_special)
		.on('click','.frozr_ord_act_icon > i', self.show_dash_actions)
		.on('click','.new_withdraw a', self.show_withdraw_form)
		.on('click','.frozr_dash_withdraw_payment_det > a, .frozr_dash_withdraw_view_seller', self.show_withdraw_payment_det)
		.on('click','.edit_wid_btn', self.show_withdraw_edit_form)
		.on('click','#withdraw .send_seller_msg_pop', self.show_withdraw_msg_form)
		.on('click','.frozr_dash_order_customer', self.show_order_customer)
		.on('click','.tablist-left a', self.show_dash_settings_tab)
		.on('click','.frozr_tab_filter_info_wrapper, .frozr_tab_filter_info_wrapper *', self.show_dash_settings_tabs)
		.on('click','#rest_allow_ords', self.show_hide_offline_orders)
		.on('click','.frozr_dash_popup_link, .frozr_dash_popup_link i', self.show_dash_pop)
		.on('click','.frozr_dash_product_change_status a', self.change_item_status)
		.on('click','.woocommerce_options_panel > h3', self.show_hide_item_sections)
		.on('click','.frozr_filter_info_wrapper', self.show_hide_dash_filters)
		.on('click','.frozr_tour_next, .frozr_tour_prev', self.nav_dash_tour)
		.on('click','.frozr_order_quick_view', self.open_close_order_view)
		.on('click','.frozr_close_tour', self.close_dash_tour)
		.on('frozr_pay_wid_success',self.paid_payout)
		.on('frozr_cancel_wid_success',self.canceled_payout)
		.on('frozr_wid_error',self.payout_error)
		.on('frozr_item_updated',self.nav_to_items)
		.on('frozr_coupon_updated',self.nav_to_coupons)
		.on('click','.frozr_reg_price_dis',self.add_var_notice)
		.on('click','.dash_tables_actions > i',self.open_items_actions_menu)
		.on('click','.frozr_view_opt',self.frozr_orders_view_options)
		.on('click','.frozr_vendor_change_sts,.frozr_vendor_status_link', self.vendor_change_status)
		.on('click', '.frozr_ly_dash_menu_title', self.open_dash_menu);
		
		/*Page events*/
		$document.on( "pagecontainertransition", function( event, ui ) {
			checkedWithdraws = 0;
			var current_page_id = ui.toPage.attr('id');
			var current_page = $('#'+current_page_id);
			current_page.addClass('ui-page-active-loaded');
			
			/*If vendor online check for new orders every minute*/
			if (screenReaderTextDash.manual_online && $('.frozr_vendor_current_status.online').length > 0 || $('.frozr_vendor_notices_status.active').length > 0 && $('.frozr_vendor_current_status.online').length > 0 || $('#orders .orders_lists', current_page).length > 0 && $('.frozr_vendor_current_status.online').length > 0) {
				if (refresh === null) {
				refresh = setInterval(Frozr_Dashboard_Scripts.check_for_new_orders, 60000);
				}
			} else {
				clearInterval(refresh);
				refresh = null;
			}

			/*Orders page*/
			if (current_page.hasClass('orders_page')) {
				Frozr_Dashboard_Scripts.update_orders_count();
			}
			
			/*Updates payouts*/
			if (current_page.hasClass('withdraw_page') && checkedWithdraws == 0 && screenReaderTextDash.active_payout == 1) {
				checkedWithdraws = 1;
				setTimeout(function(){Frozr_Dashboard_Scripts.check_payouts();},1500);
			}
		});
		$document.on( "pagecontainerbeforeshow", function( event, ui ) {
			var current_page_id = ui.toPage.attr('id');
			var current_page = $('#'+current_page_id);
			var user_notice_option = window.localStorage.getItem("store_notice");
			active_page_id = current_page_id;
			
			/*Dashboard home*/
			if (current_page.hasClass('dashboard_home')) {
				/*tour active*/
				clearTimeout(dash_tour_show_time);
				clearTimeout(dash_tour_show_info_time);
				var tour_page = $('.request_tour');
				var tour_wel_div = $('.frozr_dash_info_wrapper');
				if (tour_page.length > 0) {
					dash_tour_show_time = setTimeout(function(){tour_page.addClass('tour_active'); tour_wel_div.show()},1000);
					dash_tour_show_info_time = setTimeout(function(){$('.frozr_dash_info_wrapper').addClass('frozr_tour_show_info')},1500);
				}
			}

			/*Dashboard pages*/
			if (current_page.hasClass('ly_dashboard')) {
				if ($('.ly_dash_listing_header > ul.ly_dash_listing_status_filter').length > 0) {
				var page_info = $('.ly_dash_listing_header > ul.ly_dash_listing_status_filter > li.active a', current_page).html();
				$('.ly_dash_listing_header .frozr_filter_info', current_page).html(page_info);
				}
				if (current_page.hasClass('sellers_page')) {
					$('.fs-icon-trophy').removeClass().addClass('material-icons').html('star');
				}
				/*Close filters*/
				$('.frozr_filter_info_wrapper i').css('color', 'black');
				$('.frozr_dash_popup_open').removeClass('frozr_dash_popup_open').hide();
			}
			
		});
	
	},
	app_action_loading: function() {
		$( document.body ).trigger('frozr_body_loading');
		if (refresh !== null) {
		if(check_order_call && check_order_call.readyState != 4){
			check_order_call.abort();
		}
		clearInterval(refresh);
		}
	},
	app_action_loading_complete: function() {
		$( document.body ).trigger('frozr_body_loading_complete');
		if (refresh !== null) {
		if (screenReaderTextDash.manual_online && $('.frozr_vendor_current_status.online').length > 0 || $('.frozr_vendor_notices_status.active').length > 0 && $('.frozr_vendor_current_status.online').length > 0 || $('#orders .orders_lists', current_page).length > 0 && $('.frozr_vendor_current_status.online').length > 0) {
			refresh = setInterval(Frozr_Dashboard_Scripts.check_for_new_orders, 60000);
		}
		}
	},
	display_message: function(msg) {
		$( document.body ).trigger('norsani_display_msg',[msg]);
	},
	frozr_orders_view_options: function(e) {
		e.preventDefault();
		var data = $(this).attr('data-view');
	},
	open_items_actions_menu: function(e) {
		e.preventDefault();
		var wrapper = $(this).parent();
		$('.frozr_item_actions_list.active_list').removeClass('active_list');
		$('.frozr_item_actions_list',wrapper).addClass('active_list');
	},
	update_orders_count: function(e) {
		var data	= {};
		clearTimeout(check_orders_hide_box_time);
		clearTimeout(check_orders_box_remove_time);
		
		if ($('#orders .orders_lists', '.ui-page-active-loaded').length > 0) {
			on_orders_page = true;
		}

		data.action		= 'frozr_update_orders_count';
		data.security	= screenReaderTextDash.update_orders_count_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Dashboard_Scripts.app_action_loading();},
			complete: function() {Frozr_Dashboard_Scripts.app_action_loading_complete();},
			data: data,
			type: 'POST',
			success: function( response ) {
				if(response.error) {
				Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.response.data);
				return false;
				}
				window.localStorage.setItem("lyzvorderscount", parseInt(response.count));
			}, error: function(response) {
				Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.orders_check_error);
			}
		});
	},
	add_var_notice: function(e) {
		e.preventDefault();
		Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.regular_price_notice);
	},
	nav_to_items: function(e,resp) {
		if (resp.linkd) {
		$(':mobile-pagecontainer').pagecontainer("change", resp.linkd);
		}
	},
	nav_to_coupons: function(e,dlink) {
		if (dlink) {
		$(':mobile-pagecontainer').pagecontainer("change", dlink);
		}
	},
	payout_error: function(e,response) {
		if (response.error) {
		var error = response.error;
		var stringfy = JSON.stringify(error);
		console.log(stringfy);
		console.log(response);
		var error_object = JSON.parse(stringfy);			
		if (error_object.message) {
		Frozr_Dashboard_Scripts.display_message(error_object.message);
		} else if(error) {
		Frozr_Dashboard_Scripts.display_message(error);
		} else {
		Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.gen_error_concole);
		console.log(response);
		}
		} else {
		Frozr_Dashboard_Scripts.display_message(screenReaderText.gen_error);
		}
	},
	paid_payout: function(e,response,req_id) {
		if (response.no_result) {
			location.reload(true);
		}
		if (response.message) {
		Frozr_Dashboard_Scripts.display_message(response.message);
		}
		if (response.sts == 'SUCCESS') {
		var wrapper = $('.frozr_dash_withdraw_list'),
		wid_row = $( 'tr[data-id="'+req_id+'"]',wrapper );

		if (response.nav) {
			$.each(response.nav,function(key, value){
				$('.frozr_nav_post_cnt.'+key).html('('+value+')');
			});
			var page_info = $('.ly_dash_listing_header > ul.ly_dash_listing_status_filter > li.active a').html();
			$('.ly_dash_listing_header .frozr_filter_info').html(page_info);
		}
		wid_row.remove();
		}
	},
	canceled_payout: function(e,response,req_id) {
		if (response.no_result) {
			location.reload(true);
		}
		var wrapper = $('.frozr_dash_withdraw_list'),
		payout_row = $( 'tr[data-id="'+req_id+'"]',wrapper );
		if (response.message) {
		Frozr_Dashboard_Scripts.display_message(response.message);
		}
		if (response.nav) {
			$.each(response.nav,function(key, value){
				$('.frozr_nav_post_cnt.'+key).html('('+value+')');
			});
			var page_info = $('.ly_dash_listing_header > ul.ly_dash_listing_status_filter > li.active a').html();
			$('.ly_dash_listing_header .frozr_filter_info').html(page_info);
		}
		payout_row.remove();
	},
	check_payouts: function() {
		var pending_tab_active = $('.active.pending');
		var data_count = pending_tab_active.attr('data-count');
		var data = {};

		clearTimeout(check_orders_hide_box_time);
		clearTimeout(check_orders_box_remove_time);

		if (pending_tab_active.length > 0 && parseInt(data_count) > 0) {
		data.action		= 'frozr_check_withdraws';
		data.security	= screenReaderTextDash.frozr_check_payouts_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Dashboard_Scripts.app_action_loading();Frozr_Dashboard_Scripts.checking_message(screenReaderTextDash.checking_payouts);},
			complete: function() {Frozr_Dashboard_Scripts.app_action_loading_complete();check_orders_hide_box_time = setTimeout(function(){$('.frozr_error_box').css('transform', 'translateY(100%)');}, 1000);check_orders_box_remove_time = setTimeout(function(){$('.frozr_error_box').remove();}, 4000);},
			data: data,
			type: 'POST',
			success: function(response) {
				if (response.no_result) {
					location.reload(true);
				}
				var wrapper = $('.frozr_dash_withdraw_list');
				if (response.nav) {
					$.each(response.nav,function(key, value){
						$('.frozr_nav_post_cnt.'+key).html('('+value+')');
					});
					var page_info = $('.ly_dash_listing_header > ul.ly_dash_listing_status_filter > li.active a').html();
					$('.ly_dash_listing_header .frozr_filter_info').html(page_info);
				}
				if(response.trashed) {
					var trashed_list = response.trashed;
					$.each(trashed_list,function(key, value){
						var wid_row = $('tr[data-id="'+value+'"]',wrapper);
						if (wid_row.length > 0) {
						wid_row.remove();
						}
					});
				}
				if (response.updated) {
					var updated_list = response.updated;
					$.each(updated_list,function(key, value){
						var wid_row = $('tr[data-id="'+key+'"]',wrapper);
						var wid_sts = $('.frozr_payout_sts',wid_row);
						if (wid_row.length > 0 && wid_sts.length > 0) {
						$('span',wid_sts).html(value);
						}
					});
				}
			},
			error: function(response) {
				console.log(response);
				Frozr_Dashboard_Scripts.display_message(screenReaderText.gen_error);
			},
		});
		}
	},
	open_close_order_view: function(e) {
		e.preventDefault();
		var self = $(this);
		var order_id = self.attr('data-ord');
		if ($('.frozr_ord_quick_opened[data-ord="'+order_id+'"]').length > 0) {
		$('.frozr_order_quickview_wrapper[data-ord="'+order_id+'"]').removeClass('frozr_ord_quick_opened').hide();
		} else {
		$('.frozr_order_quickview_wrapper[data-ord="'+order_id+'"]').addClass('frozr_ord_quick_opened').show();
		}
	},
	check_for_new_orders: function() {
		var current_orders_count = Frozr_Dashboard_Scripts.get_orders_count();
		var on_orders_page = 0;
		var data	= {};
		clearTimeout(check_orders_hide_box_time);
		clearTimeout(check_orders_box_remove_time);

		if ($('#orders .orders_lists', '.ui-page-active-loaded').length > 0) {
			on_orders_page = 1;
		}

		data.action		= 'frozr_check_new_orders';
		data.ccount		= current_orders_count;
		data.on_orders	= on_orders_page;
		data.security	= screenReaderTextDash.norsani_check_new_orders;

		check_order_call = $.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Dashboard_Scripts.checking_message(screenReaderTextDash.checking_for_orders);},
			complete: function() {check_orders_hide_box_time = setTimeout(function(){$('.frozr_error_box').css('transform', 'translateY(100%)');}, 1000);check_orders_box_remove_time = setTimeout(function(){$('.frozr_error_box').remove();}, 4000);},
			data: data,
			type: 'POST',
			success: function( response ) {

				if (response.count && null != current_orders_count) {
					var new_count = parseInt(response.count);
					if (new_count > current_orders_count) {
					if (response.notice && $('#frozr_new_order_buzz').length > 0) {
					$('#frozr_new_order_buzz').get(0).play();
					}
					$('.frozr_my_account_link, .woocommerce-MyAccount-navigation-link--vendor_orders i,.woocommerce-MyAccount-navigation-link--vendor_orders a').css('color', 'greenyellow');
					Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.new_order_notice);
					window.localStorage.setItem("lyzvorderscount", new_count);
					} else {
					$('.frozr_my_account_link, .woocommerce-MyAccount-navigation-link--vendor_orders i,.woocommerce-MyAccount-navigation-link--vendor_orders a').attr('style','');
					}
				} else if(response.error) {
				Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.response.data);
				}

				if (response.orders) {
					setTimeout(function(){location.reload(true);}, 2000);
				}

				if (response.count) {
				window.localStorage.setItem("lyzvorderscount", parseInt(response.count));
				}
			}, error: function(response) {
				Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.orders_check_error);
			}
		});
	},
	checking_message: function(msg) {
		clearTimeout(checking_for_orders_message_time);
		$('.ui-page-active').append('<div class="frozr_error_box">' + msg + '</div>');
		checking_for_orders_message_time = setTimeout(function(){$('.frozr_error_box').css('transform', 'translateY(0)')}, 50);
	},
	close_tours: function(e) {
		if(!$(e.target).is('.frozr_dash_info_wrapper, .frozr_dash_info_wrapper *') && $('.frozr_tour_show_info').length > 0) {
			if ( window.confirm( screenReaderTextDash.tour_close_confirm ) ) {
			$('.frozr_tour_show_info').remove();
			} else {
				e.preventDefault();
				return false;
			}
		}
	},
	close_dash_tour: function(e) {
		e.preventDefault();
		var uri = window.location.href.toString();
		if (uri.indexOf("?") > 0) {
			var clean_uri = uri.substring(0, uri.indexOf("?"));
			window.history.replaceState({}, document.title, clean_uri);
		}
		$('.request_tour').removeClass('request_tour tour_active');
		$('.frozr_tour_show_info').remove();
	},
	nav_dash_tour: function(e) {
		e.preventDefault();
		clearTimeout(frozr_vendor_status_link_remove_time);
		jQuery("html, body").animate({scrollTop: jQuery('body').offset().top}, 300);
		
		var self = $(this);
		var page = $('.tour_active');
		var tour_div = $('.frozr_dash_info_wrapper');
		var tour_info = $('.frozr_tour_info');
		var tour_close_btn = $('.frozr_close_tour');
		var tour_next_btn = $('.frozr_tour_next');
		var tour_prev_btn = $('.frozr_tour_prev');
		var next = self.attr('data-next');
		var on_mobile = false;
		if ($('.on-mobile').length >0) {
			on_mobile = true;
		}

		tour_div.removeClass('frozr_tour_show_info');
		page.removeClass('tour_active');

		if (next == 'dash'){
			var next_nav = 'menu';
			if (on_mobile) {
				next_nav = 'menu_btn';
			}		
			setTimeout(function(){
			tour_close_btn.html(screenReaderTextDash.tour_close);
			tour_next_btn.html(screenReaderTextDash.tour_next).show();
			tour_div.removeClass('frozr_tour_welcome');
			tour_next_btn.attr('data-next', next_nav);
			tour_div.removeClass('top_arr').removeClass('bottom_m_arr').addClass('bottom_arr');
			tour_div.css({
				top: '0',
				left: '50%',
				margin: '0 0 0 -8.5em',
			});
			}, 300);
			setTimeout(function(){
			tour_prev_btn.hide();
			tour_info.html('<p>'+screenReaderTextDash.tour_dash_info+'</p>');

			tour_div.addClass('frozr_tour_show_info');}, 750);
		} else if (next == 'menu_btn') {
			if ($('.open_main_menu').length > 0) {
				$( document.body ).trigger('frozr_open_main_menu_trigger');
			}
			tour_next_btn.attr('data-next', 'menu').show();
			tour_prev_btn.attr('data-next', 'dash');
			setTimeout(function(){
			tour_div.removeClass('bottom_arr').removeClass('bottom_m_arr').addClass('top_arr');
			tour_div.css({
				top: '12%',
				margin: '0',
				left: '0',
			});
			}, 300);
			setTimeout(function(){
			tour_prev_btn.show();
			tour_info.html('<p>'+screenReaderTextDash.tour_menu_btn+'</p>');

			tour_div.addClass('frozr_tour_show_info');}, 750);
		} else if (next == 'menu') {
			var prev_nav = 'dash';
			if (on_mobile) {
				prev_nav = 'menu_btn';
			}
			tour_next_btn.attr('data-next', 'actions').show();
			tour_prev_btn.attr('data-next', prev_nav);
			setTimeout(function(){
			tour_div.removeClass('top_arr').removeClass('bottom_arr').removeClass('right_arr').addClass('bottom_m_arr');
			tour_div.css({
				top: '0em',
				margin: '0px',
				left: '2em',
			});
			}, 300);
			setTimeout(function(){
			if (on_mobile) {
			$('.secondary-toggle', document.body).trigger('click');
			}
			setTimeout(function(){
			if ($('.frozr_opened_dash_menu').length == 0) {
			$('.frozr_ly_dash_menu_title', document.body).trigger('click');
			}
			tour_prev_btn.show();
			tour_info.html('<p>'+screenReaderTextDash.tour_menu+'</p>');
			setTimeout(function(){
			tour_div.addClass('frozr_tour_show_info');
			}, 150);
			}, 550);
			}, 750);
		} else if (next == 'actions') {
			if (on_mobile) {
				$( document.body ).trigger('frozr_open_main_menu_trigger');
			}
			tour_next_btn.hide();
			tour_prev_btn.attr('data-next', 'menu');
			setTimeout(function(){
			if (on_mobile) {
			tour_div.removeClass('bottom_m_arr').addClass('top_arr');
			tour_div.css({
				top: '32em',
				margin: '0px',
				left: 'auto',
				right: '7%',
			});
			} else {
			tour_div.removeClass('bottom_m_arr').addClass('right_arr');
			tour_div.css({
				top: '8em',
				margin: '0',
				left: 'auto',
				right: '25%',
			});
			}
			}, 300);
			setTimeout(function(){
			if ($('.frozr_pop_view.frozr_pop_opened').length == 0) {
			$('.frozr_vendor_status_link', document.body).trigger('click');
			}
			setTimeout(function(){
			$('.frozr_vendor_status_link').addClass('tour_clicked');
			frozr_vendor_status_link_remove_time = setTimeout(function(){
			$('.frozr_vendor_status_link').removeClass('tour_clicked');
			}, 5050);
			tour_prev_btn.show();
			tour_info.html('<p>'+screenReaderTextDash.tour_actions_menu+'</p>');

			tour_div.addClass('frozr_tour_show_info');
			}, 250);
			}, 750);

		}
	},
	show_hide_del_additional_fee: function() {
		var value = $(this).attr('value');
		var name = $(this).attr('name');
		if (name == 'deliveryby') {
			if (value == 'item') {
			$('#shipping_pro_adtl_cost').parent().show();
			} else {
			$('#shipping_pro_adtl_cost').parent().hide();
			}
		} else {
			if (value == 'item') {
			$('#shipping_pro_adtl_cost_peak').parent().show();
			} else {
			$('#shipping_pro_adtl_cost_peak').parent().hide();
			}
		}
	},
	show_dash_actions: function(e) {
		e.preventDefault();
		clearTimeout(show_dash_actions_time);
		var wrapper = $(this).parents('.frozr_dash_mobile_actions');
		show_dash_actions_time = setTimeout(function(){
		$('.order_satus_change', wrapper).addClass('frozr_dash_popup_open').show();
		}, 50);
	},
	show_hide_offline_orders: function(e) {
		var wrapper = $(this).parents('.group-opts');
		if ($(this).prop("checked")) {
		$('.frozr_dash_offline_orders_wrapper').show();
		} else {
		$('.frozr_dash_offline_orders_wrapper').hide();
		}
	},
	show_dash_settings_tab: function(e) {
		e.preventDefault();
		var tab = $(this).attr('href');
		var content = $(this).html();
		var wrapper = $(this).parents('.frozr_dash_seller_settings_wrapper');
		$('> ul a', wrapper).removeClass('active');
		$('.group-opts.active', wrapper).removeClass('active');
		$(this).addClass('active');
		$(tab, wrapper).addClass('active');
		$('.frozr_tab_filter_info', wrapper).html(content);
	},
	show_dash_pop: function(e) {
		e.preventDefault();
		var active_link = $(this);
		clearTimeout(show_dash_pop_time);
		var wrapper = active_link.parents('main.site-main');
		var div = active_link.attr('href');
		if (div != '#seller_mgs') {
			show_dash_pop_time = setTimeout(function(){
			$(div, wrapper).addClass('frozr_dash_popup_open').show();
			},50);
		} else {
			var inner_wrapper = active_link.parent();
			var inner_parent_wrapper = active_link.parents('td');
			show_dash_pop_time = setTimeout(function(){
			var msg_div = $('#seller_mgs', wrapper);
			var inner_html = msg_div.html();
			var rest_id = parseInt(active_link.attr('data-userid'));
			var get_rest_data = Frozr_Dashboard_Scripts.get_vendors();
			var rest_data = get_rest_data[rest_id];
			if (rest_data && rest_data.name == '' || !rest_data) {
				rest_data = {name: $('.frozr_dash_sellers_name', inner_parent_wrapper).html()};
			}
			msg_div.remove();
			inner_wrapper.prepend('<div id="seller_mgs" class="common_pop frozr_dash_popup_open" style="display:block">'+inner_html+'</div>');
			$('.frozr_seller_id_msg').val(rest_id);
			$('.frozr_dash_seller_msg_form_title > span', wrapper).html(rest_data.name);
			},100);
		}
	},
	show_dash_settings_tabs: function(e) {
		e.preventDefault();
		clearTimeout(show_dash_settings_tabs_time);
		var wrapper = $(this).parent().parent();
		show_dash_settings_tabs_time = setTimeout(function(){
		$('.frozr_tab_filter_info_wrapper i').css('color', 'red');
		$('.tablist-left', wrapper).addClass('frozr_dash_popup_open').show();
		}, 50);
	},
	show_order_customer: function(e) {
		e.preventDefault();
		clearTimeout(show_order_customer_time);
		var wrapper = $(this).parent();
		show_order_customer_time = setTimeout(function(){
		$('.frozr_dash_order_customer_det', wrapper).addClass('frozr_dash_popup_open').show();
		}, 50);
	},
	show_withdraw_msg_form: function(e) {
		e.preventDefault();
		clearTimeout(show_withdraw_msg_form_time);
		if ($('.frozr_dash_withdraw_msg_open').length > 0) {
		$('.ui-page-active #withdraw_mgs').removeClass('frozr_dash_withdraw_msg_open');
		show_withdraw_msg_form_time = setTimeout(function(){$( ".ui-page-active #withdraw_mgs" ).hide();}, 700);
		} else {
		$( ".ui-page-active #withdraw_mgs" ).show();
		show_withdraw_msg_form_time = setTimeout(function(){$( ".ui-page-active #withdraw_mgs" ).addClass('frozr_dash_withdraw_msg_open');}, 50);
		}
	},
	show_withdraw_edit_form: function(e) {
		e.preventDefault();
		clearTimeout(show_withdraw_edit_form_time);
		var wrapper = $(this).parent();
		show_withdraw_edit_form_time = setTimeout(function(){
		$('.edit_wid', wrapper).addClass('frozr_dash_popup_open').show();
		}, 50);
	},
	show_withdraw_payment_det: function(e) {
		e.preventDefault();
		clearTimeout(show_withdraw_payment_det_time);
		var wrapper = $(this).parent();
		show_withdraw_payment_det_time = setTimeout(function(){
		$('.withdraw_vendor_pop', wrapper).addClass('frozr_dash_popup_open').show();
		}, 50);
	},
	show_withdraw_form: function() {
		if ($('.frozr_dash_new_withdraw_open').length > 0) {
		$('.frozr_dash_new_withdraw').removeClass('frozr_dash_new_withdraw_open').hide();
		$('.frozr_dash_withdraw_list').show();
		} else {
		$('.frozr_dash_new_withdraw').addClass('frozr_dash_new_withdraw_open').show();
		$('.frozr_dash_withdraw_list').hide();
		}
	},
	show_hide_item_sections: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parent();
		if (wrapper.hasClass('frozr_item_section_opened')) {
			wrapper.removeClass('frozr_item_section_opened');
			$('i', self).html('expand_more');
		} else {
		$('.frozr_item_section_opened').removeClass('frozr_item_section_opened');
		wrapper.addClass('frozr_item_section_opened');
		$('.frozr_item_section_opened > h3 i').html('expand_more');
		$('i', self).html('expand_less');
		}
	},
	show_hide_dash_filters: function(e) {
		e.preventDefault();
		clearTimeout(show_hide_dash_filters_time);
		var wrapper = $(this).parent();
		show_hide_dash_filters_time = setTimeout(function(){
		$('.frozr_filter_info_wrapper i').css('opacity', '0.7');
		$('> ul.ly_dash_listing_status_filter', wrapper).addClass('frozr_dash_popup_open').show();
		}, 50);
	},
	change_item_status: function(e) {
		e.preventDefault();
		var data	= {};
		var change_to = $(this).attr('data-change');
		var item_id = $(this).attr('data-id');
		var wrapper = $('#product_'+item_id);

		data.action		= 'frozr_change_item_status';
		data.id			= item_id
		data.stat		= change_to;
		data.security	= screenReaderTextDash.norsani_change_product_status;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Dashboard_Scripts.app_action_loading()},
			complete: function() {Frozr_Dashboard_Scripts.app_action_loading_complete()},
			data: data,
			type: 'POST',
			success: function( response ) {
				if (response.error) {
				Frozr_Dashboard_Scripts.display_message(response.data);
				} else {
					$('.frozr_dash_total_online_items', '.ui-page-active-loaded').html(screenReaderTextDash.online+'('+response.online+')');
					$('.frozr_dash_total_offline_items', '.ui-page-active-loaded').html(screenReaderTextDash.offline+'('+response.offline+')');
					if (change_to == 'publish') {
					$('.frozr_dashitems_title_status, .frozr_dashitems_post_status > label', wrapper).removeClass('offline').addClass('publish').html(screenReaderTextDash.online);
					$('.frozr_dash_product_change_status a', wrapper).attr('data-change', 'offline').html(screenReaderTextDash.make+' '+screenReaderTextDash.offline);
					} else {
					$('.frozr_dashitems_title_status, .frozr_dashitems_post_status > label', wrapper).removeClass('publish').addClass('offline').html(screenReaderTextDash.offline);
					$('.frozr_dash_product_change_status a', wrapper).attr('data-change', 'publish').html(screenReaderTextDash.make+' '+screenReaderTextDash.online);
					}
				}
			}, error: function(response) {
				Frozr_Dashboard_Scripts.display_message(screenReaderText.gen_error);
			}
		});
	},
	add_item_to_special: function(e) {
		e.preventDefault();
		var self = $(this);
		var data	= {};
		var item_id = self.attr('data-id');
		var item_sts = self.attr('data-sts');
		
		data.action		= 'frozr_make_item_special';
		data.item		= item_id;
		data.stat		= item_sts;
		data.security	= screenReaderTextDash.norsani_add_product_special;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Dashboard_Scripts.app_action_loading()},
			complete: function() {Frozr_Dashboard_Scripts.app_action_loading_complete()},
			data: data,
			type: 'POST',
			success: function( response ) {
				if (response.success) {
				Frozr_Dashboard_Scripts.display_message(response.data);
				if (item_sts == 'offline') {
				self.attr('data-sts','online');
				self.parent().addClass('active');
				} else {
				self.attr('data-sts','offline');
				self.parent().removeClass('active');
				}
				} else {
				Frozr_Dashboard_Scripts.display_message(screenReaderText.gen_error);
				console.log(response);
				}
			}, error: function(response) {
				console.log(response);
				Frozr_Dashboard_Scripts.display_message(screenReaderText.gen_error);
			}
		});
	},
	vendor_change_status: function(e) {
		e.preventDefault();
		var data	= {};
		var current_orders_count = Frozr_Dashboard_Scripts.get_orders_count();
		var self = $(this);
		var org_sts = screenReaderTextDash.vendor_orignal_sts;
		var changes = self.attr('data-change');
		var change_what = '';
		var statuss = self.attr('data-sts');
		var statu = '';
		var time = 0;

		if (changes) {
			change_what = changes;
		}
		if (statuss) {
			statu = statuss;
		}
		
		if (change_what == 'status') {
			var info = screenReaderTextDash.offline_status_duration;
			if (statu == 'online') {
				info = screenReaderTextDash.online_status_duration;
			}
			if (org_sts != statu) {
			var dur = Number(window.prompt(info, 60));
			if(dur == 0) {
				return false;
			} else if(!dur) {
				Frozr_Dashboard_Scripts.display_message(screenReaderTextDash.status_dur_error);
				return false;
			} else {
				time = dur;
			}
			}
		}
		data.action		= 'frozr_set_vendor_status';
		data.change		= change_what;
		data.ordscnt	= current_orders_count == null ? 'no' : 'yes';
		data.duration	= time;
		data.stat		= statu;
		data.security	= screenReaderTextDash.norsani_save_vendor_status;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Dashboard_Scripts.app_action_loading()},
			complete: function() {Frozr_Dashboard_Scripts.app_action_loading_complete()},
			data: data,
			type: 'POST',
			success: function(response) {
				if (!response.success) {
				Frozr_Dashboard_Scripts.display_message(response.data);
				} else {
					var orders_count = response.data.order_count;
					var store_sts = $('.frozr_store_status');
					var wrapper = $('.frozr_rest_store_page');
					var vendor = wrapper.attr('data-vendor');
					var vid = response.data.vid;
					if (store_sts.length > 0 && parseInt(vendor) == parseInt(vid) && response.data.rtime) {
						if (response.data.vsts) {
							store_sts.removeClass('closed').addClass('open').html(response.data.rtime);
						} else {
							store_sts.removeClass('open').addClass('closed').html(response.data.rtime);
						}
					}
					if (orders_count != null) {
						window.localStorage.setItem("lyzvorderscount", parseInt(orders_count));
					}
					if (change_what == 'status' || change_what == 'notices') {
					if ($('.frozr_vendor_online').length > 0 || $('.frozr_vendor_notices_status.active').length > 0) {
					if ($('.frozr_vendor_online').length > 0) {
					$('.frozr_vendor_status_link').removeClass('frozr_vendor_online');
					}
					clearInterval(refresh);
					refresh = null;
					} else {
					if (!$('.frozr_vendor_online').length > 0) {
					$('.frozr_vendor_status_link').addClass('frozr_vendor_online');
					}
					if (refresh === null) {
					refresh = setInterval(Frozr_Dashboard_Scripts.check_for_new_orders, 60000);
					}
					}
					}
					$('.frozr_vendor_status_menu_wrapper').html(response.data.data);
				}
			}, error: function(response) {
				Frozr_Dashboard_Scripts.display_message(screenReaderText.gen_error);
			}
		});
	},
	close_filters: function(e){
		clearTimeout(withdraw_msg_hide_time);

		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.frozr_dash_new_withdraw_open, .frozr_dash_new_withdraw_open *, .new_withdraw, .new_withdraw *') && $('.frozr_dash_new_withdraw_open').length > 0) {
			Frozr_Dashboard_Scripts.show_withdraw_form();
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.frozr_dash_popup_open:not(.tablist-left), .frozr_dash_popup_open:not(.tablist-left) *,.media-modal,.media-modal *,.frozr_gen_help_box, .frozr_gen_help_box *,.frozr_popup_help_wrapper,.frozr_popup_help_wrapper *,.frozr_content_block') && $('.frozr_dash_popup_open').length > 0) {
			$('.frozr_tab_filter_info_wrapper i, .frozr_filter_info_wrapper i').css('color', 'black');
			$('.frozr_dash_popup_open').removeClass('frozr_dash_popup_open').hide();
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,#withdraw_mgs, #withdraw_mgs *, .withdraw_requester_msg_wid, .withdraw_requester_msg_wid *') && $('.frozr_dash_withdraw_msg_open').length > 0) {
			$('.ui-page-active #withdraw_mgs').removeClass('frozr_dash_withdraw_msg_open');
			withdraw_msg_hide_time = setTimeout(function(){$( ".ui-page-active #withdraw_mgs" ).hide();}, 700);
		}
		if(!$(e.target).is('.dash_tables_actions > i') && $('.frozr_item_actions_list.active_list').length > 0) {
			$('.frozr_item_actions_list.active_list').removeClass('active_list');
		}
	},
	open_dash_menu: function(e){
		e.preventDefault();
		var menu_height = $('.frozr_dash_menu_wrapper > ul').height();
		if ($('.frozr_opened_dash_menu').length > 0) {
		$( ".usr_dash_menu_content" ).removeClass('frozr_opened_dash_menu');
		$( ".frozr_dash_menu_wrapper" ).css('height','0');
		} else {
		$( ".usr_dash_menu_content" ).addClass('frozr_opened_dash_menu');
		$( ".frozr_dash_menu_wrapper" ).css('height',menu_height+'px');
		}
	},
	get_vendors: function(vendors_type) {
		var len = window.localStorage.getItem("lyzvendors");
		var lenall = window.localStorage.getItem("lyzvendorsall");

		if (!len || len == 'undefined' || len == null) {
			return false;
		}

		var vendors = JSON.parse(len);

		if ($.isArray(vendors) && vendors.length < 1) {
			no_vendors_yet = true;
			return false;
		}

		no_vendors_yet = false;
		var vendors_all = JSON.parse(lenall);

		if (vendors_type) {
			return vendors_all[vendors_type];
		}
		return vendors;
	},
	get_orders_count: function () {
		var len = window.localStorage.getItem("lyzvorderscount");

		if (len == 'undefined' || len == null) {
			return null;
		}
		return parseInt(len);
	},
	};
	Frozr_Dashboard_Scripts.init();

})( jQuery );
