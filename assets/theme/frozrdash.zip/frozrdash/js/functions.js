/* global screenReaderText */
/**
 * Theme functions file.
 *
 */

( function( $ ) {
var file_frame,
	setted_store_name,
	reg_user_profile,
	product_featured_frame,
	fro_gen_fav_cll,
	fro_gen_src_cll,
	fro_save_item_views,
	timeoutHandle,
	open_quick_cart,
	open_close_filters,
	rrstimeoutHandle,
	display_msg_time,
	display_msg_interval,
	display_msg_hide_time,
	open_rests_contact_box_time,
	show_gen_src_input_time,
	open_main_menu_time,
	rests_filters_dragged_time,
	close_user_menu_time,
	open_user_menu_time,
	preload_remove_time,
	preload_class_remove_time,
	geolocate_user_time,
	vendors_tools_show_time,
	activate_pop_inputs_time,
	item_view_time,
	isIOS = /iPhone|iPad|iPod/.test( navigator.userAgent ),
	isAndroid = navigator.userAgent.indexOf( 'Android' ) !== -1,
	isIE8 = $( document.documentElement ).hasClass( 'ie8' ),
	specials_slider = 0,
	specials_wrapper,
	specials_list,
	specials_first_item,
	specials_last_item,
	$sidebarMenuWrap,
	$window,
	body,
	pinnedMenuTop = false,
	lastScrollPosition = 0,
	menuTop = 0,
	pinnedMenuBottom = false,
	windowWidth,
	resizeTimer,
	$document,
	adminbarOffset,
	upsell_wrapper_width,
	active_page_id,
	no_vendors_yet = true,
	check_for_vendors_time,
	distance_container;
	
var Frozr_Scripts = {
	init: function() {
		var self = this;
		var rests_loaded = self.rests_data_session();
		var theme_color = screenReaderText.color_scheme;
		var icon_color = 'dark';
		if (theme_color == 'purple' || theme_color == 'dark') {
			icon_color = 'light';
		}

		/*Get all vendors*/
		if (!rests_loaded && screenReaderText.norsani_exisit == 1) {
			self.load_norsani_rests();
		}

		/*Int main menu*/
		self.initMainNavigation( $( '.main-navigation' ) );
		/*menu icons*/
		$( '.nor_br_menu > a' ).prepend( '<span class="nor_br_menu_icon_'+icon_color+'"></span>' );
		$( '.nor_bc_menu > a' ).prepend( '<span class="nor_bc_menu_icon_'+icon_color+'"></span>' );
		$( '.nor_bg_menu > a' ).prepend( '<span class="nor_bg_menu_icon_'+icon_color+'"></span>' );
		$( '.nor_bft_menu > a' ).prepend( '<span class="nor_bft_menu_icon_'+icon_color+'"></span>' );
		$( '.nor_vr_menu > a' ).prepend( '<i class="material-icons">assignment</i>' );
		$( '.nor_gn_menu > a' ).prepend( '<i class="material-icons">search</i>' );

		/*Change jquery mobile loader*/
		$.mobile.loader.prototype.options.html = "<div class=\"progress\"><div class=\"indeterminate\"></div></div>";
		
		/*Disable Ajax if option is selected*/
		if(screenReaderText.ajax_nav == 1) {
		jQuery("a, form, button, input, .ui-link").attr({"data-enhance": "false", "data-ajax": "false"});
		}
		
		/*get the document*/
		$document = $( document );
		
		/*Remove Preloader*/
		$(window).bind('load', function(){
			if (screenReaderText.norsani_exisit == 1) {
			clearTimeout(preload_class_remove_time);
			clearTimeout(preload_remove_time);
			if (!$('#preload_page').hasClass('hideload')) {
				$('#general_page').attr('style', '');
				preload_class_remove_time = setTimeout(function(){$('#preload_page').addClass('hideload')}, 500);
				preload_remove_time = setTimeout(function(){$('#preload_page').remove();}, 2000);
			}
			} else {
				$('.frozr_preloader_inner').append('<div class="frozr_norsani_not_found">'+screenReaderText.norsani_not_exisit+'</div>');
			}
		});
		if (screenReaderText.norsani_exisit != 1) {
			return false;
		}
		
		$( document.body )
		// Re-initialize the main navigation when it is updated, persisting any existing submenu expanded status.
		.on( 'customize-preview-menu-refreshed', self.reinitMainNavigation)
		/*General*/
		.on('click', self.close_popups)
		.on('focus', 'input, textarea', self.hide_cart_on_focus)
		.on('focusout', 'input, textarea', self.show_cart_on_focusout)
		.on('focus', '.frozr_home_search_btn', self.show_gen_src_input)
		.on("click", ".frozr_general_src_btn", self.show_gen_src_input)
		.on("click", ".general_fav_btn", self.show_gen_fav_input)
		.on("click", ".external_page_title i", self.hide_gen_fav_input)
		.on("click", ".frozr_gen_src_box i", self.hide_gen_src_input)
		.on('keyup', '.frozr_gen_src', self.frozr_general_src_get)
		.on('submit', '.frozr_gen_search_form', self.frozr_general_src_get)
		.on('click', '.frozr_usr_fav_items a', self.frozr_show_items_gen_fav)
		.on('click', '.frozr_usr_fav_rests a', self.frozr_show_rests_gen_fav)
		.on('click', '.frozr_gen_tab_items a', self.frozr_show_items_gen_src)
		.on('click', '.frozr_gen_tab_rests a', self.frozr_show_rests_gen_src)
		.on('click', '.frozr_user_menu_trigger', self.open_user_menu)
		.on('click', '.secondary-toggle', self.open_main_menu)
		.on('frozr_open_main_menu_trigger', self.open_main_menu)
		.on('frozr_body_loading',self.app_action_loading)
		.on('frozr_body_loading_complete',self.app_action_loading_complete)
		.on('norsani_display_msg',self.display_norsani_message)
		.on('frozrdash_general_popup',self.show_frozrdash_general_popup_box)
		.on('frozrdash_general_popup_hide',self.hide_frozrdash_general_popup_box)
		/*Today's specials*/
		.on('click','.frozr_specials_right', self.ts_nav_right)
		.on('click','.frozr_specials_left', self.ts_nav_left)
		/*vendor registration*/
		.on('change', '#fro_reg_sel_tos', self.open_reg_form)
		.on('change', '#accepted_delivery', self.show_hide_del_form)
		.on('click', '.frozr_reg_next, .frozr_reg_back', self.open_next_reg_form)
		.on('click', '.frozr_reg_form_submit', self.trigger_submit_reg_form)
		.on('submit', '.frozr_registration_form', self.submit_reg_form)
		.on('focusout', '#frozr_reg_email, #frozr_vendor_shopname_name', self.check_field_availability)
		/*Product add to cart*/
		.on('click', '.frozr_item_add_to_cart,.frozr_related_item_link', self.open_item_atc_popup)
		.on("change", ".cart .wc-radios", self.show_adtl_input)
		.on("submit", "form.ajax_lazy_submit", self.add_to_cart)
		.on('click', '.remove_qty', self.remove_atc_qty)
		.on('click', '.add_qty', self.add_atc_qty)
		.on('click', '.item_atc_popup .wc-radios > li', self.show_active_order_type)
		.on('click', '.frozr_upsel_nav_right', self.popup_upsell_nav_right)
		.on('click', '.frozr_upsel_nav_left', self.popup_upsel_nav_left)
		/*User location*/
		.on("click",'.user_geo_location_list', self.location_input_click)
		.on("focusout",'.user_geo_location_list', self.location_input_focusout)
		.on("click",'.frozr_set_loc_pop_link', self.geo_locate_me)
		.on("lylocaftersave", self.user_location_set_manual)
		/*WooCommerce*/
		.on('click','.woocommerce-store-notice__dismiss-link', self.dismiss_woo_store_notice)
		/*Expand/Collaps cart*/
		.on("click", ".frozr_view_cart, .frozr_close_cart", self.open_close_cart)
		/*Shop*/
		.on("change", ".woocommerce-ordering select.orderby", self.auto_order_shop_items)
		/*Vendors Page*/
		.on("click", ".rest_filters", self.open_close_filter)
		.on("click", ".rests_search", self.show_rest_src_input)
		.on("click", ".orderby_reco_rests", self.add_reco_rests)
		.on("click", ".orderby_all_rests", self.add_home_rests)
		.on("click", ".orderby_top_rated_rests", self.add_top_rests)
		.on("keyup", ".rests_src_box input", self.run_rests_src)
		.on("click", self.close_filters)
		.on('dragged.owl.carousel', '.home_filter', self.rests_filters_dragged)
		.on('click', '.frozr_filter_by_distance_wrapper', self.filter_vendors_distance)
		.on('click', '.frozr_no_vend_location_set', self.show_location_form)
		/*Store page*/
		.on('click', '.frozr_store_contact_btn', self.open_rests_contact_box)
		/*Cart*/
		.on('click', '.remove_from_cart_button', self.remove_cart_item)
		/*Fav items*/
		.on('click','.orderby_fav_rests', self.add_fav_rests)
		.on('click','.add_item', self.add_remove_fav_item)
		.on('click','.add_rest', self.add_remove_fav_rest)
		/*General help*/
		.on('click', '.frozr_popup_help_wrapper > a', self.show_hide_general_help_box)
		/*single item page*/
		.on( 'click', '.wc-tabs li a', self.switch_tabs)
		/*Review link*/
		.on( 'click', 'a.woocommerce-review-link', self.int_review_input)
		/*Star ratings for comments*/
		.on( 'click', '#respond p.stars a', self.click_rating)
		.on( 'submit', '#commentform', self.submit_comment)
		/*product gallery*/
		.on( 'click', '.frozr_product_gallery_single_image_wrapper > img', self.active_product_img)
		/*checkout*/
		.on('keypress', '.woocommerce-checkout input, .woocommerce-checkout select', self.disable_enter_click_on_checkout);
		
		/*Page events*/
		$document.on( "pagecontainerbeforechange", function( event, ui ) {
			var current_page = ui.prevPage;
			var current_location = window.location.pathname;
			if (current_page) {
				current_location = current_page[0].baseURI;
			}
			var elem = $('body').find(ui.options.link).first();
			if (!ui.options.link && elem.length == 0) {
			var have_open_popup = $('.item_atc_popup_open,.frozr_expand_cart,.open_rest_contact,.open_filter_box,.frozr_dash_popup_open');
			if (have_open_popup.length > 0) {
				Frozr_Scripts.close_filters(event);
				event.preventDefault();
				history.pushState(null, null, current_location);
				return false;
			}
			}
		});
		$document.on( "pagecontainerbeforehide", function( event, ui ) {
			var current_page = ui.prevPage.attr('id');
			$('#'+current_page).removeClass('ui-page-active-loaded');
		});
		$document.on( "pagecontainertransition", function( event, ui ) {
			var current_page_id = ui.toPage.attr('id');
			var current_page = $('#'+current_page_id);
			var is_tablet = screenReaderText.is_tablet;
			current_page.addClass('ui-page-active-loaded');
			specials_wrapper = $('.frozr_specials_list');
			specials_list = $('li',specials_wrapper);
			specials_first_item = $('li:first-child',specials_wrapper);
			specials_last_item = $('li:last-child',specials_wrapper);
			
			/*main menu vars*/
			$window	= $(window);
			windowWidth = $window.width();
			$sidebarMenuWrap = $( '#sidebar' ).first();
			$body = $( document.body );
			adminbarOffset = $body.is( '.admin-bar' ) ? $( '#wpadminbar' ).height() : 0;
			
			/*set body min height*/
			Frozr_Scripts.set_body_min_height();
			
			/*scrolling*/
			$(this).on('scroll', self.pinMenu);
			$window.on('resize', function() {
				windowWidth = $(window).width();
				clearTimeout( resizeTimer );
				resizeTimer = setTimeout( self.resizeAndScroll, 500 );
			});
			$sidebarMenuWrap.on( 'click keydownn', 'button', self.resizeAndScroll );
			
			/*Set interval for special items*/
			var sp_ul = $('.frozr_specials_list > li');
			var container_width = $('.frozr_slides_content').width();
			if (sp_ul.length > 0) {
				var nav_l_width = $('.frozr_specials_left').width();
				var nav_r_width = $('.frozr_specials_right').width();
				var slider_width = container_width - nav_l_width - nav_r_width;
				if (is_tablet) {
				$('.frozr_specials_list li.active').width(slider_width/2);
				} else {
				$('.frozr_specials_list li.active').width(slider_width);
				}
			if (is_tablet && sp_ul.length > 2 || !is_tablet && sp_ul.length > 1) {
				if (specials_slider == 0) {
				specials_slider = setInterval(Frozr_Scripts.ts_auto_click, 5000);
				}
			} else {
				clearInterval(specials_slider);
				specials_slider = 0;
				$("li:not('.active')",'.frozr_specials_list').addClass('active').width(container_width);;
				$('.frozr_specials_left,.frozr_specials_right').hide();
			}
			} else {
				clearInterval(specials_slider);
				specials_slider = 0;
				$('.frozr_special_items_wrapper').hide();
			}
			
			/*refresh upsells if we are in cart page*/
			if ($('#ly_rest_cart_form',current_page).length > 0) {
				Frozr_Scripts.set_upsel_widths(current_page);
			}

			/*Store page*/
			if (current_page.hasClass('frozr_rest_store_page')) {
			Frozr_Scripts.get_delivery_details();
			}
			
			/*Single item page*/
			if (current_page.hasClass('frozr_single_item')) {
				var view_saved = Frozr_Scripts.item_view_saved();
				if (!view_saved) {view_saved = [];}
				clearTimeout(item_view_time);
				if(fro_save_item_views && fro_save_item_views.readyState != 4){
					fro_save_item_views.abort();
				}
				var item_id_txt = $('.product.type-product',current_page).attr('id');
				var item_id = item_id_txt.replace(/^\D+/g,'');
				if (item_id) {
				if ($.inArray(parseInt(item_id),view_saved) < 0) {
				var data = {};
				item_view_time = setTimeout(function(){
				data.itemid		= parseInt(item_id);
				data.action		= 'frozr_save_item_view_count';
				data.security	= screenReaderText.frozr_add_new_page_count_nonce;

				fro_save_item_views = $.ajax({
					url: screenReaderText.ajax_url,
					beforeSend: function() {Frozr_Scripts.app_action_loading();},
					complete: function() {Frozr_Scripts.app_action_loading_complete();},
					data: data,
					type: 'POST',
					success: function(response) {
					view_saved.push(parseInt(item_id));
					window.localStorage.setItem("lyzitemview", JSON.stringify(view_saved));
					},
					error: function() {
						Frozr_Scripts.display_message(screenReaderText.gen_error);
					},
				});
				}, 1100);
				}
				}
			}
			
		});
		$document.on( "pagecontainerbeforeshow", function( event, ui ) {
			var current_page_id = ui.toPage.attr('id');
			var current_page = $('#'+current_page_id);
			var user_notice_option = window.localStorage.getItem("store_notice");
			active_page_id = current_page_id;
			
			/*Hide sections and filters of previous page*/
			Frozr_Scripts.hide_gen_src_input();
			Frozr_Scripts.close_user_menu();
			Frozr_Scripts.hide_gen_fav_input();
			
			/*hide minicart if we're on cart and checkout*/
			if ($('.woocommerce-checkout, #ly_rest_cart_form',current_page).length > 0) {
			$('.frozr_mobile_cart').addClass('frozr_hide');
			current_page.addClass('no_cart');
			} else if ($('.frozr_mobile_cart.frozr_hide').length > 0){
			$('.frozr_mobile_cart').removeClass('frozr_hide');
			}
			/*Hide minicart*/
			if($('.frozr_expand_cart').length > 0) {
			Frozr_Scripts.open_close_cart();
			}

			/*Hide atc popup*/
			Frozr_Scripts.close_atc_popup();
			
			/*Hide main menu*/
			if (screen.width < 955 && $('.open_main_menu').length > 0 || screenReaderText.theme_is_one_column > 0 && $('.open_main_menu').length > 0) {
			Frozr_Scripts.open_main_menu();
			}
			
			/* Check the value of that cookie and show/hide the notice accordingly*/
			if ( 'hidden' === user_notice_option ) {
				$( '.woocommerce-store-notice' ).hide();
			} else {
				$( '.woocommerce-store-notice' ).show();
			}

			/*Show hide search and fav icons from top bar*/
			if($('.frozr_gen_src_wrapper',current_page).length == 0) {
				$('.frozr_general_src_btn').hide();
			} else {
				$('.frozr_general_src_btn').show();
			}
			if ($('.frozr_usr_fav_wrapper',current_page).length == 0) {
				$('.general_fav_btn').hide();
			} else {
				$('.general_fav_btn').show();
			}

			/*Store page*/
			if (current_page.hasClass('frozr_rest_store_page')) {
				var store_menu_type = $('.frozr_store_page_menu_wrapper',current_page);
				if ($('.on-mobile').length > 0) {
				$('.frozr_site_navbar').addClass('store_page');
				setted_store_name = false;
				$(document).bind('scroll', self.pin_rest_top_bar);
				}
				Frozr_Scripts.search_store_favs();
				if (store_menu_type.length > 0) {
				store_menu_type.owlCarousel({
					items:1,
					rtl: screenReaderText.frozr_rtl == 1 ? true : false,
					nav: false,
					center: true,
					dots: false,
				});
				
				var active_menu = $('.fl_activated', current_page);
				if (active_menu.length > 0) {
					var active_key = active_menu.attr('data-wrapper');
					var menu_pos = active_menu.attr('data-pos');
					store_menu_type.trigger('to.owl.carousel', menu_pos);
					Frozr_Scripts.search_meal_type(active_key,current_page);
				}

				store_menu_type.on('dragged.owl.carousel', function (e) {
					var celement = e.item.index,
						dragged_item= false,
						count_loop	= 0,
						list = $('.owl-item', store_menu_type);					
					
					list.each(function(){
						dragged_item = $(this);
						if (count_loop == celement) {
							return false
						} else {
							count_loop++;
						}
					});
					var filter_key = $('li',dragged_item).attr('data-wrapper');
					Frozr_Scripts.search_meal_type(filter_key,current_page);
				});
				}
			} else if($('.store_page').length) {
				$('.frozr_site_navbar').removeClass('store_page');
			}
			
			/*We're on the item page*/
			if (current_page.hasClass('frozr_single_item')) {
				Frozr_Scripts.int_tabs(event);
			}

			/*Vendors page*/
			clearTimeout(vendors_tools_show_time);
			if (current_page.hasClass('vendors_archive')) {
				$('.vendors_tools').show();
				vendors_tools_show_time = setTimeout(function(){$('.vendors_tools').addClass('filter_tools_show')}, 50);
				var vendors_type = Frozr_Scripts.get_active_vendors_page();
				var top_rests_content = Frozr_Scripts.get_top_rests();
				$('.home_filter').owlCarousel({
					items:1,
					rtl: screenReaderText.frozr_rtl == 1 ? true : false,
					nav: false,
					center: true,
					dots: false,
				});
				if($.isEmptyObject(top_rests_content)) {
					$('.orderby_top_rated_rests').parent().hide();
				}

				Frozr_Scripts.add_home_rests(event, false,vendors_type);
			} else {
				$('.vendors_tools').removeClass('filter_tools_show');
				vendors_tools_show_time = setTimeout(function(){$('.vendors_tools').hide();}, 250);
			}
						
			/*Hide header if empty*/
			if ($('header.page-header > *', current_page).length === 0) {
				$('header.page-header', current_page).hide();
			}
			
			/*Set page title*/
			var page_title = $('div[data-id="finde"]', current_page).html();
			$('.frozr_page_title .main_title').html(page_title);
			
			/*initialize scripts*/
			if (current_page.data('id') === 'shop') {
			} else {
			}
			
			if (current_page.hasClass('frozr_single_item') && current_page.data('id') !== 'shop') {
				
				/*remove product sharing if empty*/
				if ($('.frozr_product_sharing div', current_page).length === 0) {
					$('.frozr_product_sharing div', current_page).remove();
				}

				// Target quantity inputs on product pages
				$( 'input.qty:not(.product-quantity input.qty)', current_page ).each( function() {
					var min = parseFloat( $( this ).attr( 'min' ) );

					if ( min >= 0 && parseFloat( $( this ).val() ) < min ) {
						$( this ).val( min );
					}
				});
			}

			/*disable ajax*/
			$('.widget_meta a, .frozr_checkout, .button.checkout').attr('data-ajax', 'false');
			$('.edit-link a, .woocommerce-form-login, .register, a[rel="nofollow"]', current_page).attr('data-ajax', 'false');
			if ($('.checkout-button', current_page).length > 0) {
				$('.checkout-button', current_page).attr('data-ajax', 'false');
			}
			if ($('.woocommerce-checkout', current_page).length > 0) {
				$('.woocommerce-form-login, .checkout_coupon, .woocommerce-checkout', current_page).attr('data-ajax', 'false');
			}
			
			/*Add page class*/
			if (current_page_id !== 'primary') {
			var bodyclass = $('div[data-id="finde"]', current_page).attr('class');
			$('body').attr('class', bodyclass);
			}

		});
	},
	disable_enter_click_on_checkout: function(e) {
		if (e.keyCode == 13) {
			var inputs = $(this).parents("form").eq(0).find(":input");
			var idx = inputs.index(this);

			if (idx == inputs.length - 1) {
				inputs[0].select();
			} else {
				inputs[idx + 1].focus();
				inputs[idx + 1].select();
			}
			return false;
		}
	},
	set_body_min_height: function() {
		if ( 955 < windowWidth) {
			var sidebar_height = $sidebarMenuWrap.height();
			if ($window.height() > sidebar_height) {
				sidebar_height = $window.height();
			} else {
			}
			$('.frozr_general_wrapper').css('min-height',sidebar_height+'px');
		}
	},
	active_product_img: function(e) {
		e.preventDefault();
		var self = $(this);
		var larg_img_url = self.attr('data-large_image');
		$('.frozr_product_image_full','.ui-page-active').attr('style','background-image:url('+larg_img_url+')');
	},
	submit_comment: function(e) {
		e.preventDefault();
		/*Check if its a rating comment*/
		var $rating = $( this ).closest( '#respond' ).find( '#rating' ),
			rating  = $rating.val();

		if ( $rating.length > 0 && ! rating && screenReaderText.review_rating_required === 'yes' ) {
			window.alert( screenReaderText.i18n_required_rating_text );
			return false;
		}
		
		var data		= {};
		data			= $(this).serializeJSON();
		data.action		= 'frozr_post_comment';
		data.security	= screenReaderText.post_comment_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {$( document.body ).trigger('frozr_body_loading');},
			complete: function() {$( document.body ).trigger('frozr_body_loading_complete');},
			data: data,
			type: 'POST',
			success: function( response ) {
				$( document.body ).trigger('norsani_display_msg',[response.message]);
				if(response.error) {
				return false;
				}
				location.reload(true);
			}, error: function(erre) {
				console.log(erre);
			}
		});
	},
	click_rating: function() {
		var $star   	= $( this ),
			$rating 	= $( this ).closest( '#respond' ).find( '#rating' ),
			$container 	= $( this ).closest( '.stars' );

		$rating.val( $star.text() );
		$star.siblings( 'a' ).removeClass( 'active' );
		$star.addClass( 'active' );
		$container.addClass( 'selected' );

		return false;
	},
	int_review_input: function() {
		$( '#rating' ).hide().before( '<p class="stars"><span><a class="star-1" href="#">1</a><a class="star-2" href="#">2</a><a class="star-3" href="#">3</a><a class="star-4" href="#">4</a><a class="star-5" href="#">5</a></span></p>' );
		$( '.reviews_tab a' ).click();
	},
	switch_tabs: function(e,clicked_element) {
		e.preventDefault();
		var $tab          = clicked_element ? clicked_element : $( this );
		var $tabs_wrapper = $tab.closest( '.woocommerce-tabs' );
		var $tabs         = $tabs_wrapper.find( '.wc-tabs' );
		
		$tabs.find( 'li' ).removeClass( 'active' );
		$tabs_wrapper.find( '.wc-tab, .panel:not(.panel .panel)' ).hide();

		$tab.closest( 'li' ).addClass( 'active' );
		$tabs_wrapper.find( $tab.attr( 'href' ) ).show();
	},
	int_tabs: function(e) {
		$('.wc-tab, .woocommerce-tabs .panel:not(.panel .panel)','#'+active_page_id).hide();

		var hash  = window.location.hash;
		var url   = window.location.href;
		var $tabs_wrapper = $('.woocommerce-tabs','#'+active_page_id);
		var $tabs = $tabs_wrapper.find('.wc-tabs').first();

		if (hash.toLowerCase().indexOf('comment-') >= 0 || hash === '#reviews' || hash === '#tab-reviews') {
			Frozr_Scripts.switch_tabs(e,$tabs.find('li.reviews_tab a'));
		} else if ( url.indexOf('comment-page-') > 0 || url.indexOf('cpage=') > 0 ) {
			Frozr_Scripts.switch_tabs(e,$tabs.find('li.reviews_tab a'));
		} else if (hash === '#tab-additional_information') {
			Frozr_Scripts.switch_tabs(e,$tabs.find('li.additional_information_tab a'));
		} else {
			Frozr_Scripts.switch_tabs(e,$tabs.find('li:first a'));
		}
	},
	popup_upsell_nav_right: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parent();
		var container_width = upsell_wrapper_width
		var item_width = screenReaderText.is_mobile ? container_width/2 : container_width/4;
		$('.frozr_upsell_single_item.frozr_upsel_show',wrapper).first().removeClass('frozr_upsel_show').width(0);
		var unactive = $('.frozr_upsell_single_item.frozr_upsel_show',wrapper).last().next();
		if(unactive.length > 0) {
			unactive.addClass('frozr_upsel_show').width(item_width);
			$('.frozr_upsel_nav_left',wrapper).attr('style','');
		}
		if (unactive.next().length == 0) {
			self.css({'opacity':'0.2','pointer-events':'none'});
		}
	},
	popup_upsel_nav_left: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parent();
		var container_width = upsell_wrapper_width;
		var item_width = screenReaderText.is_mobile ? container_width/2 : container_width/4;
		$('.frozr_upsell_single_item.frozr_upsel_show',wrapper).last().removeClass('frozr_upsel_show').width(0);
		var unactive = $('.frozr_upsell_single_item.frozr_upsel_show',wrapper).first().prev();
		if(unactive.length > 0) {
			unactive.addClass('frozr_upsel_show').width(item_width);
			$('.frozr_upsel_nav_right',wrapper).attr('style','');
		}
		if (unactive.prev().length == 0) {
			self.css({'opacity':'0.2','pointer-events':'none'});
		}
	},
	app_action_loading: function() {
		$('.ui-loader').loader("show");
	},
	app_action_loading_complete: function() {
		$(".ui-loader").loader( "hide" );
	},
	ts_nav_left: function(e) {
		e.preventDefault();
		/*Stop the auto slide*/
		clearInterval(specials_slider);
		specials_slider = 0;
		var is_tablet = screenReaderText.is_tablet;
		var nav_l_width = $('.frozr_specials_left').width();
		var nav_r_width = $('.frozr_specials_right').width();
		var container_width = $('.frozr_slides_content').width();
		var slider_width = container_width - nav_l_width - nav_r_width;
		
		var specials_active_item = $('.frozr_specials_item.active').last(),
		specials_prev_item = specials_active_item.prev(),
		specials_prev_prev_item = specials_prev_item.prev();
		
		$('.active',specials_wrapper).removeClass('active').width(0);
		if (is_tablet && specials_list.length > 2) {
		if (specials_prev_prev_item.length > 0 && specials_prev_prev_item.hasClass('frozr_specials_item')) {
			specials_prev_item.addClass('active').width(slider_width/2);
			specials_prev_prev_item.addClass('active').width(slider_width/2);
		} else if (specials_prev_item.length > 0 && specials_prev_prev_item.hasClass('frozr_specials_item')) {
			specials_prev_item.addClass('active').width(slider_width/2);
			specials_first_item.addClass('active').width(slider_width/2);
		} else {
			specials_first_item.addClass('active').width(slider_width/2);
			specials_last_item.addClass('active').width(slider_width/2);
		}
		} else if (is_tablet && specials_list.length <= 2) {
			if (specials_list.length < 2) {
			var cwidth = slider_width;
			} else {
			var cwidth = slider_width/2;
			}
			$("li:not('.active')",specials_wrapper).addClass('active').width(cwidth);
			$('.frozr_specials_left,.frozr_specials_right').hide();
		} else {
		if (specials_prev_item.length > 0 && specials_prev_item.hasClass('frozr_specials_item')) {
			specials_prev_item.addClass('active').width(slider_width);
		} else {
			specials_last_item.addClass('active').width(slider_width);
		}
		}
	},
	ts_auto_click: function() {
		var is_tablet = screenReaderText.is_tablet;

		var nav_l_width = $('.frozr_specials_left').width();
		var nav_r_width = $('.frozr_specials_right').width();
		var container_width = $('.frozr_slides_content').width();
		var slider_width = container_width - nav_l_width - nav_r_width;

		var specials_active_item = $('.frozr_specials_item.active').last(),
		specials_next_item = specials_active_item.next(),
		specials_next_next_item = specials_next_item.next();
		
		$('.active',specials_wrapper).removeClass('active').width(0);
		if (is_tablet && specials_list.length > 2) {
		if (specials_next_next_item.length > 0 && specials_next_next_item.hasClass('frozr_specials_item')) {
			specials_next_item.addClass('active').width(slider_width/2);
			specials_next_next_item.addClass('active').width(slider_width/2);
		} else if (specials_next_item.length > 0 && specials_next_next_item.hasClass('frozr_specials_item')) {
			specials_next_item.addClass('active').width(slider_width/2);
			specials_first_item.addClass('active').width(slider_width/2);
		} else {
			specials_first_item.addClass('active').width(slider_width/2);
			specials_first_item.next().addClass('active').width(slider_width/2);
		}
		} else if (is_tablet && specials_list.length <= 2) {
			if (specials_list.length < 2) {
			var cwidth = slider_width;
			} else {
			var cwidth = slider_width/2;
			}
			$("li:not('.active')",specials_wrapper).addClass('active').width(cwidth);
			$('.frozr_specials_left,.frozr_specials_right').hide();
		} else {
		if (specials_next_item.length > 0 && specials_next_item.hasClass('frozr_specials_item')) {
			specials_next_item.addClass('active').width(slider_width);
		} else {
			specials_first_item.addClass('active').width(slider_width);
		}
		}
	},
	ts_nav_right: function(e) {
		e.preventDefault();
		/*stop the auto slide*/
		clearInterval(specials_slider);
		specials_slider = 0;
		var is_tablet = screenReaderText.is_tablet;
		
		var nav_l_width = $('.frozr_specials_left').width();
		var nav_r_width = $('.frozr_specials_right').width();
		var container_width = $('.frozr_slides_content').width();
		var slider_width = container_width - nav_l_width - nav_r_width;
		
		var specials_active_item = $('.frozr_specials_item.active').last(),
		specials_next_item = specials_active_item.next(),
		specials_next_next_item = specials_next_item.next();			
		
		$('.active',specials_wrapper).removeClass('active').width(0);
		if (is_tablet && specials_list.length > 2) {
		if (specials_next_next_item.length > 0 && specials_next_next_item.hasClass('frozr_specials_item')) {
			specials_next_item.addClass('active').width(slider_width/2);
			specials_next_next_item.addClass('active').width(slider_width/2);
		} else if (specials_next_item.length > 0 && specials_next_next_item.hasClass('frozr_specials_item')) {
			specials_next_item.addClass('active').width(slider_width/2);
			specials_first_item.addClass('active').width(slider_width/2);
		} else {
			specials_first_item.addClass('active').width(slider_width/2);
			specials_first_item.next().addClass('active').width(slider_width/2);
		}
		} else if (is_tablet && specials_list.length <= 2) {
			if (specials_list.length < 2) {
			var cwidth = slider_width;
			} else {
			var cwidth = slider_width/2;
			}
			$("li:not('.active')",specials_wrapper).addClass('active').width(cwidth);
			$('.frozr_specials_left,.frozr_specials_right').hide();
		} else {
		if (specials_next_item.length > 0 && specials_next_item.hasClass('frozr_specials_item')) {
			specials_next_item.addClass('active').width(slider_width);
		} else {
			specials_first_item.addClass('active').width(slider_width);
		}
		}
	},
	show_frozrdash_general_popup_box: function(e,data) {
		e.preventDefault();
		$(".frozrdash_general_popup").html('');
		$(".ui-page-active").addClass("frozr_content_block");
		$(".frozrdash_general_popup").html(data).addClass("frozrdash_general_popup_open");
		setTimeout(function(){$(".frozrdash_general_popup").addClass('frozrdash_general_popup_loaded');}, 100);
	},
	hide_frozrdash_general_popup_box: function(e) {
		$( ".frozrdash_general_popup" ).removeClass("frozrdash_general_popup_open frozrdash_general_popup_loaded");
		$( ".ui-page-active" ).removeClass("frozr_content_block");
	},
	show_hide_general_help_box: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parent();
		var help_txt = $('.frozr_popup_help_text', wrapper).html();
		$(".ui-page-active").addClass("frozr_content_block");
		$(".frozr_gen_help_box").html(help_txt).addClass("frozr_gen_help_box_open");
	},
	display_norsani_message: function(e,msg) {
		Frozr_Scripts.display_message(msg);
	},
	display_message: function(msg) {
		$('.ui-page-active').append('<div class="frozr_error_box">' + msg + '</div>');
		clearTimeout(display_msg_time);
		clearTimeout(display_msg_interval);
		clearTimeout(display_msg_hide_time);
		
		display_msg_time = setTimeout(function(){$('.frozr_error_box').css('transform', 'translateY(0)')}, 50);
		display_msg_interval = setTimeout(function(){$('.frozr_error_box').css('transform', 'translateY(100%)')}, 8000);
		display_msg_hide_time = setTimeout(function(){$('.frozr_error_box').remove()}, 9000);
	},
	pinMenu: function(){
		var windowPos = $window.scrollTop();
		
		if ( 955 > windowWidth || screenReaderText.theme_is_one_column > 0 ) {
			return false;
		}
		
		var sidebarHeight = $sidebarMenuWrap.height();
		var windowHeight  = $window.height();
		var bodyHeight	  = $document.height();
		var sidebar_top_offset = $sidebarMenuWrap.offset().top;
		var side_fixed_height = adminbarOffset > 0 ? 95 : 100; 
		var d_class = 'top:'+adminbarOffset+'px;-webkit-transition:none;transition:none;';
			menuTop = ( sidebar_top_offset > 0 ) ? sidebar_top_offset : 0;

		if ( sidebarHeight + adminbarOffset > windowHeight ) {
			if ( windowPos > lastScrollPosition ) {
				// Scrolling down
				if ( pinnedMenuTop ) {
					// let it scroll
					pinnedMenuTop = false;
					$sidebarMenuWrap.attr( 'style', 'top:' + menuTop + 'px;' );
					
				} else if ( ! pinnedMenuBottom && sidebar_top_offset + sidebarHeight < windowPos + windowHeight && sidebarHeight < bodyHeight) {
					// pin the bottom
					pinnedMenuBottom = true;
					$sidebarMenuWrap.attr( 'style', 'position:fixed; bottom:0;' );
				}
			} else if ( windowPos < lastScrollPosition ) {
				// Scrolling up
				if ( pinnedMenuBottom ) {
					// let it scroll
					pinnedMenuBottom = false;
					$sidebarMenuWrap.attr( 'style', 'top:' + menuTop + 'px;' );
					
				} else if ( ! pinnedMenuTop && sidebar_top_offset >= windowPos ) {
					// pin the top
					pinnedMenuTop = true;
					$sidebarMenuWrap.attr( 'style', 'position:fixed;'+d_class );
				}
			} else {
				pinnedMenuTop = pinnedMenuBottom = false;
				$sidebarMenuWrap.attr( 'style', 'top: ' + menuTop + 'px;' );
			}
		} else if ( ! pinnedMenuTop ) {
			pinnedMenuTop = true;
			$sidebarMenuWrap.attr( 'style', 'position:fixed;'+d_class+'height:'+side_fixed_height+'%' );
		}

		lastScrollPosition = windowPos;
	},
	resize: function(){
		if(!screenReaderText.is_mobile) {
		if ( 955 > windowWidth || screenReaderText.theme_is_one_column > 0 ) {
			top = bottom = false;
			$sidebarMenuWrap.removeAttr( 'style' );
		}
		}
	},
	resizeAndScroll: function(){
		Frozr_Scripts.resize();
		Frozr_Scripts.pinMenu();
		Frozr_Scripts.set_body_min_height();
	},
	get_delivery_details: function() {
	var wrapper = $('#'+active_page_id);
	var ven_time_wrap = $('.frozr_rest_del_time_wrapper', wrapper);
	if (ven_time_wrap.length < 1) {
		return false;
	}
	var ven_fee_wrap = $('.frozr_del_fee_wrapper', wrapper);
	var ven_fee_wrap_text = $('.frozr_del_fee_text', ven_fee_wrap);
	var ven_fee_wrap_text_help = $('.frozr_popup_help_text', ven_fee_wrap);
	var to_vendor = ven_time_wrap.attr('data-vendor');
	var startaddress = Frozr_Scripts.get_location_vals('usrlocun');
	var distance_container = $('.frozr_distance_text', ven_time_wrap);
	var distance_container_help = $('.frozr_popup_help_text', ven_time_wrap);
	var ven_fee = ven_fee_wrap.attr('data-fee');
	var ven_ord_type = ven_fee_wrap.attr('data-ordtyp');
	var del_sellers = Frozr_Scripts.get_location_vals('delsellers');
	
	$.ajax({
		beforeSend: function() {Frozr_Scripts.app_action_loading();},
		complete: function() {Frozr_Scripts.app_action_loading_complete();},
		url: screenReaderText.ajax_url,
		data: {action:'frozr_get_delivery_info',vendor: to_vendor, address: startaddress, security:screenReaderText.frozr_set_user_loc_nonce},
		type: 'POST',
		success: function( response ) {
			if (response.total_del) {
				var totaldev = Number.parseFloat(response.total_del).toFixed(2);
				var totaldis = Number.parseFloat(response.distance).toFixed(2);
				var delivery_fee = totaldev / totaldis;
				var dist_txt = response.distance+' '+response.divider;
				distance_container.html(response.duration);
				distance_container_help.html(screenReaderText.distance_help_cal+' '+dist_txt);
				if ($.inArray(to_vendor,del_sellers) > -1) {
				if (!ven_fee || ven_fee == 0) {
					ven_fee_wrap_text.html(screenReaderText.free_delivery);
					ven_fee_wrap_text_help.html(screenReaderText.del_fee_help_free);
				} else {
					ven_fee_wrap_text.html(screenReaderText.currency+totaldev+' '+screenReaderText.ord_per+' '+ven_ord_type);
					ven_fee_wrap_text_help.html(screenReaderText.del_fee_help+' '+screenReaderText.currency+delivery_fee.toFixed(2)+' X '+dist_txt);
				}
				} else {
					ven_fee_wrap_text.html(screenReaderText.out_of_rang);
					ven_fee_wrap_text_help.html(screenReaderText.out_of_rang_desc);
				}
			} else {
			if (typeof google != 'undefined') {
			var endaddresss = ven_time_wrap.attr('data-address');
			var endaddsplit = endaddresss.split(',');
			var endaddress = new google.maps.LatLng(parseFloat(endaddsplit[0]), parseFloat(endaddsplit[1]));
			if (startaddress && endaddress) {
			var service = new google.maps.DistanceMatrixService();
			service.getDistanceMatrix({
				origins: [ startaddress ],
				destinations: [ endaddress ],
				travelMode: screenReaderText.distance_travelmode,
				unitSystem: screenReaderText.distance_unitsystem == 'google.maps.UnitSystem.METRIC' ? google.maps.UnitSystem.METRIC : google.maps.UnitSystem.IMPERIAL,
				avoidHighways: screenReaderText.distance_avoidhighways == 'false' ? false : true,
				avoidTolls: screenReaderText.distance_avoidtolls == 'false' ? false : true,
				}, function(response, status) {
				if (status == 'OK') {
					var origins = response.originAddresses;
					var destinations = response.destinationAddresses;
					for (var i = 0; i < origins.length; i++) {
						var results = response.rows[i].elements;
						for (var j = 0; j < results.length; j++) {
							var element = results[j];
							var data	= {};

							if (typeof element.distance != 'undefined' && typeof element.duration != 'undefined' && $.inArray(to_vendor,del_sellers) > -1) {
							var dist = element.distance.value > 0 ? element.distance.value : 1;
							var dur_txt = element.duration.value > 0 ? element.duration.text : '5 mins';
								data.distance	= parseFloat(dist);
								data.duration	= dur_txt;
								data.startaddr	= startaddress;
								data.tovend		= parseInt(to_vendor);
								data.action		= 'frozr_add_new_distance';
								data.security	= screenReaderText.frozr_add_new_distance_sec;

								jQuery.ajax({
									beforeSend: function() {Frozr_Scripts.app_action_loading();},
									complete: function() {Frozr_Scripts.app_action_loading_complete();},
									url: screenReaderText.ajax_url,
									data: data,
									type: 'POST',
									success: function( response ) {
										var totaldev = Number.parseFloat(response.total_del).toFixed(2);
										var totaldis = Number.parseFloat(element.distance.text).toFixed(2);
										var dist_txt = totaldis+' '+screenReaderText.distance_divider;
										var delivery_fee = totaldev / totaldis;
										distance_container.html(dur_txt);
										distance_container_help.html(screenReaderText.distance_help_cal+' '+dist_txt);
										if ($.inArray(to_vendor,del_sellers) > -1) {
										if (!ven_fee || ven_fee == 0) {
											ven_fee_wrap_text.html(screenReaderText.free_delivery);
											ven_fee_wrap_text_help.html(screenReaderText.del_fee_help_free);
										} else {
											ven_fee_wrap_text.html(screenReaderText.currency+totaldev+' '+screenReaderText.ord_per+' '+ven_ord_type);
											ven_fee_wrap_text_help.html(screenReaderText.del_fee_help+' '+screenReaderText.currency+delivery_fee.toFixed(2)+' X '+dist_txt);
										}
										} else {
											ven_fee_wrap_text.html(screenReaderText.out_of_rang);
											ven_fee_wrap_text_help.html(screenReaderText.out_of_rang_desc);
										}
									}, error: function(erre) {
										console.log(erre);
									}
								});
							} else {
								distance_container.html(screenReaderText.geolocation_failed_distance);
								distance_container_help.html(screenReaderText.unsupported_loc_help);
								ven_fee_wrap_text_help.html(screenReaderText.unsupported_loc_help);
								ven_fee_wrap_text.html(screenReaderText.geolocation_failed_distance);
							}
						}
					}
				} else {
					distance_container.html(screenReaderText.geolocation_error_distance);
					distance_container_help.html(screenReaderText.geolocation_error_distance_help);
					ven_fee_wrap_text_help.html(screenReaderText.geolocation_error_fee_help);
					ven_fee_wrap_text.html(screenReaderText.geolocation_error_distance);
					console.log(status);
				}
				});
			}
			} else {
				distance_container.html(screenReaderText.geolocation_no_connection);
				distance_container_help.html(screenReaderText.geolocation_connection_help);
				ven_fee_wrap_text_help.html(screenReaderText.geolocation_connection_help);
				ven_fee_wrap_text.html(screenReaderText.geolocation_no_connection);
			}
			}
		}, error: function(erre) {
		console.log(erre);
		distance_container.html(screenReaderText.geolocation_error_distance);
		distance_container_help.html(screenReaderText.geolocation_error_distance_help);
		ven_fee_wrap_text_help.html(screenReaderText.geolocation_error_fee_help);
		ven_fee_wrap_text.html(screenReaderText.geolocation_error_distance);
		}
	});
	},
	filter_vendors_distance: function(e,usr_loc) {
		e.preventDefault();
		var startaddress = null != usr_loc ? usr_loc : Frozr_Scripts.get_location_vals('usrlocun');
		if (e.type == 'click') {
		distance_container = $(this).parent();
		}
		if (startaddress) {
		Frozr_Scripts.app_action_loading();
		var near_vends = Frozr_Scripts.get_near_rests();
		var dis_sym = screenReaderText.distance_unitsystem == 'google.maps.UnitSystem.METRIC' ? ' km' : ' Mile';
		var vendors_ids = [];
		$('.rests_list_single', distance_container).each( function() {
			var self = $(this);
			var vend_inner = $('.item_cont',self);
			if (vend_inner.parent().attr('data-geo') != '') {
			vendors_ids.push(parseInt(vend_inner.attr('data-id')));
			}
		});
		var not_included_vendors = jQuery.grep(vendors_ids, function( a ) {
			var found_ele = false;
			for (var j = 0; j < near_vends.length; j++) {
				if (a == near_vends[j].vend && near_vends[j].dis == null) {
					found_ele = true;
					break;
				}
			}
			if (found_ele == true) {
			return a;
			}
		});
		if (not_included_vendors.length > 0) {
			var vendors_addressess = [];
			var vendors_addressess_matrix = [];
			var count = 0;
			var vcount = 0;
			var counts = 0;
			$.each(not_included_vendors,function(key, value){
				var self = $('[data-id="'+value+'"]',distance_container).parent();
				var geo_addr = self.attr('data-geo');
				var split_geo = geo_addr.split(',');
				var addr_obj = new google.maps.LatLng(parseFloat(split_geo[0]), parseFloat(split_geo[1]));
				vendors_addressess.push(addr_obj);
				count++;
				if (count == 24) {
					vendors_addressess_matrix[counts] = vendors_addressess;
					vendors_addressess = [];
					counts++;
					count = 0;
				}
			});
			if (vendors_addressess.length > 0) {
				if (vendors_addressess_matrix.length > 0) {
					counts++;
				}
				vendors_addressess_matrix[counts] = vendors_addressess;
			}
			$.each(vendors_addressess_matrix,function(key, value){
			var service = new google.maps.DistanceMatrixService();
			service.getDistanceMatrix({
				origins: [startaddress],
				destinations: value,
				travelMode: screenReaderText.distance_travelmode,
				unitSystem: screenReaderText.distance_unitsystem == 'google.maps.UnitSystem.METRIC' ? google.maps.UnitSystem.METRIC : google.maps.UnitSystem.IMPERIAL,
				avoidHighways: screenReaderText.distance_avoidhighways == 'false' ? false : true,
				avoidTolls: screenReaderText.distance_avoidtolls == 'false' ? false : true,
				}, function(response, status) {
				if (status == 'OK') {
					var origins = response.originAddresses;
					var results = response.rows[0].elements;
					var vendors_distance_list = [];
					for (var j = 0; j < results.length; j++) {
						var element = results[j];
						if (typeof element.distance != 'undefined' && typeof element.duration != 'undefined') {
						var distance_val = element.distance.value > 0 ? element.distance.value : 1;
						var dur_txt = element.duration.value > 0 ? element.duration.text : '5 mins';
						vendors_distance_list.push({vend:not_included_vendors[vcount],dis:distance_val,dur:dur_txt});
						vcount++;
						}
					}
					if (vendors_distance_list.length > 0) {
					for (var j = 0; j < vendors_distance_list.length; j++) {
						for (var i = 0; i < near_vends.length; i++) {
						if (vendors_distance_list[j].vend == near_vends[i].vend && near_vends[i].dis == null) {
							near_vends[i].dis = vendors_distance_list[j].dis;
						}
						}
					}
					var masterList = near_vends.sort(function(a,b){
						return parseFloat(a.dis) - parseFloat(b.dis);
					});
					window.localStorage.setItem("lyznearrests", JSON.stringify(masterList));
					
					var vendors_sorted_array = [];
					var vendors_wrapper = $('.frozr_vendors_list_wrapper',distance_container);
					$.each(masterList,function(key, value){
						if (value.vend > 0 && $.inArray( parseInt(value.vend), vendors_ids ) > -1) {
						var wrapp = $('[data-id="'+value.vend+'"]',distance_container).parent();
						$('.vend_distance_wrapper', wrapp).html('<i class="material-icons">navigation</i>'+Number.parseFloat(value.dis/1000).toFixed(1)+dis_sym);
						var ven_obj = $('[data-id="'+value.vend+'"]',distance_container).parent().get(0);
						vendors_sorted_array.push(ven_obj);
						}
					});
					vendors_wrapper.html('');
					$.each(vendors_sorted_array,function(){
						vendors_wrapper.append(this);
					});
					
					var data		= {};
					data.startaddr	= startaddress;
					data.list		= vendors_distance_list;
					data.action		= 'frozr_add_new_distance_bulk';
					data.security	= screenReaderText.frozr_add_new_distance_sec;

					jQuery.ajax({
						beforeSend: function() {},
						complete: function() {Frozr_Scripts.app_action_loading_complete();},
						url: screenReaderText.ajax_url,
						data: data,
						type: 'POST',
						success: function( responsee ) {
						}, error: function(erre) {
							console.log(erre);
						}
					});
					} else {
						Frozr_Scripts.app_action_loading_complete();
						Frozr_Scripts.display_message(screenReaderText.gen_error);
					}
				} else {
					Frozr_Scripts.app_action_loading_complete();
					Frozr_Scripts.display_message(screenReaderText.gen_error);
					console.log(status);
				}
				});
			});
		} else {
			Frozr_Scripts.app_action_loading_complete();
			var vendors_sorted_array = [];
			var vendors_wrapper = $('.frozr_vendors_list_wrapper',distance_container);
			var masterList = near_vends.sort(function(a,b){
				return parseFloat(a.dis) - parseFloat(b.dis);
			});
			$.each(masterList,function(key, value){
				if (value.vend > 0 && $.inArray( parseInt(value.vend), vendors_ids ) > -1) {
				var wrapp = $('[data-id="'+value.vend+'"]',distance_container).parent();
				$('.vend_distance_wrapper', wrapp).html('<i class="material-icons">navigation</i>'+Number.parseFloat(value.dis/1000).toFixed(1)+dis_sym);
				var ven_obj = $('[data-id="'+value.vend+'"]',distance_container).parent().get(0);
				vendors_sorted_array.push(ven_obj);
				}
			});
			vendors_wrapper.html('');
			$.each(vendors_sorted_array,function(){
				vendors_wrapper.append(this);
			});
		}
		} else {
		Frozr_Scripts.show_location_form();
		}
	},
	show_location_form: function() {
		$(".ui-page-active").addClass("frozr_content_block");
		$(".frozr_location_set_wrapper").addClass("frozr_location_set_wrapper_open");
		var location_div = $('#frozr_location_input_gen');
		if (location_div.length > 0) {
			$(document.body).trigger('frozr_location_form_active',['frozr_location_input_gen']);
		}
	},
	show_hide_del_form: function() {
		if ($(this).prop("checked")) {
			$('li[data-id="frozr_reg_fees_menu"],li[data-id="frozr_reg_del_menu"]').show();
			$('.show_for_del_only').removeClass('show_for_del_only');
		} else {
			$('div[data-menu="frozr_reg_fees_menu"],div[data-menu="frozr_reg_del_menu"]').addClass('show_for_del_only');
			$('li[data-id="frozr_reg_fees_menu"],li[data-id="frozr_reg_del_menu"]').hide();
		}
	},
	check_field_availability: function(e) {
		e.preventDefault();
		var data = {};
		var self = $(this);
		var wrapper = self.parent();
		var input_val = self.val();
		var filterval = input_val;
		
		if (input_val.length == 0) {
			if (self.attr('id') == 'frozr_vendor_shopname_name') {
			$('.field_not,.field_ok', wrapper).html(screenReaderText.fill_shopname).removeClass('field_ok').addClass('field_not');
			} else {
			$('.field_not,.field_ok', wrapper).html(screenReaderText.fill_email_address).removeClass('field_ok').addClass('field_not');
			}
			$('input', wrapper).addClass('input_not');
			return false;
		}
		
		if (self.attr('id') == 'frozr_reg_email') {
			var ftype = 'email';
		} else if (self.attr('id') == 'frozr_vendor_shopname_name') {
			var ftype = 'storename';
		}
		
		if ($('.field_not, .field_ok', wrapper).length > 0) {
			$('.field_not, .field_ok', wrapper).removeClass().html('').addClass('frozr_content_loader');
		} else {
			wrapper.append('<div class="frozr_content_loader"></div>');
		}

		data.inputval = filterval;
		data.type = ftype;
		data.action = 'frozr_reg_check_field';
		data.security = screenReaderText.frozr_reg_form_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			data: data,
			type: 'POST',
			success: function(response) {
				if(response.success) {
					$('input', wrapper).removeClass('input_not');
					$('.frozr_content_loader').removeClass().addClass('field_ok').html(response.message);
				} else {
					$('input', wrapper).addClass('input_not');
					$('.frozr_content_loader').removeClass().addClass('field_not').html(response.message);
				}
			},
			error: function() {
				Frozr_Scripts.display_message(screenReaderText.gen_error);
			},
		});
	},
	trigger_submit_reg_form: function(e) {
		e.preventDefault();
		$('.frozr_registration_form',document.body).trigger('submit');
	},
	submit_reg_form: function(e) {
		e.preventDefault();
		var data = {},
			address_geo	= $('#frozr_reg_address', this).data('geo'),
			fields = $(this).serializeJSON();

		if (address_geo) {
			var restaddgeo = address_geo;
		} else {
			var restaddgeo = '';
		}
		data = fields;
		data.delivery_locs	= $('#fro_reg_delivery_locations_map', this).data('poly');
		data.addressgeo		= restaddgeo;
		data.delivery_locs_filtered	= $('#fro_reg_delivery_locations_map').data('polyfilterd');
		data.action = 'frozr_read_reg_form';
		data.security = screenReaderText.frozr_reg_form_nonce;

		$.ajax({
			beforeSend: function() {Frozr_Scripts.app_action_loading();},
			complete: function() {Frozr_Scripts.app_action_loading_complete();},
			url: screenReaderText.ajax_url,
			data: data,
			type: 'POST',
			success: function(response) {
				if(response.success == false) {
				Frozr_Scripts.display_message(response.data);
				} else if (response.redirect) {
					window.location.href = response.redirect;
				} else {
					$('.frozr_registration_forms_wrapper, .frozr_page_default_content, .frozr_reg_forms_menu').remove();
					$('.frozr_my_account_link').addClass('frozr_user_menu_trigger');
					$('.frozr_reg_thankyou').show();
				}
			},
			error: function(response) {
				Frozr_Scripts.display_message(screenReaderText.gen_error);
			},
		});
	},
	open_reg_form: function(e) {
		e.preventDefault();
		var current = $('.frozr_reg_active_div');
		if ($(this).prop("checked")) {
		var title = current.attr('data-title');
		var desc = current.attr('data-desc');
		$('.fro_def_cont').hide();
		$('.frozr_reg_form_title').html(title);
		$('.frozr_reg_form_desc').html(desc);
		$('#frozr_reg_seller_tos, .fro_reg_sel_tos_btn').hide();
		$('.frozr_registration_forms_wrapper, .frozr_reg_forms_menu').removeClass('frozr_hide');
		$("html, body").animate({
			scrollTop: jQuery('.frozr_reg_forms_menu').offset().top - 100
		}, 300);
		}
	},
	open_next_reg_form: function(e) {
		e.preventDefault();
		var current = $('.frozr_reg_active_div'),
			position = $(this).attr('data-act');
		
		if (position == 'next') {
		var next = current.next();
		if (next.hasClass('show_for_del_only')) {
			next = next.next();
			if (next.hasClass('show_for_del_only')) {
			next = next.next();
			}
		}
		} else {
		var next = current.prev();
		if (next.hasClass('show_for_del_only')) {
			next = next.prev();
			if (next.hasClass('show_for_del_only')) {
			next = next.prev();
			}
		}
		}
		var menu = next.attr('data-menu');
		var title = next.attr('data-title');
		var desc = next.attr('data-desc');
		
		if (next.length > 0) {
		
		if (current.attr('data-menu') == 'frozr_reg_gen_info_menu') {
			var scroll_top = false;
			
			if ($('#frozr_reg_email').val() == '' || $('#frozr_reg_email.input_not').length > 0) {
				Frozr_Scripts.display_message(screenReaderText.fill_email_address);
				scroll_top = true;
			} else if($('#frozr_vendor_shopname_name').val() == '' || $('#frozr_vendor_shopname_name.input_not').length > 0) {
				Frozr_Scripts.display_message(screenReaderText.fill_shopname);
				scroll_top = true;
			} else if($('#frozr_reg_password').val() == '') {
				Frozr_Scripts.display_message(screenReaderText.fill_password);
				scroll_top = true;
			}
			
			if (scroll_top) {
			$("html, body").animate({scrollTop: $('#frozr_reg_email').offset().top - 100}, 300);
			return false;
			}
		}
		
		$('.frozr_reg_forms_menu > li').removeClass('frozr_reg_active_menu');
		$('.frozr_reg_forms_menu > li[data-id="'+menu+'"]').addClass('frozr_reg_active_menu');
		$('.frozr_reg_form_title').html(title);
		$('.frozr_reg_form_desc').html(desc);

		/*Hide current form*/
		if (next.is(':last-child')) {
			$('.frozr_reg_next').hide();
			$('.frozr_reg_form_submit').show();
		} else {
			$('.frozr_reg_form_submit').hide();
			$('.frozr_reg_next').show();
		}
		current.addClass('frozr_hide').removeClass('frozr_reg_active_div');
		
		/*Show next form*/
		if (!next.is(':first-child')) {
			$('.frozr_reg_back').show();
		} else {
			$('.frozr_reg_back').hide();
		}
		next.removeClass('frozr_hide').addClass('frozr_reg_active_div');
		}
		
		$("html, body").animate({scrollTop: $('.frozr_reg_forms_menu').offset().top}, 300);
	},
	frozr_show_items_gen_fav: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parents('.frozr_usr_fav_tabs');
		var active_btn = self.parent();
		$('.active',wrapper).removeClass('active');
		active_btn.addClass('active');
		$('.frozr_usr_fav_rslt_items').show();
		$('.frozr_usr_fav_rslt_rests').hide();
	},
	frozr_show_rests_gen_fav: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parents('.frozr_usr_fav_tabs');
		var active_btn = self.parent();
		$('.active',wrapper).removeClass('active');
		active_btn.addClass('active');
		$('.frozr_usr_fav_rslt_items').hide();
		$('.frozr_usr_fav_rslt_rests').show();
	},
	frozr_show_items_gen_src: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parents('.frozr_gen_src_tabs');
		var active_btn = self.parent();
		$('.active',wrapper).removeClass('active');
		active_btn.addClass('active');
		$('.ui-page-active .frozr_gen_rslt_items').show();
		$('.ui-page-active .frozr_gen_rslt_rests').hide();
	},
	frozr_show_rests_gen_src: function(e) {
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parents('.frozr_gen_src_tabs');
		var active_btn = self.parent();
		$('.active',wrapper).removeClass('active');
		active_btn.addClass('active');
		$('.ui-page-active .frozr_gen_rslt_items').hide();
		$('.ui-page-active .frozr_gen_rslt_rests').show();
	},
	location_input_focusout: function() {
		var input = $('.item_atc_popup_open');
		input.removeClass('location_input_focused');
	},
	location_input_click: function(e) {
		e.preventDefault();
		var input = $('.item_atc_popup_open');
		input.addClass('location_input_focused');
		$('.item_atc_popup.item_atc_popup_open').animate({scrollTop: 0}, 400); 
	},
	user_location_set_manual: function(e,pos,sellerspos,usrloc,sellersArray,responses) {
		if($('.no_del_found').length > 0) {
			location.reload(true);
		} else if ($('.frozr_location_set_wrapper_open').length > 0) {
			$( ".frozr_location_set_wrapper" ).removeClass("frozr_location_set_wrapper_open");
			$( ".ui-page-active" ).removeClass("frozr_content_block");
			var data		= {};
			data.user_loc	= usrloc;
			data.action		= 'frozr_get_near_vendors_data';
			data.security	= screenReaderText.load_norsani_rests_nonce;

			jQuery.ajax({
				beforeSend: function() {Frozr_Scripts.app_action_loading();},
				complete: function() {Frozr_Scripts.app_action_loading_complete();},
				url: screenReaderText.ajax_url,
				data: data,
				type: 'POST',
				success: function( response ) {
					var near_vends = response.near_sellers;
					var masterList = near_vends.sort(function(a,b){
						return parseFloat(a.dis) - parseFloat(b.dis);
					});
					window.localStorage.setItem("lyznearrests", JSON.stringify(masterList));
					Frozr_Scripts.filter_vendors_distance(e,usrloc);
				}, error: function(erre) {
					console.log(erre);
				}
			});
		} else {
		Frozr_Scripts.user_location_set(e,responses);
		}
	},
	user_location_set: function(e,response) {
		var item_wrapper = $(".item_atc_popup");
		var item_id = $('.fle_addtocart', item_wrapper).attr('data-item');
		if(response.atc_new_form && item_wrapper.length > 0) {
		Frozr_Scripts.open_item_atc_popup(e,item_id);
		}
		/*get delivery details*/
		Frozr_Scripts.get_delivery_details();
		
		if ($('.frozr_gen_help_box_open').length > 0) {
			$('.frozr_gen_help_box_open').removeClass('frozr_gen_help_box_open');
			$( ".ui-page-active" ).removeClass("frozr_content_block");
		}
		
		if(!response.success) {
		setTimeout(function(){$('.user_geo_location_list').val('');},50);
		Frozr_Scripts.location_input_focusout();
		}
		
		if(response.message) {
		Frozr_Scripts.display_message(response.message);
		}
		
	},
	search_meal_type: function(filter_key,current_page) {
		Frozr_Scripts.app_action_loading();
		var items_list	= $('.items_list_single', current_page),
			no_items_found = true;
		
		$('.frozr_mealtype_item_found').removeClass('frozr_mealtype_item_found');
		items_list.each(function(){
			var self = $(this);
			var filter_value = self.attr('data-mealtyp');
			var filter_type = self.attr('data-mealtyparray');
			if (filter_type == 'array') {
				var split_menus = filter_value.split(',');
				var item_found = false;
				$.each( split_menus,function(key, value){
					if (value != '' && value == filter_key) {
						item_found = true;
					}
				});
				if (item_found) {
					self.addClass('frozr_mealtype_item_found').show();
				} else {
					self.removeClass('frozr_mealtype_item_found').hide();
				}
			} else if (filter_value != '' && filter_value == filter_key) {
				self.addClass('frozr_mealtype_item_found').show();
			} else {
				self.removeClass('frozr_mealtype_item_found').hide();
			}
		});
		
		$('.frozr_rest_store_items_group', current_page).each(function(){
			var self = $(this);
			if ($('.frozr_mealtype_item_found', self).length > 0) {
				self.show();
				no_items_found = false;
			} else {
				self.hide();
			}
		});
		
		if (no_items_found) {
		$('.frozr_vendor_store_notices', current_page).html('<div class="frozr_no_results frozr_vendor_meal_src"><i class="material-icons">store</i>'+screenReaderText.menu_no_items+'</div>').show();
		} else {
			$('.frozr_vendor_store_notices',current_page).html('').hide();
		}
		Frozr_Scripts.app_action_loading_complete();
	},
	geo_locate_me: function(e) {
		e.preventDefault();
		clearTimeout(geolocate_user_time);
		if ( window.confirm( screenReaderText.geo_locate_me_notice ) ) {
		geolocate_user_time = setTimeout(function(){
		try {
		var geocoder = new google.maps.Geocoder;
		var itemid = 0;
		if($('.cart.ajax_lazy_submit').length > 0) {
			itemid = $('.cart.ajax_lazy_submit').attr('data-product_id');
		}
		/* Try HTML5 geolocation.*/
		if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(function(position) {
			var sellerspos = screenReaderText.frozr_sellers_locs,
				resultRequest = '',
				resultPath = '',
				sellersArray = [],
				latstr = position.coords.latitude,
				lngstr = position.coords.longitude,
				latlng = {lat: parseFloat(latstr), lng: parseFloat(lngstr)},
				pos = new google.maps.LatLng(parseFloat(latstr), parseFloat(lngstr));
			
			$.ajax({
				beforeSend: function() {Frozr_Scripts.app_action_loading();},
				complete: function() {Frozr_Scripts.app_action_loading_complete();},
				url: screenReaderText.ajax_url,
				data: {action:'frozr_get_sellers_locs',security:screenReaderText.frozr_set_user_loc_nonce},
				type: 'POST',
				success: function( response ) {
					sellerspos = response;
				}
			}).always(function(response) {
			/*Get delivery sellers*/
			jQuery.each(sellerspos, function (index, val) {
				var deliveryCoords = [];
				jQuery.each(val, function (indexs, vals) {
					if (vals[0] != null && vals[1] != null) {
						deliveryCoords.push(new google.maps.LatLng(parseFloat(vals[0]), parseFloat(vals[1])));
					}
				});
				if (deliveryCoords) {
					var sellerspoly = new google.maps.Polygon({paths: deliveryCoords});
					resultRequest = google.maps.geometry.poly.containsLocation(pos, sellerspoly);
					resultPath = resultRequest ? index :'';
					if (resultPath != null) {
						sellersArray.push(resultPath);
					}
				}
			});
			geocoder.geocode({'location': latlng}, function(results, status) {
				if (status === 'OK') {
					var customer_location = parseFloat(latstr)+','+parseFloat(lngstr);
					if (results[0]) {
						$.ajax({
						beforeSend: function() {Frozr_Scripts.app_action_loading();},
						complete: function() {Frozr_Scripts.app_action_loading_complete();},
						url: screenReaderText.ajax_url,
						data: {
							ritem: itemid,
							sellers: sellersArray,
							userloc: results[0].formatted_address,
							locgeo: customer_location,
							action: 'frozr_user_loc_cookie',
							security: screenReaderText.frozr_set_user_loc_nonce,
						},
						type: 'POST',
						success: function( response ) {
						window.localStorage.setItem("frozr_del_sellers", JSON.stringify(sellersArray));
						window.localStorage.setItem("frozr_user_location", response.usr_loc);
						window.localStorage.setItem("frozr_user_location_unslashed", response.usr_loc_un);
						Frozr_Scripts.user_location_set_manual(e,pos,sellerspos,results[0].formatted_address,sellersArray,response);
						}
						});
					} else {
						Frozr_Scripts.display_message(screenReaderText.geocoder_address_not_found);
					}
				} else {
					var msg = screenReaderText.geocoder_address_not_found;
					
					switch(status) {
						case "ZERO_RESULTS":
						msg = screenReaderText.geo_position_unavailable;
						break;
						case "OVER_QUERY_LIMIT":
						msg = screenReaderText.geo_over_query_limit;
						break;
						case "REQUEST_DENIED":
						msg = screenReaderText.geo_request_denied;
						break;
						case "INVALID_REQUEST":
						msg = screenReaderText.geo_invalid_request;
						break;
						case "UNKNOWN_ERROR":
						msg = screenReaderText.geo_cod_unknown_error;
						break;
					}
					
				  Frozr_Scripts.display_message(msg);
				}
			});
			});
		}, function(error) {
			var msg = screenReaderText.geolocation_failed;
			
			switch(error.code) {
				case error.POSITION_UNAVAILABLE:
				msg = screenReaderText.geo_position_unavailable;
				break;
				case error.PERMISSION_DENIED:
				msg = screenReaderText.geo_access_denied;
				break;
				case error.TIMEOUT:
				msg = screenReaderText.geo_timeout;
				break;
				case error.UNKNOWN_ERROR:
				msg = screenReaderText.geo_unknown_error;
				break;
			}
			Frozr_Scripts.display_message(msg);
		});
		} else {
			/* Browser doesn't support Geolocation*/
			Frozr_Scripts.display_message(screenReaderText.geolocation_not_support);
		}
		} catch (e) {
			Frozr_Scripts.display_message(screenReaderText.geolocation_failed_connection);
		}
		}, 1000);
		}
	},
	open_item_atc_popup: function(e,itemid) {
		e.preventDefault();
		var active_item = $(this);
		if (itemid) {
		var item_id = itemid;
		} else {
		var item_id = active_item.attr('data-id');
		}

		var data = {};
		var get_cart = active_item.attr('data-get');
		
		$(".ui-page-active").addClass("frozr_content_block");
		$(".item_atc_popup").html('<div class="frozr_content_loader"></div>').addClass("item_atc_popup_open frozr_content_loading");

		data.action		= 'frozr_ly_gen_src_atc';
		data.itemid		= parseInt(item_id);
		data.security	= screenReaderText.frozr_general_src_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			data: data,
			type: 'POST',
			success: function(response) {
				if(response){
				$(".item_atc_popup").removeClass("frozr_content_loading").html(response);
				$('.item_atc_popup .wc-radios > li:first-child input').trigger('click');
				$('.item_atc_popup .wc-radios').trigger('change');
				if ($('.item_atc_popup .order_l_type_field li').length == 0) {
					$('.item_atc_popup .order_l_type_field').hide();
					$('.no_orders_allowed').show();
				}
				if (get_cart) {
					$('.cart.ajax_lazy_submit').attr('data-get','cart');
				}
				
				Frozr_Scripts.set_upsel_widths($(".item_atc_popup"));
				
				var location_form = $('#frozr_location_input_post');
				if (location_form.length > 0) {
					$(document.body).trigger('frozr_location_form_active',['frozr_location_input_post']);
				}
				} else {
				Frozr_Scripts.display_message(screenReaderText.gen_error);
				$(".ui-page-active").removeClass("frozr_content_block");
				$( ".item_atc_popup" ).removeClass("item_atc_popup_open frozr_content_loading");
				}
			},
			error: function(xhr) {
				Frozr_Scripts.display_message(screenReaderText.gen_error);
				$(".ui-page-active").removeClass("frozr_content_block");
				$( ".item_atc_popup" ).removeClass("item_atc_popup_open frozr_content_loading");
			},
		});
	},
	set_upsel_widths: function(wrapper) {
		var upsell_list = $('.frozr_upsell_list',wrapper);
		var upsell_items = $('.frozr_upsell_single_item',wrapper);
		var upsell_items_active = $('.frozr_upsell_single_item.frozr_upsel_show',wrapper);
		if (upsell_items.length > 4 && !screenReaderText.is_mobile || screenReaderText.is_mobile && upsell_items.length > 2) {
		upsell_list.addClass('frozr_upsell_cur_active');
		var container_width = upsell_list.width();
		upsell_wrapper_width = container_width;
		var item_width = screenReaderText.is_mobile ? container_width/2 : container_width/4;
		upsell_items_active.width(item_width);
		}
	},
	frozr_general_fav_get: function() {
		var data = {};
		var fav_items = Frozr_Scripts.get_fav_items();
		var found_fav_items = false;
		clearTimeout(timeoutHandle);

		if (fav_items.length > 0) {
		Frozr_Scripts.app_action_loading();
		
		if(fro_gen_fav_cll && fro_gen_fav_cll.readyState != 4){
			fro_gen_fav_cll.abort();
		}

		timeoutHandle = setTimeout(function(){
		data.items		= fav_items;
		data.action		= 'frozr_ly_gen_fav';
		data.security	= screenReaderText.frozr_general_fav_nonce;

		fro_gen_fav_cll = $.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Scripts.app_action_loading();},
			complete: function() {Frozr_Scripts.app_action_loading_complete();},
			data: data,
			type: 'POST',
			success: function(response) {
				$('.frozr_usr_fav_rslt_items_list', '#'+active_page_id).html('');
				var fav_items_result = response.items;

				if (fav_items_result.length > 0) {
				found_fav_items = true;
				$('.frozr_usr_fav_rslt_items .frozr_no_results','#'+active_page_id).hide();
				$.each( response.items, function( key, value ) {
				Frozr_Scripts.item_html(key, value, 'frozr_usr_fav_rslt_items_list', 'fav_loop', screenReaderText.fav_items);
				});
				}
			},
			error: function() {
				Frozr_Scripts.display_message(screenReaderText.gen_error);
			},
		});
		}, 1100);
		}
		if (!found_fav_items) {
			if ($('.frozr_usr_fav_rslt_items .frozr_no_results','#'+active_page_id).length > 0) {
				$('.frozr_usr_fav_rslt_items .frozr_no_results','#'+active_page_id).show();
			} else {
			$('.frozr_usr_fav_rslt_items', '#'+active_page_id).append('<div class="frozr_no_results"><i class="material-icons">favorite_border</i>'+screenReaderText.no_fav_items+'</div>');
			}
		}
	},
	item_html: function(key,value,div,loop_type,title) {
		var fav_items = Frozr_Scripts.get_fav_items();
		if (title) {
		var list_title = '<h2 class="rests_list_title">'+title+'</h2>';
		} else {
		var list_title = '';
		}
		
		if ($('.ui-page-active .'+div+' .rests_list_header').length == 0) {
		$('.ui-page-active .'+div+'').append(list_title+'<ul class="rests_list_header"><li></li><li class="rest_names_header">'+screenReaderText.name+'</li>'
			+'<li>'+screenReaderText.rating+'</li>'
			+'<li class="frozr_items_header_menu hide_on_mobile">'+screenReaderText.menu+'</li>'
			+'<li class="frozr_items_header_item hide_on_mobile">'+screenReaderText.category+'</li>'
			+'<li><i class="material-icons">favorite</i></li>'
			+'<li><i class="material-icons">add_shopping_cart</i></li>'
			+'</ul>');
		}
		var item_is_fav ='';
		if($.inArray( parseInt(value.id), fav_items ) > -1 || loop_type == 'fav_loop') {
			item_is_fav = ' fav_item';
		}
		var vimg = value.image ? ' style="background-image:url('+value.image+');"' : '';
		$('.ui-page-active .'+div).append('<div class="items_list_single">'
			+'<a class="frozr_navto_item" href="'+value.link+'"><span class="waves-effect rest_item_img"'+vimg+'></span></a>'
			+'<span class="item_det">'
				+'<div class="frozr_item_details"><a class="frozr_navto_item frozr_item_title" href="'+value.link+'">'+value.title+'</a>'+value.itemstatus+'</div>'
				+'<span class="frozr_item_author"><a href="'+value.author_link+'">'+value.author+'</a></span>'
			+'</span>'
			+'<span class="item_loop_rating">'+value.rating_html+'</span>'
			+'<span class="item_loop_menu hide_on_mobile">'+value.menu_type+'</span>'
			+'<span class="item_cats hide_on_mobile">'+value.cats+'</span>'
			+'<span class="item_fav"><i class="material-icons add_fav add_item '+item_is_fav+'" data-id="'+value.id+'">favorite_border</i></span>'
			+'<span class="item_atc"><a href="#0" class="frozr_item_add_to_cart" data-id="'+value.id+'"><i class="material-icons">add</i></a>'
			+'<span class="item_loop_price">'+value.price+'</span>'
			+'</span>'
			+'</div>');
	},
	rest_html: function(key,rest_data,div,container,title,type) {
		var fav_rests = Frozr_Scripts.get_fav_rests();
		var rest_status = '<i class="material-icons rest_status_icon">locked</i> '+screenReaderText.vendor_closed;
		var rest_sts_class = 'closed';
		var rest_is_fav = '';
		var rest_rating = '';
		
		if (title) {
		var list_title = '<h2 class="rests_list_title">'+title+'</h2>';
		} else {
		var list_title = '';
		}

		if ($('.'+div+' .rests_list_header', container).length == 0) {
		$('.'+div, container).append(list_title+'<a href="!#" class="frozr_filter_by_distance_wrapper"><i class="material-icons">near_me</i>'+screenReaderText.order_by_distance+'</a><ul class="rests_list_header"><li></li><li class="rest_names_header">'+screenReaderText.name+'</li>'
			+'<li>'+screenReaderText.rstatus+'</li>'
			+'<li>'+screenReaderText.rating+'</li>'
			+'<li><i class="material-icons">favorite</i></li>'
			+'</ul><div class="frozr_vendors_list_wrapper"></div>');
		}

		if (rest_data.timing_status) {
			rest_sts_class = 'opened';
			rest_status = '<i class="material-icons rest_status_icon">lock_open</i> '+screenReaderText.vendor_open;
		}

		if($.inArray( parseInt(key), fav_rests ) > -1) {
			rest_is_fav = ' fav_item';
		}
		var vimg = rest_data.logo ? ' style="background-image:url('+rest_data.logo+');"' : '';
		$('.'+div+' .frozr_vendors_list_wrapper', container).append('<div class="rests_list_single" data-geo="'+rest_data.address+'">'
			+'<a class="item_cont rest_single_logo" title="'+rest_data.name+'" href="'+rest_data.url+'" data-id="'+key+'">'
			+'<span class="rest_item_img"'+vimg+'></span>'
			+'</a>'
			+'<a class="item_cont rest_single" title="'+rest_data.name+'" href="'+rest_data.url+'" data-id="'+key+'">'
			+'<span class="subheader">'+rest_data.name+'</span><span class="vend_cusine">'+rest_data.vendorclass+'</span><div class="vend_distance_wrapper"></div>'
			+'</a>'
			+'<a class="rest_status '+rest_sts_class+'">'+rest_status+'</a>'
			+'<span class="frozr_rest_rating">'+rest_data.rating+'</span>'
			+'<span class="rest_fav_wrap"><i class="material-icons add_fav add_rest'+rest_is_fav+'" data-id="'+key+'">favorite_border</i></span>'
			+'</div>');
	},
	search_store_favs: function() {
		var fav_items = Frozr_Scripts.get_fav_items();
		var fav_rests = Frozr_Scripts.get_fav_rests();
		var wrapper = $('#'+active_page_id);
		var vendorid = wrapper.attr('data-vendor');
		
		$.each( $('.add_fav','.frozr_rest_store_items_group'), function( key, value ) {
		if($.inArray( parseInt($(value).attr('data-id')), fav_items ) > -1) {
			$(value).addClass('fav_item');
		}
		});
		if (fav_rests.length > 0) {
			if($.inArray( parseInt(vendorid), fav_rests ) > -1) {
				$('.rest_fav_wrap .add_rest', wrapper).addClass('fav_item');
			}
		}
	},
	add_gen_fav_rests: function() {
		var fav_rest = [];
		var fav_rests = Frozr_Scripts.get_fav_rests();
		var rests_content = Frozr_Scripts.get_vendors();
		var container = $('.frozr_usr_fav_wrapper', '#'+active_page_id);
		var found_vars = false;

		/*Clear any data*/
		$('.frozr_usr_fav_rslt_rests', container).html('');
		if (rests_content && !$.isEmptyObject(rests_content) && fav_rests.length > 0) {

		$.each( rests_content, function( key, value ) {
			if($.inArray( parseInt(key), fav_rests ) > -1) {
			found_vars = true;
			$('.frozr_usr_fav_rslt_rests .frozr_no_results',container).hide();
			Frozr_Scripts.rest_html(key,value,'frozr_usr_fav_rslt_rests',container,screenReaderText.fav_rests);
			}
		});
		}
		if (!found_vars) {
			if ($('.frozr_usr_fav_rslt_rests .frozr_no_results',container).length > 0) {
				$('.frozr_usr_fav_rslt_rests .frozr_no_results',container).show();
			} else {
			$('.frozr_usr_fav_rslt_rests', container).html('<div class="frozr_no_results"><i class="material-icons">favorite_border</i>'+screenReaderText.no_fav_rests+'</div>');
			}
		}
	},
	frozr_general_src_get: function(e) {
		e.preventDefault();
		var data = {};
		var input_val = $(this).val();
		clearTimeout(timeoutHandle);
		
		$('.frozr_gen_rslt_feat_rests').hide();
		if(fro_gen_src_cll && fro_gen_src_cll.readyState != 4){
			fro_gen_src_cll.abort();
		}
		if (input_val.length > 0) {
			timeoutHandle = setTimeout(function(){
			data.action		= 'frozr_ly_gen_src';
			data.keyword	= input_val;
			data.security	= screenReaderText.frozr_general_src_nonce;

			fro_gen_src_cll = $.ajax({
				url: screenReaderText.ajax_url,
				beforeSend: function() {Frozr_Scripts.app_action_loading()},
				complete: function() {Frozr_Scripts.app_action_loading_complete()},
				data: data,
				type: 'POST',
				success: function(response) {
					var filtered_items = jQuery.map( response.items, function( values, index ) {return values; });
					var filtered_rests = jQuery.map( response.vendors, function( values, index ) {return values; });

					window.localStorage.setItem("lyzgensrcitemresult", JSON.stringify(filtered_items));
					window.localStorage.setItem("lyzgensrcrestresult", JSON.stringify(filtered_rests));
					Frozr_Scripts.output_gen_src_results();
				},
				error: function(response) {
					console.log(response);
					Frozr_Scripts.display_message(screenReaderText.gen_error);
				},
			});
			}, 1100);
		}
	},
	output_gen_src_results: function() {
		var items = window.localStorage.getItem("lyzgensrcitemresult");
		var vendors = window.localStorage.getItem("lyzgensrcrestresult");
		var rests_content = Frozr_Scripts.get_vendors();
		var page_title_raw = screenReaderText.src_results;
		var search_key = $('.frozr_gen_src').val();
		var page_title = page_title_raw+': "'+search_key+'"';
		
		$('.frozr_gen_src').blur();
		
		if (vendors) {
		var rests_array = JSON.parse(vendors);
		} else {
		var rests_array = [];
		}
		
		if (rests_array.length) {
			$('.ui-page-active .frozr_gen_rslt_rests').html('');

			$.each( rests_array, function( key, value ) {
			$.each( value, function( rkey, rvalue ) {
			$.each( rvalue, function( rrkey, rrvalue ) {
				var rest_data = rests_content[rrvalue];
				Frozr_Scripts.rest_html(rrvalue,rest_data,'frozr_gen_rslt_rests','.ui-page-active',page_title);
			});
			});
			});
		} else {
			Frozr_Scripts.no_rests_found();
		}
		
		if(items) {
		var items_array = JSON.parse(items);
		} else {
		var items_array = [];
		}
		
		var items_count = 0;
		if (items_array.length) {
			
			$('.frozr_gen_rslt_items_list').html('');
			
			if (items_array.length > 0) {
			$.each( items_array, function( vkey, vvalue ) {
			$.each( vvalue, function( vvkey, vvvalue ) {
			$.each( vvvalue, function( vvvkey, vvvvalue ) {
			if (items_count > 19) {return false;}
			Frozr_Scripts.item_html(vvvkey, vvvvalue, 'frozr_gen_rslt_items_list','gen_src',page_title);
			items_count++;
			});
			});
			});
			}
		} else {
			Frozr_Scripts.no_items_found();
		}
	},
	no_rests_found: function() {
		$('.ui-page-active .frozr_gen_rslt_rests').html('<div class="gen_src_no_rests_found"><i class="material-icons">store</i><h2>'+screenReaderText.no_rests+'</h2></div>');
	},
	no_items_found: function() {
		$('.ui-page-active .frozr_gen_rslt_items_list').html('<div class="gen_src_no_rests_found"><i class="material-icons">shopping_cart</i><h2>'+screenReaderText.no_items+'</h2></div>');
	},
	show_rest_src_input: function(e) {
		e.preventDefault();
		$('.rests_src_box').addClass('rests_src_box_vis').show().focus();
		$('.rests_src_box input').focus();
	},
	open_rests_contact_box: function(e) {
		var div = $('#rest_contact');
		clearTimeout(open_rests_contact_box_time);
		var page = $('.ui-page-active');
		var top_bar = $('.frozr_site_navbar.store_page');
		if ($('.open_rest_contact').length > 0) {
		div.removeClass('open_rest_contact');
		top_bar.removeClass('frozr_hide');
		page.removeClass('no_click');
		open_rests_contact_box_time = setTimeout(function(){div.hide();}, 450);
		Frozr_Scripts.block_unblock_page(e, $('.ui-page-active main > *:not(#rest_contact)'), true);
		} else {
		div.show();
		Frozr_Scripts.block_unblock_page(e, $('.ui-page-active main > *:not(#rest_contact)'), false);
		open_rests_contact_box_time = setTimeout(function(){page.addClass('no_click');top_bar.addClass('frozr_hide');div.addClass('open_rest_contact');}, 50);
		}
	},		
	show_cart_on_focusout: function(e) {
		$('.frozr_mobile_cart').removeClass('hide_mobile_cart');
	},
	hide_cart_on_focus: function(e) {
		$('.frozr_mobile_cart').addClass('hide_mobile_cart');
	},
	block_unblock_page: function(e, div_to_block, unblock) {
		if (unblock == true) {
		div_to_block.removeClass('frozr_content_block');
		$('.frozr_mobile_cart').removeClass('hide_mobile_cart');
		} else {
		div_to_block.addClass('frozr_content_block');
		$('.frozr_mobile_cart').addClass('hide_mobile_cart');
		}
	},
	show_gen_fav_input: function(e) {
		e.preventDefault();
		var active_page = $('#'+active_page_id);
		var page_title = $('.frozr_gen_fav_pagetitle',active_page).html();
		Frozr_Scripts.add_gen_fav_rests();
		Frozr_Scripts.frozr_general_fav_get();
		$('.frozr_page_title .external_page_title').html(page_title).show();
		active_page.addClass('gen_fav_active');
		$('.frozr_usr_fav_wrapper',active_page).addClass('fav_items_open');
		$('.frozr_page_title .main_title,.on-mobile .secondary-toggle,.frozr_one_col .secondary-toggle').hide();
		/*if on store page*/
		if ($('.frozr_site_navbar.store_page').length > 0) {
			$('.frozr_site_navbar.store_page').addClass('frozr_fav_open_on_store');
		}
		jQuery("html, body").animate({scrollTop: jQuery('body').offset().top}, 300);
	},
	show_gen_src_input: function(e) {
		e.preventDefault();
		clearTimeout(show_gen_src_input_time);
		$('.ui-page-active .gen_src_no_rests_found').remove();
		$('#'+active_page_id).addClass('gen_src_active');
		$('.frozr_gen_src_box').show();
		show_gen_src_input_time = setTimeout(function(){$( ".frozr_gen_src_box" ).addClass('frozr_gen_src_box_vis');}, 50);
		$('.frozr_gen_src').focus();
		/*hide fav page if open*/
		if ($('.fav_items_open').length > 0) {
		Frozr_Scripts.hide_gen_fav_input();
		}
		
		Frozr_Scripts.add_featured_items();
		Frozr_Scripts.add_featured_rests();
		jQuery("html, body").animate({scrollTop: jQuery('body').offset().top}, 300);
	},
	hide_gen_fav_input: function(e) {
		$('.frozr_page_title .external_page_title').html('').hide();
		$('.frozr_page_title .main_title,.on-mobile .secondary-toggle,.frozr_one_col .secondary-toggle').show();
		$('.frozr_usr_fav_wrapper').removeClass('fav_items_open');
		$('.gen_fav_active').removeClass('gen_fav_active');
		$('.frozr_fav_open_on_store').removeClass('frozr_fav_open_on_store');
	},
	hide_gen_src_input: function(e) {
		$('.gen_src_active').removeClass('gen_src_active');
		$('.frozr_gen_src_box').removeClass('frozr_gen_src_box_vis').hide();
	},
	open_main_menu: function(e) {
		var div = $('#sidebar');
		clearTimeout(open_main_menu_time); 
		var page = $('.ui-page-active');
		if ($('.open_main_menu').length > 0) {
		div.removeClass('open_main_menu');
		page.removeClass('frozr_content_block');
		open_main_menu_time = setTimeout(function(){div.removeClass('fixed_sidebar').hide();}, 450);
		} else {
		div.addClass('fixed_sidebar').show();
		open_main_menu_time = setTimeout(function(){page.addClass('frozr_content_block');div.addClass('open_main_menu');}, 50);
		}
	},
	open_close_filter: function(e) {
		var top_bar_height = $('.frozr_site_navbar').height();
		clearTimeout(open_close_filters);
		if ($('#'+active_page_id+'.vendors_archive .open_filter_box').length > 0) {
			$('#'+active_page_id+'.vendors_archive .filter_box').css('top', '-100%');
			open_close_filters = setTimeout(function(){$('#'+active_page_id+'.vendors_archive .filter_box').removeClass('open_filter_box').hide();}, 450);
			Frozr_Scripts.block_unblock_page(e, $('.ui-page-active main'), true);
		} else {
			$('#'+active_page_id+'.vendors_archive .filter_box').show();
			Frozr_Scripts.block_unblock_page(e, $('.ui-page-active main'), false);
			open_close_filters = setTimeout(function(){$('#'+active_page_id+'.vendors_archive .filter_box').addClass('open_filter_box').css('top', top_bar_height+'px')}, 100);
		}
	},
	remove_atc_qty: function(e){
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parent();
		var input = $('input', wrapper);
		var crnt_val = parseInt(input.val());
		var min_val = parseInt(input.attr('min'));
		if (crnt_val > min_val) {
		input.val(crnt_val-1);
		}
	},
	add_atc_qty: function(e){
		e.preventDefault();
		var self = $(this);
		var wrapper = self.parent();
		var input = $('input', wrapper);
		var crnt_val = parseInt(input.val());
		var max_val = parseInt(input.attr('max'));
		if (!max_val || crnt_val < max_val) {
		input.val(crnt_val+1);
		}
	},
	remove_cart_item: function(e){
		e.preventDefault();

		if ( window.confirm( screenReaderText.remove_cart_item_confirm ) ) {
		var self		= $(this),
			product_key = self.attr('data-cart_item_key'),
			data		= {};

		data.action		= 'frozr_item_remove_from_cart';
		data.itemkey	= product_key;
		data.security	= screenReaderText.remove_cart_item_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Scripts.app_action_loading();},
			complete: function() {Frozr_Scripts.app_action_loading_complete();},
			data: data,
			type: 'POST',
			success: function( response ) {
				if (response.cart_is_empty) {
				$('.frozr_cart_full').html('<div class="empty_cart"><i class="material-icons emmpty_cart_icon">shopping_basket</i>'+response.minicart+'</div>');			
				} else {
				$('.frozr_cart_full').html('<h3>'+screenReaderText.cart+'</h3>'+response.minicart);
				}
				$('.frozr_total_mini_cart').html(response.total);
			},
			error: function( response ) {
				Frozr_Scripts.display_message(screenReaderText.gen_error);
			}
		});
		}
	},
	close_filters: function(e){
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.filter_box, .filter_box *, .rests_filters_btn *') && $('.open_filter_box').length > 0) {
			Frozr_Scripts.open_close_filter(e);
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.rests_src_box, .rests_src_box *, .rests_search, .rests_search *') && $('.rests_src_box_vis').length > 0) {
			$('.rests_src_box').removeClass('rests_src_box_vis').hide();
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.ui-autocomplete, .ui-autocomplete *, .item_atc_popup, .item_atc_popup *, .frozr_item_add_to_cart, .frozr_item_add_to_cart *,.frozr_related_item_link,.frozr_related_item_link *') && $('.item_atc_popup_open').length > 0) {
			Frozr_Scripts.close_atc_popup();
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.frozr_cart_full, .frozr_cart_full *') && $('.frozr_expand_cart').length > 0) {
			Frozr_Scripts.open_close_cart(e);
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,#sidebar, #sidebar *') && $('.open_main_menu').length > 0) {
			Frozr_Scripts.open_main_menu(e);
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,#rest_contact, #rest_contact *') && $('.open_rest_contact').length > 0) {
			Frozr_Scripts.open_rests_contact_box(e);
		}
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.frozr_gen_help_box, .frozr_gen_help_box *, .frozr_popup_help_wrapper, .frozr_popup_help_wrapper *') && $('.frozr_gen_help_box_open').length > 0) {
			$( ".frozr_gen_help_box" ).removeClass("frozr_gen_help_box_open");
			$( ".ui-page-active" ).removeClass("frozr_content_block");
		}
		if(!$(e.target).is('.frozr_no_vend_location_set, .frozr_filter_by_distance_wrapper, .frozr_location_set_wrapper, .frozr_location_set_wrapper *') && $('.frozr_location_set_wrapper_open').length > 0) {
			$( ".frozr_location_set_wrapper" ).removeClass("frozr_location_set_wrapper_open");
			$( ".ui-page-active" ).removeClass("frozr_content_block");
		}
		
		/*close frozrdash general popup*/
		if(!$(e.target).is('.frozrdash_general_popup_open *') && $('.frozrdash_general_popup_loaded').length > 0) {
			Frozr_Scripts.hide_frozrdash_general_popup_box();
		}

	},
	pin_rest_top_bar: function(e) {
		if ($('.frozr_rest_store_page.ui-page-active-loaded').length > 0) {
		var div_position = $('.frozr_store_header').offset().top;
		if ((div_position - $(document).scrollTop()) < 0 && setted_store_name == false) {
			$('.store_page .frozr_page_title').addClass('show_title');
			setted_store_name = true;
		} else if ((div_position - $(document).scrollTop()) > 0) {
			$('.store_page .frozr_page_title').removeClass('show_title');
			setted_store_name = false;
		}
		}
	},
	rests_filters_dragged: function(e) {
		clearTimeout(rests_filters_dragged_time);
		rests_filters_dragged_time = setTimeout(function(){Frozr_Scripts.add_home_rests(e, true, Frozr_Scripts.get_active_vendors_page());}, 100);
	},
	run_rests_src: function(e) {
		var inputfield = $(this);
		var vendors_type = Frozr_Scripts.get_active_vendors_page();
		var container = $('#'+active_page_id+'.vendors_archive');
		clearTimeout(rrstimeoutHandle);

		rrstimeoutHandle = setTimeout(function(){
			var inputdata = inputfield.val();
			var rests_content = Frozr_Scripts.get_vendors(vendors_type);
			var got_item = false;
			var page_title = screenReaderText.src_results;

			if (rests_content && !$.isEmptyObject(rests_content) && inputdata.length > 0) {
				
				$('.vendors_tools .active', container).removeClass('active');
				$('.rests_search', container).parent().addClass('active');
				
				/*Clear any data*/
				$('.frozr_rests_list', container).html('');
				
				$('.vendors_nothing_found, .filter_nothing_found', container).hide();
				
				$.each( rests_content, function( key, value ) {
				var varify = false;
				var filterval = value.name.replace(/&amp/g, "").replace(/[.,\/#!$%\*;:{}=\-_`~()]/g,"").replace(/"/g, "").replace(/'/g, "").toLowerCase();
				var searchstring = inputdata.replace(/&amp/g, "").replace(/[.,\/#!$%\*;:{}=\-_`~()]/g,"").replace(/"/g, "").replace(/'/g, "").toLowerCase();
				
				if (filterval.search(searchstring) > -1) {
					varify = true;
					got_item = true;
				}

				if (varify) {
				Frozr_Scripts.rest_html(key,value,'frozr_rests_list',container,page_title);
				}
				});
				
				if(inputdata.length > 0 && !got_item) {
					$('.filter_nothing_found', container).show();
				}
			} else {
				Frozr_Scripts.add_home_rests(e,false,vendors_type);		
			}
		}, 1000);
	},
	add_home_rests: function(e, filter, vendors_type) {
		clearTimeout(check_for_vendors_time);
		var vendorstype = vendors_type ? vendors_type : Frozr_Scripts.get_active_vendors_page();
		var rests_content = Frozr_Scripts.get_vendors(vendorstype);
		var filter_vendorclass = [];
		var filter_menus = [];
		var got_item = false;
		var added_classes = false;
		var page_title = screenReaderText.all_rests;
		var container = $('#'+active_page_id+'.vendors_archive');
		var check_classes = container.attr('data-classes');
		var del_sellers = Frozr_Scripts.get_location_vals('delsellers');

		if (rests_content && !$.isEmptyObject(rests_content)) {
		/*Clear any data*/
		$('.frozr_rests_list', container).html('');

		/*Get active filters*/
		active_filter_default = $('#rest_vendorclass_filter .active.center .item', container).attr('data-value');
		active_class_filter = active_filter_default ? active_filter_default : $('#rest_vendorclass_filter .active.center .item', container).html();
		active_type_filter = $('#rest_type_filter .active.center .item', container).attr('data-value');

		$('.vendors_nothing_found, .filter_nothing_found', container).hide();
		$('.item.zero_results', container).removeClass('zero_results');
		$('.no_del_found', container).removeClass('no_del_found');
		
		$.each( rests_content, function( key, value ) {
			var varify = false;
			var rests_vendorclass = value.vendorclass.split('- ');
			var accepted_orders = value.accepted_orders_closed;

			if (value.timing_status) {
				accepted_orders = value.accepted_orders;
			}

			/*Filter vendorclass*/
			if (!filter && check_classes != 'added') {
			$.each( rests_vendorclass, function( cukey, cuvalue ) {
				if ($.inArray( cuvalue, filter_vendorclass ) == -1 && cuvalue != '') {
					filter_vendorclass.push(cuvalue);
					$('#rest_vendorclass_filter', container).trigger('add.owl.carousel', ['<li class="truncate item">'+cuvalue+'</li>']);
					added_classes = true;
				}
			});
			}
			
			var rests_vendorclass_array = $.map(rests_vendorclass, function( val, i ) {
				return val.replace(/&amp/g, "").replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").replace(/"/g, "").replace(/'/g, "").replace(/\s{1,}/g, '-').toLowerCase();
			});
			if (filter) {
				var filterone = active_class_filter.replace(/&amp/g, "").replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").replace(/"/g, "").replace(/'/g, "").replace(/\s{1,}/g, '-').toLowerCase();
				if (active_type_filter == 'any' || $.inArray( active_type_filter, accepted_orders ) > -1 && active_type_filter != 'delivery' || active_type_filter == 'delivery' && $.inArray(key,del_sellers) > -1) {
					if (filterone == 'any' || $.inArray( filterone, rests_vendorclass_array ) > -1) {
						varify = true;
						got_item = true;
						page_title = screenReaderText.src_rests;
					}
				}
				$('.vendors_tools .active', container).removeClass('active');
				$('.rest_filters', container).parent().addClass('active');
			} else {
				$('.vendors_tools .active', container).removeClass('active');
				$('.orderby_all_rests', container).parent().addClass('active');
				varify = true;
			}

			if (varify) {
			Frozr_Scripts.rest_html(key,value,'frozr_rests_list',container,page_title);
			} 
		});
		
		if (!filter && added_classes) {
			container.attr('data-classes', 'added');
		}
		
		if(filter && !got_item) {
			$('.filter_nothing_found', container).addClass('no_del_found').show();
			if (active_type_filter == 'delivery') {$('.filter_nothing_found .frozr_current_location', container).show();}else{$('.filter_nothing_found .frozr_current_location', container).hide();}
			$('.home_filter .active.center .item', container).addClass('zero_results');
		}
		
		} else if(no_vendors_yet) {
			$('.filter_nothing_found', container).hide();
			$('.vendors_nothing_found', container).show();
			check_for_vendors_time = setTimeout(function(){Frozr_Scripts.add_home_rests(e, false);}, 1000);		
		} else {
			$('.filter_nothing_found', container).show();
			$('.vendors_nothing_found', container).hide();
		}
	},
	add_top_rests: function(e) {
		e.preventDefault();
		var vendorstype = Frozr_Scripts.get_active_vendors_page();
		var top_rests_content = Frozr_Scripts.get_top_rests();
		var rests_content = Frozr_Scripts.get_vendors(vendorstype);
		var container = $('#'+active_page_id+'.vendors_archive');
		var page_title = screenReaderText.top_rests;

		if(!$.isEmptyObject(top_rests_content) && rests_content && !$.isEmptyObject(rests_content)) {

		/*Clear any data*/
		$('.frozr_rests_list', container).html('');
		$('.vendors_tools .active', container).removeClass('active');
		$('.orderby_top_rated_rests', container).parent().addClass('active');

		$.each( top_rests_content, function( key, value ) {
			var rest_data = rests_content[key];
			if(rest_data) {
			Frozr_Scripts.rest_html(key,rest_data,'frozr_rests_list',container,page_title,'top');
			}
		});
		}
	},
	add_featured_items: function() {
		var feat_items_content = Frozr_Scripts.get_feat_items();
		var container = $('.ui-page-active .frozr_gen_src_wrapper');

		if(!$.isEmptyObject(feat_items_content) && feat_items_content.length > 0) {
			if ($('.frozr_gen_rslt_items_list .items_list_single', container).length == 0) {
			$.each( feat_items_content, function( key, value ) {
				Frozr_Scripts.item_html(key, value, 'frozr_gen_rslt_items_list', 'reco_loop', screenReaderText.feat_items);
			});
			}
		} else {
			if ($('.frozr_gen_rslt_items_list .frozr_no_feats').length == 0) {
			$('.frozr_gen_rslt_items_list').html('<div class="frozr_no_results frozr_no_feats"><i class="material-icons">search</i>'+screenReaderText.search_vendors_items+'</div>');
			}
		}
	},
	add_featured_rests: function() {
		var feat_rests_content = Frozr_Scripts.get_feat_rests();
		var rests_content = Frozr_Scripts.get_vendors();
		var container = $('.ui-page-active .frozr_gen_src_wrapper');

		if(rests_content && !$.isEmptyObject(rests_content) && !$.isEmptyObject(feat_rests_content)) {
			if ($('.frozr_gen_rslt_rests .rests_list_single', container).length == 0) {
			$.each( feat_rests_content, function( key, value ) {
				var rest_data = rests_content[value];
				if (rest_data) {
				Frozr_Scripts.rest_html(value,rest_data,'frozr_gen_rslt_rests',container,screenReaderText.feat_rests);
				}
			});
			}
		} else {
			if ($('.frozr_gen_rslt_rests .frozr_no_feats').length == 0) {
			$('.frozr_gen_rslt_rests').html('<div class="frozr_no_results frozr_no_feats"><i class="material-icons">search</i>'+screenReaderText.search_vendors_items+'</div>');
			}
		}
	},
	add_reco_rests: function(e) {
		e.preventDefault();
		var reco_rests_content = Frozr_Scripts.get_reco_rests();
		var vendorstype = Frozr_Scripts.get_active_vendors_page();
		var rests_content = Frozr_Scripts.get_vendors(vendorstype);
		var container = $('#'+active_page_id+'.vendors_archive');
		var page_title = screenReaderText.reco_rests;

		if(rests_content && !$.isEmptyObject(rests_content) && !$.isEmptyObject(reco_rests_content)) {
		
		/*Clear any data*/
		$('.frozr_rests_list', container).html('');
		$('.vendors_tools .active', container).removeClass('active');
		$('.orderby_reco_rests', container).parent().addClass('active');
		$.each( reco_rests_content, function( key, value ) {
			var rest_data = rests_content[value];
			if (rest_data) {
			Frozr_Scripts.rest_html(value,rest_data,'frozr_rests_list',container,page_title);
			}
		});
		} else {
			Frozr_Scripts.display_message(screenReaderText.no_recommended_rests);
		}
	},
	load_norsani_rests: function() {
		var startaddress = Frozr_Scripts.get_location_vals('usrlocun');
		var data	= {};

		data.action		= 'frozr_get_resturants_data';
		data.user_loc	= startaddress;
		data.security	= screenReaderText.load_norsani_rests_nonce;

		$.ajax({
			beforeSend: function() {Frozr_Scripts.app_action_loading()},
			complete: function() {Frozr_Scripts.app_action_loading_complete()},
			url: screenReaderText.ajax_url,
			data: data,
			type: 'POST',
			success: function( response ) {
				if (response != '') {
					var vendors_data = response.sellers_data;
					var near_vends = response.near_sellers;
					var vendors_classified = {};
					$.each(vendors_data,function(key,value){
						$.each(value,function(xkey,xval){
							vendors_classified[xkey] = xval;
						});
					});
					window.localStorage.setItem("lyzvendorsall", JSON.stringify(vendors_data));
					window.localStorage.setItem("lyzvendors", JSON.stringify(vendors_classified));
					if (response.fav_items) {
					window.localStorage.setItem("lyzfavitems", JSON.stringify(response.fav_items));
					}
					if (response.fav_rests) {
					window.localStorage.setItem("lyzfavrests", JSON.stringify(response.fav_rests));
					}
					window.localStorage.setItem("lyzfeatrests", JSON.stringify(response.featured_rests));
					window.localStorage.setItem("lyzfeatitems", JSON.stringify(response.featured_items));
					window.localStorage.setItem("lyzrecoitems", JSON.stringify(response.reco_items));
					window.localStorage.setItem("lyzrecorests", JSON.stringify(response.reco_rests));
					window.localStorage.setItem("lyztoprests", JSON.stringify(response.top_rests));
					var masterList = near_vends.sort(function(a,b){
						return parseFloat(a.dis) - parseFloat(b.dis);
					});
					window.localStorage.setItem("lyznearrests", JSON.stringify(masterList));
					window.sessionStorage.setItem("lyzrestsloaded",true);
				}
			}, error: function(erre) {
				console.log(erre);
			}
		});
	},
	add_remove_fav_item: function() {
		var data = {};
		var item_id = $(this).attr('data-id');
		var item_wrap = $(this).parents('.items_list_single');
		var item_title = $('.frozr_item_title',item_wrap).html();
		var fav_items = Frozr_Scripts.get_fav_items();
		var confirm_step = true;
		
		if ($('.fav_items_open').length > 0) {
		if ( !window.confirm( screenReaderText.remove_fav_confirm ) ) {
			confirm_step = false;
		}
		}
		
		if (confirm_step) {
		$(this).toggleClass('fav_item');

		if ($('body').hasClass('logged-in')) {
		data.action		= 'frozr_add_item_to_fav';
		data.itemid		= item_id;
		data.security	= screenReaderText.add_item_to_fav_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Scripts.app_action_loading();},
			complete: function() {Frozr_Scripts.app_action_loading_complete();},
			data: data,
			type: 'POST',
			success: function(response) {
				var item_clicked = $('i[data-id="'+item_id+'"]').parents('.items_list_single');
				var fav_class = $('.fav_item', item_clicked);
				
				if (fav_class.length == 0) {
					if ($('.fav_items_open').length > 0) {
						Frozr_Scripts.update_fav_items_list(item_id);
					}
					Frozr_Scripts.display_message(item_title+' '+screenReaderText.item_fav_removed);
				} else {
				Frozr_Scripts.display_message(item_title+' '+screenReaderText.item_fav_added);
				}
				window.localStorage.setItem("lyzfavitems", JSON.stringify(response));
			},
			error: function() {
				$(this).toggleClass('fav_item');
			},
		});
		} else {
			if($.inArray( parseInt(item_id), fav_items ) > -1) {
				fav_items.splice($.inArray(parseInt(item_id), fav_items),1);
				if ($('.fav_items_open').length > 0) {
					Frozr_Scripts.update_fav_items_list(item_id);
				}
				Frozr_Scripts.display_message(item_title+' '+screenReaderText.item_fav_removed);
			} else {
				fav_items.push(item_id);
				Frozr_Scripts.display_message(item_title+' '+screenReaderText.item_fav_added);
			}
			window.localStorage.setItem("lyzfavitems", JSON.stringify(fav_items));
		}
		}
	},
	update_fav_items_list: function(item_id) {
		$('.frozr_usr_fav_rslt_items_list .add_item[data-id="'+item_id+'"]','#'+active_page_id).parents('.items_list_single').remove();
		if ($('.frozr_usr_fav_rslt_items_list .items_list_single','#'+active_page_id).length == 0) {
			$('.frozr_usr_fav_rslt_items_list','#'+active_page_id).html('').hide();
			if ($('.frozr_usr_fav_rslt_items .frozr_no_results','#'+active_page_id).length > 0) {
				$('.frozr_usr_fav_rslt_items .frozr_no_results','#'+active_page_id).show();
			} else {
			$('.frozr_usr_fav_rslt_items', '#'+active_page_id).append('<div class="frozr_no_results"><i class="material-icons">favorite_border</i>'+screenReaderText.no_fav_items+'</div>');
			}
		}
	},
	add_remove_fav_rest: function() {
		var data = {};
		var item_id = $(this).attr('data-id');
		var rest_wrap = $(this).parents('.rests_list_single');
		var rest_title = $('.rest_single .subheader',rest_wrap).html();
		var fav_rests = Frozr_Scripts.get_fav_rests();
		var confirm_step = true;
		
		if ($('.fav_items_open').length > 0) {
		if ( !window.confirm( screenReaderText.remove_fav_confirm ) ) {
			confirm_step = false;
		}
		}
		
		if (confirm_step) {
		
		$(this).toggleClass('fav_item');
		
		if ($('body').hasClass('logged-in')) {
		data.action		= 'frozr_add_rest_to_fav';
		data.itemid		= item_id;
		data.security	= screenReaderText.add_rest_to_fav_nonce;

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Scripts.app_action_loading();},
			complete: function() {Frozr_Scripts.app_action_loading_complete();},
			data: data,
			type: 'POST',
			success: function(response) {
				var item_clicked = $('i[data-id="'+item_id+'"]').parents('.rests_list_single');
				var fav_class = $('.fav_item', item_clicked);
				
				if (fav_class.length == 0) {
				if ($('.fav_items_open').length > 0) {
					Frozr_Scripts.update_fav_rests_list(item_id);
				}
				Frozr_Scripts.display_message(rest_title+' '+screenReaderText.rest_fav_removed);
				} else {
				Frozr_Scripts.display_message(rest_title+' '+screenReaderText.rest_fav_added);
				}
				window.localStorage.setItem("lyzfavrests", JSON.stringify(response));
			},
			error: function() {
				$(this).toggleClass('fav_item');
			},
		});
		} else {
			if($.inArray( parseInt(item_id), fav_rests ) > -1) {
				fav_rests.splice($.inArray(parseInt(item_id), fav_rests),1);
				if ($('.fav_items_open').length > 0) {
					Frozr_Scripts.update_fav_rests_list(item_id);
				}
				Frozr_Scripts.display_message(rest_title+' '+screenReaderText.rest_fav_removed);
			} else {
				fav_rests.push(item_id);
				Frozr_Scripts.display_message(rest_title+' '+screenReaderText.rest_fav_added);
			}
			window.localStorage.setItem("lyzfavrests", JSON.stringify(fav_rests));
		}
		}
	},
	update_fav_rests_list: function(rest_id) {
		var container = $('.frozr_usr_fav_wrapper', '#'+active_page_id);
		$('.frozr_vendors_list_wrapper .add_rest[data-id="'+rest_id+'"]',container).parents('.rests_list_single').remove();
		if ($('.frozr_vendors_list_wrapper .rests_list_single',container).length == 0) {
			$('.frozr_vendors_list_wrapper',container).html('').hide();
			if ($('.frozr_usr_fav_rslt_rests .frozr_no_results',container).length > 0) {
				$('.frozr_usr_fav_rslt_rests .frozr_no_results',container).show();
			} else {
			$('.frozr_usr_fav_rslt_rests', container).html('<div class="frozr_no_results"><i class="material-icons">favorite_border</i>'+screenReaderText.no_fav_rests+'</div>');
			}
		}
	},
	add_fav_rests: function(e) {
		e.preventDefault();
		var fav_rests = Frozr_Scripts.get_fav_rests();
		var vendorstype = Frozr_Scripts.get_active_vendors_page();
		var rests_content = Frozr_Scripts.get_vendors(vendorstype);
		var container = $('#'+active_page_id+'.vendors_archive');
		var page_title = screenReaderText.fav_rests;
		var got_fav_rest = false;
		var results = '';
		
		if (rests_content && !$.isEmptyObject(rests_content) && !$.isEmptyObject(fav_rests)) {
		/*Clear any data*/
		$('.vendors_nothing_found, .filter_nothing_found', container).hide();
		$('.vendors_tools .active', container).removeClass('active');
		$('.orderby_fav_rests', container).parent().addClass('active');

		$.each( fav_rests, function( key, value ) {
			var rest_data = rests_content[value];
			if (rest_data) {
			got_fav_rest = true;
			return false;
			}
		});
		if (got_fav_rest) {
			$('.frozr_rests_list', container).html('');
			$.each( fav_rests, function( key, value ) {
				var rest_data = rests_content[value];
				if (rest_data) {
				Frozr_Scripts.rest_html(value,rest_data,'frozr_rests_list',container,page_title);
				}
			});
		} else {
			Frozr_Scripts.display_message(screenReaderText.no_fav_rests);
		}
		} else {
			Frozr_Scripts.display_message(screenReaderText.no_fav_rests);
		}
	},
	initMainNavigation: function ( container ) {
		// Add dropdown toggle that display child menu items.
		container.find( '.menu-item-has-children > a' ).after( '<button class="dropdown-toggle" aria-expanded="false">' + screenReaderText.expand + '</button>' );

		// Toggle buttons and submenu items with active children menu items.
		container.find( '.current-menu-ancestor > button' ).addClass( 'toggle-on' );
		container.find( '.current-menu-ancestor > .sub-menu' ).addClass( 'toggled-on' );

		$( document ).on( 'click','.mh_logo', function() {
			$('.current-menu-item, .menu-item-has-children').removeClass('current-menu-item current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor');
			container.find( '.current-menu-ancestor > button' ).removeClass( 'toggle-on' );
			container.find( '.current-menu-ancestor > .sub-menu' ).removeClass( 'toggled-on' );
		});
		
		container.on('click', 'ul.nav-menu li a', function(){
			if (!$(this).parent().hasClass('menu-item-has-children')) {
			$('.current-menu-item, .menu-item-has-children').removeClass('current-menu-item current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor');
			$(this).parent().addClass('current_page_item current-menu-item').parents('.menu-item-has-children').addClass('current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor');
			}			
		});

		container.find( '.menu-item-has-children > a, .dropdown-toggle' ).click( function( e ) {
			var wrapper = $(this).parent();
			var _this = $( '.dropdown-toggle', wrapper ).first();
			_this.toggleClass( 'toggle-on' );
			_this.next( '.children, .sub-menu' ).toggleClass( 'toggled-on' );
			_this.attr( 'aria-expanded', _this.attr( 'aria-expanded' ) === 'false' ? 'true' : 'false' );
			_this.html( _this.html() === screenReaderText.expand ? screenReaderText.collapse : screenReaderText.expand );
		});
	},
	reinitMainNavigation: function( e, params ) {
		if ( 'primary' === params.wpNavMenuArgs.theme_location ) {
			Frozr_Scripts.initMainNavigation( params.newContainer );

			// Re-sync expanded status from oldContainer.
			params.oldContainer.find( '.dropdown-toggle.toggle-on' ).each(function() {
				var containerId = $( this ).parent().prop( 'id' );
				$( params.newContainer ).find( '#' + containerId + ' > .dropdown-toggle' ).triggerHandler( 'click' );
			});
		}
	},
	close_popups: function(e){
		if(!$(e.target).is('.frozr_tour_show_info,.frozr_tour_show_info *,.frozr_user_menu, .frozr_user_menu *, .frozr_user_menu_trigger, .frozr_user_menu_trigger *') && $('.frozr_pop_opened').length > 0) {
			Frozr_Scripts.close_user_menu();
		}
	},
	close_user_menu: function() {
		clearTimeout(close_user_menu_time);
		$('.frozr_user_menu').removeClass('frozr_pop_view');
		close_user_menu_time = setTimeout(function(){$('.frozr_pop_opened').removeClass('frozr_pop_opened');}, 100);
	},
	open_dash_menu: function(e){
		e.preventDefault();
		var menu_height = $('.frozr_dash_menu_wrapper > ul').height();
		if ($('.frozr_opened_dash_menu').length > 0) {
		$( ".usr_dash_menu_content" ).removeClass('frozr_opened_dash_menu');
		$( ".frozr_dash_menu_wrapper" ).css('height','0');
		} else {
		$( ".usr_dash_menu_content" ).addClass('frozr_opened_dash_menu');
		$( ".frozr_dash_menu_wrapper" ).css('height',menu_height+'px');
		}
	},
	show_active_order_type: function(e){
		var self = $(this);
		$('.atc_ord_typ_active').removeClass('atc_ord_typ_active');
		$('label',self).addClass('atc_ord_typ_active');
	},
	open_close_cart: function(e){
		clearTimeout(open_quick_cart);
		if($('.frozr_expand_cart').length > 0) {
			$( ".frozr_cart_full" ).removeClass('frozr_expand_cart');
			$('.frozr_close_cart').hide();
			open_quick_cart = setTimeout(function(){$( ".frozr_cart_full" ).hide();},1000);
		} else {
			$('.frozr_cart_full').show().focus();
			open_quick_cart = setTimeout(function(){$( ".frozr_cart_full" ).addClass('frozr_expand_cart');$('.frozr_close_cart').show();},50);
		}
	},
	open_user_menu: function(e){
		e.preventDefault();
		clearTimeout(open_user_menu_time);
		var wrapper = $(this).attr('data-wrapper');
		if ($('.frozr_pop_opened').length > 0) {
			$('.'+wrapper).removeClass('frozr_pop_view');
			open_user_menu_time = setTimeout(function(){$('.frozr_pop_opened').removeClass('frozr_pop_opened');}, 100);
		} else {
			$('.'+wrapper).addClass('frozr_pop_opened');
			open_user_menu_time = setTimeout(function(){$('.frozr_pop_opened').addClass('frozr_pop_view');}, 100);
		}
	},
	show_adtl_input: function(e) {
		e.preventDefault();
		$('.frozr_item_location_wrapper').hide();
		var wrapper = $('.cart.ajax_lazy_submit');
		if ($( "input.curbside_order_l_type", wrapper).prop("checked")) {
			$('.item_ly_options > div').hide();
			$('.item_curbside_option').show();
			if ($( "input.curbside_order_l_type", wrapper).hasClass('show_closed_order_notice')) {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).hide();
			} else {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).show();
			}
		} else if ($( "input.dine-in_order_l_type", wrapper).prop("checked")) {
			$('.item_ly_options > div').hide();
			$('.item_dinein_option').show();
			if ($( "input.dine-in_order_l_type", wrapper).hasClass('show_closed_order_notice')) {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).hide();
			} else {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).show();
			}
		} else if ($( "input.delivery_order_l_type", wrapper).prop("checked")) {
			$('.item_ly_options > div').hide();
			$('.item_del_option').show();
			if ($('.item_del_option .no_delivery_location').length > 0) {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).hide();
				$('.frozr_item_location_wrapper').show();
			} else if ($( "input.delivery_order_l_type", wrapper).hasClass('show_closed_order_notice')) {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).hide();
			} else {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).show();
			}
		} else if ($( "input.pickup_order_l_type", wrapper).prop("checked")) {
			$('.item_ly_options > div').hide();
			$('.item_pickup_option').show();
			if ($( "input.pickup_order_l_type", wrapper).hasClass('show_closed_order_notice')) {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).hide();
			} else {
				$(".item_special_comments_field, .quantity, .single_add_to_cart_button", wrapper).show();
			}
		}
	},
	add_to_cart: function (e) {
		e.preventDefault();
		var self		= $(this),
			wrapper		= self.parent(),
			get_cart	= self.attr('data-get'),
			full_cart	= false,
			data		= {};
		
		if ($('.delivery_order_l_type', wrapper).prop("checked")) {
			var order_type = 'delivery';
		} else {
			var order_type = 'other';
		}
		if (get_cart) {
			full_cart = true;
		}
			
		$('button', self).addClass('fro_adding_to_cart')

		data				= self.serializeJSON();
		data.order_type		= order_type;
		data.getfull		= full_cart;
		data.pid			= self.attr('data-product_id');
		data.action			= 'frozr_ajax_add_to_cart';

		$.ajax({
			url: screenReaderText.ajax_url,
			beforeSend: function() {Frozr_Scripts.app_action_loading();},
			complete: function() {Frozr_Scripts.app_action_loading_complete();},
			data: data,
			type: 'POST',
			success: function( response ) {
				if (response.refresh_page) {
					location.reload(true);
					return false;
				}
				if (response.fragments) {
					var fragments = response.fragments;
					var cart_hash = response.cart_hash;
					$( '.frozr_cart_full' ).html( fragments['#topcart .mini_cart'] );
					$( '.frozr_total_mini_cart' ).html( fragments['amount'] );

					/*refresh cart count*/
					$('.frozr_top_cart_count', document.body).text(response.count_items).show();

					/* Trigger event so themes can refresh other areas*/
					$( document.body ).trigger( 'added_to_cart', [ fragments, cart_hash, self ] );
					
					/*Remove ajax from checkout button*/
					$('.button.checkout').attr('data-ajax','false');
					
					if (response.cross_sells) {
						$('.item_atc_popup.item_atc_popup_open').html(response.cross_sells);
						Frozr_Scripts.set_upsel_widths($('.item_atc_popup.item_atc_popup_open'));
					} else {
					/*close cart popup*/
					Frozr_Scripts.close_atc_popup();
					}
					
					if (response.full_cart) {
						$('.entry-content .woocommerce').html(response.full_cart);
						Frozr_Scripts.set_upsel_widths($('#'+active_page_id));
					}
					
				} else if (response.data != '') {
					Frozr_Scripts.display_message(response.data);
					Frozr_Scripts.close_atc_popup();
				}
			},
			error: function (res) {
				Frozr_Scripts.display_message(screenReaderText.gen_error);
				Frozr_Scripts.close_atc_popup();
			},					
		});
	},
	close_atc_popup: function() {
		$('.pac-container').remove();
		$( ".item_atc_popup" ).removeClass("item_atc_popup_open frozr_content_loading");
		$( ".ui-page-active" ).removeClass("frozr_content_block");
	},
	dismiss_woo_store_notice: function() {
		window.localStorage.setItem("store_notice", 'hidden');
		$( '.woocommerce-store-notice' ).hide();
	},
	auto_order_shop_items: function() {
		$( this ).closest( 'form' ).submit();
	},
	rests_data_session: function () {
		var rests_content = Frozr_Scripts.get_vendors();
		var session_loaded = window.sessionStorage.getItem('lyzrestsloaded');
		if (rests_content && !$.isEmptyObject(rests_content) && session_loaded) {
		return true;
		} else {
		return false;
		}
	},
	get_vendors: function(vendors_type) {
		var len = window.localStorage.getItem("lyzvendors");
		var lenall = window.localStorage.getItem("lyzvendorsall");

		if (!len || len == 'undefined' || len == null) {
			return false;
		}

		var vendors = JSON.parse(len);

		if ($.isArray(vendors) && vendors.length < 1) {
			no_vendors_yet = true;
			return false;
		}

		no_vendors_yet = false;
		var vendors_all = JSON.parse(lenall);

		if (vendors_type) {
			return vendors_all[vendors_type];
		}
		return vendors;
	},
	get_active_vendors_page: function(name_key) {
		var default_active_type = false;

		if (active_page_id) {
		var default_type_split = active_page_id.split('_x_');
		default_active_type = default_type_split[1];
		}
		
		if (default_active_type && default_active_type != 'all') {
		return vendor_type = name_key ? name_key : default_active_type;
		} else {
		return false;
		}
	},
	get_fav_items: function () {
		var empty_array	 = [];
		var len = window.localStorage.getItem("lyzfavitems");

		if (len == 'undefined' || len == null) {
			return empty_array;
		}
		var favs = JSON.parse(len);
		return $.map( favs, function( val, i ) {return parseInt(val);});
	},
	get_fav_rests: function () {
		var empty_array = [];
		var len = window.localStorage.getItem("lyzfavrests");

		if (len == 'undefined' || len == null) {
			return empty_array;
		}
		var favs = JSON.parse(len);
		return $.map( favs, function( val, i ) {return parseInt(val);});
	},
	get_near_rests: function () {
		var len = window.localStorage.getItem("lyznearrests");

		if (len == 'undefined' || len == null) {
			return false;
		}
		var vendors = JSON.parse(len);
		
		if ($.isArray(vendors) && vendors.length < 1) {
			return false;
		}

		return vendors;
	},
	get_top_rests: function () {
		var vendors_type = Frozr_Scripts.get_active_vendors_page();
		var len = window.localStorage.getItem("lyztoprests");

		if (len == 'undefined' || len == null) {
			return false;
		}
		var vendors = JSON.parse(len);
		
		if ($.isArray(vendors) && vendors.length < 1) {
			return false;
		}

		return vendors[vendors_type];
	},
	get_feat_items: function () {
		var empty_array	 = [];
		var len = window.localStorage.getItem("lyzfeatitems");

		if (len == 'undefined' || len == null) {
			return empty_array;
		}
		return JSON.parse(len);
	},
	get_feat_rests: function () {
		var vendors_type = Frozr_Scripts.get_active_vendors_page();
		var len = window.localStorage.getItem("lyzfeatrests");
		var vendors_new_array = [];

		if (len == 'undefined' || len == null) {
			return false;
		}
		var vendors = JSON.parse(len);
		
		if ($.isArray(vendors) && vendors.length < 1) {
			return false;
		}
		var dep_vendors = vendors[vendors_type];
		if (vendors_type && dep_vendors && dep_vendors.length > 0) {
			return vendors[vendors_type];
		} else {
			$.each(vendors,function(key,val) {
				$.each(val,function(xk,xv) {
				vendors_new_array.push(xv);	
				});
			});
			return vendors_new_array;
		}
	},
	get_reco_rests: function () {
		var vendors_type = Frozr_Scripts.get_active_vendors_page();
		var len = window.localStorage.getItem("lyzrecorests");

		if (len == 'undefined' || len == null) {
			return false;
		}
		var vendors = JSON.parse(len);
		
		if ($.isArray(vendors) && vendors.length < 1) {
			return false;
		}
		
		return vendors[vendors_type];
	},
	get_reco_items: function () {
		var empty_array	 = [];
		var len = window.localStorage.getItem("lyzrecoitems");

		if (len == 'undefined' || len == null) {
			return empty_array;
		}
		return JSON.parse(len);
	},
	get_location_vals: function (type) {
		var empty_array	 = [];
		var frozr_del_sellers = window.localStorage.getItem("frozr_del_sellers");
		var frozr_user_location = window.localStorage.getItem("frozr_user_location");
		var frozr_user_location_unslashed = window.localStorage.getItem("frozr_user_location_unslashed");
		
		if (type == 'delsellers') {
		if (frozr_del_sellers == 'undefined' || frozr_del_sellers == null) {
			return empty_array;
		} else {
			return JSON.parse(frozr_del_sellers);
		}
		}
		
		if (type == 'usrloc') {
		if (frozr_user_location == 'undefined' || frozr_user_location == null) {
			return false;
		} else {
			return frozr_user_location;
		}
		}
		
		if (type == 'usrlocun') {
		if (frozr_user_location_unslashed == 'undefined' || frozr_user_location_unslashed == null) {
			return false;
		} else {
			return frozr_user_location_unslashed;
		}
		}
		return false;
	},
	item_view_saved: function () {
		var len = window.localStorage.getItem("lyzitemview");

		if (len == 'undefined' || len == null || !len) {
			return false;
		}
		return JSON.parse(len);
	}
	};
	Frozr_Scripts.init();

})( jQuery );

var addComment = {
	moveForm: function( commId, parentId, respondId, postId ) {
		var div, element, style, cssHidden,
			t			= this,
			comm		= t.I( commId ),
			respond		= t.I( respondId ),
			cancel		= t.I( 'cancel-comment-reply-link' ),
			parent		= t.I( 'comment_parent' ),
			post		= t.I( 'comment_post_ID' ),
			commentForm = respond.getElementsByTagName( 'form' )[0];

		if ( ! comm || ! respond || ! cancel || ! parent || ! commentForm ) {
			return;
		}

		t.respondId = respondId;
		postId = postId || false;

		if ( ! t.I( 'wp-temp-form-div' ) ) {
			div = document.createElement( 'div' );
			div.id = 'wp-temp-form-div';
			div.style.display = 'none';
			respond.parentNode.insertBefore( div, respond );
		}

		comm.parentNode.insertBefore( respond, comm.nextSibling );
		if ( post && postId ) {
			post.value = postId;
		}
		parent.value = parentId;
		cancel.style.display = '';

		cancel.onclick = function() {
			var t		= addComment,
				temp	= t.I( 'wp-temp-form-div' ),
				respond = t.I( t.respondId );

			if ( ! temp || ! respond ) {
				return;
			}

			t.I( 'comment_parent' ).value = '0';
			temp.parentNode.insertBefore( respond, temp );
			temp.parentNode.removeChild( temp );
			this.style.display = 'none';
			this.onclick = null;
			return false;
		};

		/*
		 * Set initial focus to the first form focusable element.
		 * Try/catch used just to avoid errors in IE 7- which return visibility
		 * 'inherit' when the visibility value is inherited from an ancestor.
		 */
		try {
			for ( var i = 0; i < commentForm.elements.length; i++ ) {
				element = commentForm.elements[i];
				cssHidden = false;

				// Modern browsers.
				if ( 'getComputedStyle' in window ) {
					style = window.getComputedStyle( element );
				// IE 8.
				} else if ( document.documentElement.currentStyle ) {
					style = element.currentStyle;
				}

				/*
				 * For display none, do the same thing jQuery does. For visibility,
				 * check the element computed style since browsers are already doing
				 * the job for us. In fact, the visibility computed style is the actual
				 * computed value and already takes into account the element ancestors.
				 */
				if ( ( element.offsetWidth <= 0 && element.offsetHeight <= 0 ) || style.visibility === 'hidden' ) {
					cssHidden = true;
				}

				// Skip form elements that are hidden or disabled.
				if ( 'hidden' === element.type || element.disabled || cssHidden ) {
					continue;
				}

				element.focus();
				// Stop after the first focusable element.
				break;
			}

		} catch( er ) {}

		return false;
	},
	I: function( id ) {
		return document.getElementById( id );
	}
};