<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Learn more: {@link https://codex.wordpress.org/Template_Hierarchy}
 *
 * @package Norsani
 * @subpackage Themes
 * @since FrozrDash 1.0
 */

get_header(); ?>
<div data-role="page" id="primary" class="content-area">
<?php frozr_fixed_cart(true); ?>
<?php frozr_general_search_result(); ?>
<?php frozr_user_favs(); ?>
<div data-id="finde" style="display:none"><?php echo __('Home','frozrdash'); ?></div>
<main class="site-main" role="main">
<?php if ( have_posts() ) :
if ( is_home() && ! is_front_page() ) : ?>
<header><h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1></header>
<?php endif;
while ( have_posts() ) : the_post();
get_template_part( 'content', get_post_format() );
endwhile;
the_posts_pagination( array(
'prev_text'=> __( 'Previous page', 'frozrdash' ),
'next_text'=> __( 'Next page', 'frozrdash' ),
'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'frozrdash' ) . ' </span>',
));
else :
get_template_part( 'content', 'none' );
endif;
?>
</main><!-- .site-main -->
</div><!-- .content-area -->
<?php get_footer();