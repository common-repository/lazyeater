<?php
/**
 * FrozrDash functions and definitions
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package Norsani
 * @subpackage Themes
 * @since FrozrDash 1.0
 */

/**
 * FrozrDash only works in WordPress 4.1 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.1-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}
if ( ! function_exists( 'frozrdash_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * @since FrozrDash 1.0
 */
function frozrdash_setup() {
	/*
	 * Make theme available for translation.
	 */
	load_theme_textdomain( 'frozrdash', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );
	
	/*Add WooCommerce support*/
	add_theme_support('woocommerce');

	// Add support for Frozr Norsani plugin
	add_theme_support( 'frozr-norsani' );
	
	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * See: https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 825, 510, true );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __('Primary Menu','frozrdash'),
		'social'  => __('Social Links Menu','frozrdash'),
		'footer'  => __('Footer Menu','frozrdash'),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
	));

	/*
	 * Enable support for custom logo.
	 *
	 * @since FrozrDash 1.5
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 248,
		'width'       => 248,
		'flex-height' => true,
	) );

	$color_scheme  = frozr_get_color_scheme();
	$default_color = trim( $color_scheme[0], '#' );

	// Setup the WordPress core custom background feature.

	/**
	 * Filter FrozrDash custom-header support arguments.
	 *
	 * @since FrozrDash 1.0
	 *
	 * @param array $args {
	 *     An array of custom-header support arguments.
	 *
	 *     @type string $default-color     		Default color of the header.
	 *     @type string $default-attachment     Default attachment of the header.
	 * }
	 */
	add_theme_support( 'custom-background', apply_filters( 'frozr_custom_background_args', array(
		'default-color'      => $default_color,
		'default-attachment' => 'fixed',
	) ) );

	// Indicate widget sidebars can use selective refresh in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif; // frozrdash_setup
add_action( 'after_setup_theme', 'frozrdash_setup' );

/**
 * Register widget area.
 *
 * @since FrozrDash 1.0
 *
 * @link https://codex.wordpress.org/Function_Reference/register_sidebar
 */
function frozr_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Widget Area', 'frozrdash' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'frozrdash' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'frozr_widgets_init' );

/**
 * JavaScript Detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
 * @since FrozrDash 1.1
 */
function frozr_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'frozr_javascript_detection', 0 );

/*Disable WooCommerce style sheets*/
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * Enqueue scripts and styles.
 *
 * @since FrozrDash 1.0
 */
function frozr_scripts() {

	// Load our main stylesheet.
	wp_enqueue_style( 'jquery-mobile-cus', get_template_directory_uri() . '/css/jquery.mobile.custom.structure.min.css', array(), '4.5' );
	wp_enqueue_style( 'owl-style', get_template_directory_uri() . '/css/owl.carousel.min.css', array(), '3.2' );
	wp_enqueue_style( 'main-styles',  get_template_directory_uri() . '/css/main.css', array(), '0.1' );
	wp_enqueue_style( 'frozr-style', get_stylesheet_uri() );

	// Load the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'frozr-ie', get_template_directory_uri() . '/css/ie.css', array( 'frozr-style' ), '20141010' );
	wp_style_add_data( 'frozr-ie', 'conditional', 'lt IE 9' );

	// Load the Internet Explorer 7 specific stylesheet.
	wp_enqueue_style( 'frozr-ie7', get_template_directory_uri() . '/css/ie7.css', array( 'frozr-style' ), '20141010' );
	wp_style_add_data( 'frozr-ie7', 'conditional', 'lt IE 8' );

	wp_enqueue_script( 'frozr-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20141010', true );

	if ( is_singular() && wp_attachment_is_image() ) {
		wp_enqueue_script( 'frozr-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20141010' );
	}
	
	if (!frozr_theme_is_one_column()) {
	wp_enqueue_style( 'frozr-classic-layout', get_template_directory_uri() . '/css/classic.css', array( 'frozr-style' ), '20141010' );
	} elseif (frozr_theme_is_one_column() && !frozr_mobile()) {
	wp_enqueue_style( 'frozr-one_col-layout', get_template_directory_uri() . '/css/one_col.css', array( 'frozr-style' ), '20141010' );
	}

	wp_enqueue_script( 'jquery-mobile-cus', get_template_directory_uri() . '/js/jquery.mobile.custom.min.js', array(), '4.5', true );
	wp_enqueue_script( 'owl', get_template_directory_uri() . '/js/owl.carousel.min.js', array( 'jquery' ), '20150330', true );
	wp_enqueue_script( 'frozr-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20150330', true );
	
	$dis_option = get_option( 'frozr_dis_settings' );
	$location_update_link = !empty($_SERVER['HTTPS']) ? ' <a class="frozr_set_loc_pop_link" href="#" title="'. __('Change your location','frozrdash').'">'. __('Update Location?','frozrdash').'</a>' : '';
	wp_localize_script( 'frozr-script', 'screenReaderText', array(
		'ajax_url'					=> admin_url( 'admin-ajax.php' ),
		'expand'					=> '<span class="screen-reader-text">' . __( 'expand child menu', 'frozrdash' ) . '</span>',
		'collapse'					=> '<span class="screen-reader-text">' . __( 'collapse child menu', 'frozrdash' ) . '</span>',
		'frozr_general_src_nonce'	=> wp_create_nonce( 'frozr_general_src_sec' ),
		'frozr_general_fav_nonce'	=> wp_create_nonce( 'frozr_general_fav_sec' ),
		'frozr_reg_form_nonce'		=> wp_create_nonce( 'frozr_reg_form' ),
		'post_comment_nonce'		=> wp_create_nonce( 'frozr_post_ajax_comment' ),
		'no_top_rests'				=> __( 'No vendors found in the top rated vendors list.', 'frozrdash' ),
		'no_fav_items'				=> get_current_user_id() > 0 ? __( "Your favorite products list will be here", 'frozrdash' ): __( 'Create an account and add products to your favorites to see them here.', 'frozrdash' ),
		'no_fav_rests'				=> get_current_user_id() > 0 ? __( "Your favorite vendors list will be here", 'frozrdash' ): __( 'Create an account and add vendors to your favorites to see them here.', 'frozrdash' ),
		'no_recommended_rests'		=> get_current_user_id() > 0 ? __( 'Recommended vendors list will be shown after you make your first purchase.', 'frozrdash' ): __( 'Recommended vendors list will be shown after you create your account and make your first purchase.', 'frozrdash' ),
		'i18n_required_rating_text'	=> esc_attr__( 'Please select a rating', 'frozrdash' ),
		'review_rating_required'	=> get_option( 'woocommerce_review_rating_required' ),
		'gen_error'					=> __( 'Something went wrong! Please try again.', 'frozrdash' ),
		'fill_email_address'		=> __( 'Please fill your email address.', 'frozrdash' ),
		'fill_shopname'				=> __( 'Please fill your store name.', 'frozrdash' ),
		'fill_password'				=> __( 'Please fill your password.', 'frozrdash' ),
		'name'						=> __( 'Name', 'frozrdash' ),
		'rstatus'					=> __( 'Status', 'frozrdash' ),
		'rating'					=> __( 'Rating', 'frozrdash' ),
		'category'					=> __( 'Category', 'frozrdash' ),
		'menu'						=> __( 'Menu', 'frozrdash' ),
		'all_rests'					=> __( 'All vendors', 'frozrdash' ),
		'src_rests'					=> __( 'Filter results', 'frozrdash' ),
		'src_results'				=> __( 'Search results', 'frozrdash' ),
		'reco_rests'				=> __( 'Recommended vendors', 'frozrdash' ),
		'delt_rests'				=> __( 'Listed by fastest delivery time', 'frozrdash' ),
		'fav_items'					=> __( 'Favorite products', 'frozrdash' ),
		'fav_rests'					=> __( 'Favorite vendors', 'frozrdash' ),
		'top_rests'					=> __( 'Top vendors', 'frozrdash' ),
		'feat_rests'				=> __( 'Featured vendors', 'frozrdash' ),
		'feat_items'				=> __( 'Featured products', 'frozrdash' ),
		'no_rests'					=> __( 'No vendors found :(', 'frozrdash' ),
		'no_items'					=> __( 'No products found :(', 'frozrdash' ),
		'vendor'					=> __( 'vendor', 'frozrdash' ),
		'remove_fav_confirm'		=> __( 'Are you sure you want to remove this from your favorites?', 'frozrdash' ),
		'remove_cart_item_confirm'	=> __( 'Are you sure you want to remove this product from cart?', 'frozrdash' ),
		'vendor_open'				=> __( 'Open', 'frozrdash' ),
		'vendor_closed'				=> __( 'Closed', 'frozrdash' ),
		'cart'						=> __( 'Cart', 'frozrdash' ),
		'item_fav_added'			=> __( 'was added to your favorites.', 'frozrdash' ),
		'item_fav_removed'			=> __( 'was removed from your favorites.', 'frozrdash' ),
		'rest_fav_added'			=> __( 'was added to your favorites.', 'frozrdash' ),
		'rest_fav_removed'			=> __( 'was removed from your favorites.', 'frozrdash' ),
		'menu_no_items'				=> __( 'Sorry, no products found in this menu.', 'frozrdash' ),
		'geo_locate_me_notice'		=> __( "Geolocation service access is required to complete this step. Do you want to continue?", 'frozrdash' ),
		'norsani_not_exisit'		=> __( "We couldn't find Norsani to start :(", "frozrdash" ),
		'order_by_distance'			=> __( "Sort by distance", "frozrdash" ),
		'search_vendors_items'		=> __( "Search Vendors & Products", "frozrdash" ),
		'theme_is_one_column'		=> frozr_theme_is_one_column() ? 1: 0,
		'frozr_rtl'					=> is_rtl() ? 1 : 0,
		'color_scheme'				=> get_theme_mod('color_scheme'),
		'ajax_nav'					=> get_theme_mod('frozr_ajax_nav'),
		'norsani_exisit'			=> class_exists('Frozr_Norsani') ? 1 : 0,
		'is_tablet'								=> frozr_tablet(),
		'is_mobile'								=> frozr_mobile(),
		'frozr_add_new_page_count_nonce'		=> wp_create_nonce( 'frozr_add_new_page_count' ),
		'frozr_set_user_loc_nonce'				=> wp_create_nonce( 'frozr_set_user_loc' ),
		'distance_help_cal'						=> __( "This is an estimate calculation for the delivery duration to your location", 'frozrdash' ),
		'free_delivery'							=> __( 'Free Delivery', 'frozrdash' ),
		'del_fee_help_free'						=> __( "This vendor provides free delivery service.", 'frozrdash' ),
		'currency'								=> get_woocommerce_currency_symbol(),
		'ord_per'								=> __( 'per', 'frozrdash' ),
		'out_of_rang'							=> __( "Out of range", "frozrdash" ),
		'out_of_rang_desc'						=> __( "Your current location is out of range of this vendor's delivery service.", "frozrdash" ),
		'del_fee_help'							=> __( "The delivery fee multiplied with the total distance to your location.", 'frozrdash' ),
		'distance_travelmode'					=> (! empty( $dis_option['frozr_norsani_distance_travelmode']) ) ? $dis_option['frozr_norsani_distance_travelmode'] : 'DRIVING',
		'distance_unitsystem'					=> (! empty( $dis_option['frozr_norsani_distance_unitsystem']) ) ? $dis_option['frozr_norsani_distance_unitsystem'] : 'google.maps.UnitSystem.METRIC',
		'distance_avoidhighways'				=> (! empty( $dis_option['frozr_norsani_distance_avoidhighways']) ) ? 'true' : 'false',
		'distance_avoidtolls'					=> (! empty( $dis_option['frozr_norsani_distance_avoidtolls']) ) ? 'true' : 'false',
		'distance_divider'						=> norsani()->vendor->frozr_distance_divider(true),
		'frozr_add_new_distance_sec'			=> wp_create_nonce( 'frozr_add_new_distance_nonce' ),
		'geolocation_failed_distance'			=> __( 'Unsupported location', 'frozrdash' ),
		'geolocation_error_distance'			=> __( 'Server error', 'frozrdash' ),
		'geolocation_error_distance_help'		=> __( "We couldn't calculate the delivery duration between your location and this vendor due to a server or internet connection error.", "frozrdash" ),
		'unsupported_loc_help'					=> __( "Your location is not within the delivery zone of this vendor.", 'frozrdash' ).$location_update_link,
		'geolocation_error_fee_help'			=> __( "We couldn't calculate the delivery fee of this vendor due to a server or internet connection error.", "frozrdash" ),
		'geolocation_no_connection'				=> __( 'No Connection!', 'frozrdash' ),
		'geolocation_connection_help'			=> __( 'Please check your internet connection and try again.', 'frozrdash' ),
		'load_norsani_rests_nonce'				=> wp_create_nonce( 'load_norsani_rests' ),
		'frozr_sellers_locs'					=> frozr_get_all_sellers_locations('filtered'),
		'frozr_set_user_loc_nonce'				=> wp_create_nonce( 'frozr_set_user_loc' ),
		'geocoder_address_not_found'			=> __( 'No address found for your location.', 'frozrdash' ),
		'geo_position_unavailable'				=> __( 'Your location information is unavailable!', 'frozrdash' ),
		'geo_over_query_limit'					=> __( 'We could not set your location due to query limit. Please try setting it manually.', 'frozrdash' ),
		'geo_request_denied'					=> __( 'The location was not set due to denied request. Please try again later.', 'frozrdash' ),
		'geo_invalid_request'					=> __( 'The location was not set due to invalid request. Please try again later.', 'frozrdash' ),
		'geo_cod_unknown_error'					=> __( 'Could not set your address due to an unknown error. Please try again later.', 'frozrdash' ),
		'geolocation_failed'					=> __( 'Error: The Geolocation service failed.', 'frozrdash' ),
		'geo_access_denied'						=> __( 'Geolocation Access Denied. Please enable the geolocation service on your device.', 'frozrdash' ),
		'geo_timeout'							=> __( 'Geolocation failed, maybe due to a slow internet connection.', 'frozrdash' ),
		'geo_unknown_error'						=> __( 'Geolocation failed due to an unknown error. Please try again later.', 'frozrdash' ),
		'geolocation_not_support'				=> __( "Error: Your browser doesn't support geolocation.", "frozrdash" ),
		'geolocation_failed_connection'			=> __( 'Please check your internet connection and try again.', 'frozrdash' ),
		'remove_cart_item_nonce'				=> wp_create_nonce( 'remove_cart_item' ),
		'add_item_to_fav_nonce'					=> wp_create_nonce( 'add_item_to_fav' ),
		'add_rest_to_fav_nonce'					=> wp_create_nonce( 'add_rest_to_fav' ),
	) );
	
	if ( user_can( get_current_user_id(), 'frozer' ) || frozr_is_seller_enabled(get_current_user_id()) || is_super_admin() ) {
		wp_enqueue_script( 'frozr-dashboard-script', get_template_directory_uri() . '/js/dashboard-functions.js', array( 'jquery' ), '20150330', true );
		$vendor_org_sts = norsani()->vendor->frozr_vendors_open_close(get_current_user_id());
		wp_localize_script( 'frozr-dashboard-script', 'screenReaderTextDash', array(
			'orders_check_error'		=> __( "We couldn't check for new orders!", "frozrdash" ),
			'checking_for_orders'		=> __( 'Checking for orders...', 'frozrdash' ),
			'offline'					=> __( 'Offline', 'frozrdash' ),
			'online'					=> __( 'Online', 'frozrdash' ),
			'make'						=> __( 'Make', 'frozrdash' ),
			'tour_close'				=> __( 'Close', 'frozrdash' ),
			'tour_next'					=> __( 'Next', 'frozrdash' ),
			'tour_dash_info'			=> __( 'This is your dashboard where you can find useful statistics on your sales.', 'frozrdash' ),
			'tour_menu_btn'				=> __( 'Click the menu button to navigate between your dashboard pages.', 'frozrdash' ),
			'tour_menu'					=> __( "This is your dashboard's navigation menu.", "frozrdash" ),
			'tour_actions_menu'			=> __( "Finally, This is your main actions menu. Whenever you are 'online' people will be able to make orders from your store.", 'frozrdash' ),
			'tour_close_confirm'		=> __( "Navigating away will close the tour. Do you want to continue?", 'frozrdash' ),
			'new_order_notice'			=> __( 'You recieved a new order.','frozrdash').' <a href="'.home_url('/dashboard/orders').'" title="'.__('Navigate to orders page','frozrdash').'">'.__('Navigate to orders page?','frozrdash').'</a>',
			'online_status_duration'	=> __( 'Please enter how many minutes you wish to stay "online". i.e: 60', 'frozrdash' ),
			'offline_status_duration'	=> __( 'Please enter how many minutes you wish to stay "offline". i.e: 60', 'frozrdash' ),
			'status_dur_error'			=> __( 'You must enter a number of minutes to stay with your new status', 'frozrdash' ),
			'vendor_orignal_sts'		=> $vendor_org_sts[1] ? 'online' : 'offline',
			'manual_online'				=> frozr_manual_vendor_online() ? 1 : 0,
			'checking_payouts'			=> esc_js( __( 'Updating PayPal Payouts statuses...', 'frozrdash' )),
			'regular_price_notice'		=> esc_js( __( 'This option has been disabled because the product has variations.', 'frozrdash' )),
			'gen_error_concole'			=> esc_js( __( 'Something went wrong, please check your browser console for more info.', 'frozrdash' )),
			'frozr_check_payouts_nonce'	=> wp_create_nonce( 'frozr_check_payouts_sec' ),
			'update_orders_count_nonce'	=> wp_create_nonce( 'update_orders_count' ),
			'norsani_check_new_orders'	=> wp_create_nonce( 'norsani_check_new_orders' ),
			'norsani_change_product_status'	=> wp_create_nonce( 'norsani_change_product_status' ),
			'norsani_add_product_special'	=> wp_create_nonce( 'norsani_add_product_special' ),
			'norsani_save_vendor_status'	=> wp_create_nonce( 'norsani_save_vendor_status' ),
			'active_payout'				=> frozr_payout_active() ? 1 : 0,
		) );
	}
	
	wp_dequeue_script( 'comment-reply' );
	
	//remove generator meta tag
	remove_action( 'wp_head', array( $GLOBALS['woocommerce'], 'generator' ) );
 
	//first check that woo exists to prevent fatal errors
	if ( function_exists( 'is_woocommerce' ) ) {
		//dequeue scripts and styles
		wp_dequeue_script( 'wc_price_slider' );
		wp_dequeue_script( 'wc-single-product' );
		wp_dequeue_script( 'wc-cart-fragments' );
		wp_dequeue_script( 'wc-add-to-cart' );
		wp_dequeue_script( 'wc-add-to-cart-variation' );
		wp_dequeue_script( 'wc-chosen' );
		wp_dequeue_script( 'wc-cart' );
		wp_dequeue_script( 'woocommerce' );
		wp_dequeue_script( 'prettyPhoto' );
		wp_dequeue_script( 'prettyPhoto-init' );
		wp_dequeue_script( 'jquery-blockui' );
		wp_dequeue_script( 'jquery-placeholder' );
		wp_dequeue_script( 'fancybox' );
		wp_dequeue_script( 'wc-lost-password' );
		wp_dequeue_style( 'woocommerce_frontend_styles' );
		wp_dequeue_style( 'woocommerce-general');
		wp_dequeue_style( 'woocommerce-layout' );
		wp_dequeue_style( 'woocommerce-smallscreen' );
		wp_dequeue_style( 'woocommerce_fancybox_styles' );
		wp_dequeue_style( 'woocommerce_prettyPhoto_css' );

		if (!is_checkout()) {
		wp_dequeue_script( 'wc-checkout' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'frozr_scripts' );

/**
 * Add featured image as background image to post navigation elements.
 *
 * @since FrozrDash 1.0
 *
 * @see wp_add_inline_style()
 */
function frozr_post_nav_background() {
	if ( ! is_single() ) {
		return;
	}

	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );
	$css      = '';

	if ( is_attachment() && 'attachment' == $previous->post_type ) {
		return;
	}

	if ( $previous &&  has_post_thumbnail( $previous->ID ) ) {
		$prevthumb = wp_get_attachment_image_src( get_post_thumbnail_id( $previous->ID ), 'post-thumbnail' );
		$css .= '
			.post-navigation .nav-previous { background-image: url(' . esc_url( $prevthumb[0] ) . '); }
			.post-navigation .nav-previous .post-title, .post-navigation .nav-previous a:hover .post-title, .post-navigation .nav-previous .meta-nav { color: #fff; }
			.post-navigation .nav-previous a:before { background-color: rgba(0, 0, 0, 0.4); }
		';
	}

	if ( $next && has_post_thumbnail( $next->ID ) ) {
		$nextthumb = wp_get_attachment_image_src( get_post_thumbnail_id( $next->ID ), 'post-thumbnail' );
		$css .= '
			.post-navigation .nav-next { background-image: url(' . esc_url( $nextthumb[0] ) . '); border-top: 0; }
			.post-navigation .nav-next .post-title, .post-navigation .nav-next a:hover .post-title, .post-navigation .nav-next .meta-nav { color: #fff; }
			.post-navigation .nav-next a:before { background-color: rgba(0, 0, 0, 0.4); }
		';
	}

	wp_add_inline_style( 'frozr-style', $css );
}
add_action( 'wp_enqueue_scripts', 'frozr_post_nav_background' );

/**
 * Display descriptions in main navigation.
 *
 * @since FrozrDash 1.0
 *
 * @param string  $item_output The menu item output.
 * @param WP_Post $item        Menu item object.
 * @param int     $depth       Depth of the menu.
 * @param array   $args        wp_nav_menu() arguments.
 * @return string Menu item with possible description.
 */
function frozr_nav_description( $item_output, $item, $depth, $args ) {
	if ( 'primary' == $args->theme_location && $item->description ) {
		$item_output = str_replace( $args->link_after . '</a>', '<div class="menu-item-description">' . $item->description . '</div>' . $args->link_after . '</a>', $item_output );
	}

	return $item_output;
}
add_filter( 'walker_nav_menu_start_el', 'frozr_nav_description', 10, 4 );

/**
 * Add a `screen-reader-text` class to the search form's submit button.
 *
 * @since FrozrDash 1.0
 *
 * @param string $html Search form HTML.
 * @return string Modified search form HTML.
 */
function frozr_search_form_modify( $html ) {
	return str_replace( 'class="search-submit"', 'class="search-submit screen-reader-text"', $html );
}
add_filter( 'get_search_form', 'frozr_search_form_modify' );

/**
 * Add item add to cart data to location set return ajax response.
 *
 * @since FrozrDash 1.0
 *
 * @param return location function response json array.
 * @param $_POST location set function data.
 * @return array Modified location set function response.
 */
function frozr_get_atc_after_locaation_set( $return, $data ) {
	$product_id = intval ($data['ritem']);

	if ($product_id > 0) {
		$product_obj = wc_get_product($product_id);		
		$return['atc_new_form'] = woocommerce_template_loop_add_to_cart($product_obj);
	}
	return $return;
}
add_filter( 'frozr_user_locaation_set', 'frozr_get_atc_after_locaation_set',10,2 );

add_action('frozr_after_save_user_location', 'frozr_add_user_geo_location',10,1);
function frozr_add_user_geo_location($data ) {
	$user_geo_loc = !empty($data['locgeo']) ? esc_attr($data['locgeo']) : '';
	wc_setcookie('frozr_user_geo_location', $user_geo_loc, time() + (86400 * 30), false);
}
/**
 * Modifies tag cloud widget arguments to display all tags in the same font size
 * and use list format for better accessibility.
 *
 * @since FrozrDash 1.9
 *
 * @param array $args Arguments for tag cloud widget.
 * @return array The filtered arguments for tag cloud widget.
 */
function frozr_widget_tag_cloud_args( $args ) {
	$args['largest']  = 22;
	$args['smallest'] = 8;
	$args['unit']     = 'pt';
	$args['format']   = 'list';

	return $args;
}
add_filter( 'widget_tag_cloud_args', 'frozr_widget_tag_cloud_args' );

function frozr_user_menu_modified( $args ) {
	unset($args['edit-address']);
	unset($args['dashboard']);
	unset($args['downloads']);
	$store_array = array();
	
	if (user_can( get_current_user_id(), 'frozer' ) && class_exists('Frozr_Norsani') && frozr_is_seller_enabled(get_current_user_id())) {
		$store_array = array("ly-store"=> __( 'View Store', 'frozrdash' ));
	}
	
	if ( class_exists('Frozr_Norsani') && user_can( get_current_user_id(), 'frozer' ) || class_exists('Frozr_Norsani') && frozr_is_seller_enabled(get_current_user_id()) ) {
		$args['orders'] = __('My purchases','frozrdash');
		$args = array("ly-dashboard"=> __( 'Dashboard', 'frozrdash' ),'vendor_orders' =>__('Orders','frozrdash')) + $store_array + $args;
	}

	return $args;
}
add_filter( 'woocommerce_account_menu_items', 'frozr_user_menu_modified',10,1 );

function frozr_login_redirect( $redirect_to, $user ) {
	if ( user_can( $user->ID, 'frozer' ) || frozr_is_seller_enabled($user->ID) ) {
		$redirect_to = home_url() . '/dashboard/home/';
	} else {
		$redirect_to = home_url();
	}
	return $redirect_to;
}
add_filter('woocommerce_login_redirect', 'frozr_login_redirect',10,2);

function frozr_get_vendor_dashboard_menu() {
	// Simply hook the menu action
	do_action('frozr_norsani_admin_dashboard_menu', true);
}

function frozr_dashboard_menu_title($text, $title) {
	$text = '<i class="material-icons">add</i> ' . sprintf(__('%s Dashboard','frozrdash'), $title);
	return $text;
}
add_filter('frozr_your_dashboard_text', 'frozr_dashboard_menu_title',10,2);

/*add user location to checkout form*/
add_filter('woocommerce_default_address_fields','frozr_add_user_location_checkout',10,1);
function frozr_add_user_location_checkout($fields) {
	$has_delivery = false;
	foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
		if ($cart_item['order_l_type'] == 'delivery') {
			$has_delivery = true;
			break;
		}
	}
	if ($has_delivery) {
	$user_location = frozr_norsani_cookies('locun') ? frozr_norsani_cookies('locun') : __('Unset','frozrdash');
	$fields['address_1']['label'] = sprintf(__('Street address. (Please enter details to your exact location. Your general delivery location is: %s)','frozrdash'), $user_location);
	}
	return $fields;
}
add_filter('woocommerce_order_formatted_billing_address','frozr_add_user_geo_to_orders',10,2);
function frozr_add_user_geo_to_orders($address,$order) {
	$user_location = get_post_meta($order->get_id(),'_user_del_location',true) ? get_post_meta($order->get_id(),'_user_del_location',true) : false;
	$address_det = !empty($address['address_2']) ? $address['address_2'] .', ' : '';
	if ($user_location) {
		$address['address_2'] = $address_det.$user_location;
	}
	return $address;
}
add_action('woocommerce_email_customer_details','frozr_email_add_order_direction_link',90,4);
function frozr_email_add_order_direction_link($order, $sent_to_admin, $plain_text, $email) {
	$vendor_id = get_post_field('post_author',$order->get_id());
	$user_location = get_post_meta($order->get_id(),'_user_geo_location',true) ? get_post_meta($order->get_id(),'_user_geo_location',true) : false;
	$rest_geo_address = get_user_meta($vendor_id, 'rest_address_geo', true) ? '&origin='.get_user_meta($vendor_id, 'rest_address_geo', true) : '';

	if ($user_location) {
		echo '<a href="https://www.google.com/maps/dir/?api=1'.$rest_geo_address.'&destination='.$user_location.'" class="frozr_order_directions"><i class="material-icons">place</i> '.__('Get Directions','frozrdash').'</a>';
	}
}
add_action('frozr_order_after_customer_address','frozr_add_order_direction_link',10,1);
function frozr_add_order_direction_link($order) {
	$vendor_id = get_post_field('post_author',$order->get_id());
	$user_location = get_post_meta($order->get_id(),'_user_geo_location',true) ? get_post_meta($order->get_id(),'_user_geo_location',true) : false;
	$rest_geo_address = get_user_meta($vendor_id, 'rest_address_geo', true) ? '&origin='.get_user_meta($vendor_id, 'rest_address_geo', true) : '';

	if ($user_location) {
		echo '<a href="https://www.google.com/maps/dir/?api=1'.$rest_geo_address.'&destination='.$user_location.'" class="frozr_order_directions"><i class="material-icons">place</i> '.__('Get Directions','frozrdash').'</a>';
	}
}
/**
 * General search get add to cart
 */
add_action( 'wp_ajax_frozr_ly_gen_src_atc', 'frozr_ly_gen_src_atc' );
add_action( 'wp_ajax_nopriv_frozr_ly_gen_src_atc', 'frozr_ly_gen_src_atc' );
function frozr_ly_gen_src_atc() {
	check_ajax_referer( 'frozr_general_src_sec', 'security' );
	$product_id = intval ($_POST['itemid']);
	
	if ($product_id > 0) {
		$product_obj = wc_get_product($product_id);
		wp_send_json(woocommerce_template_loop_add_to_cart($product_obj));
	}
}
/**
 * Ajax post comment
 */
add_action( 'wp_ajax_nopriv_frozr_post_comment', 'frozr_post_comment' );
add_action( 'wp_ajax_frozr_post_comment', 'frozr_post_comment' );
function frozr_post_comment() {
	check_ajax_referer( 'frozr_post_ajax_comment', 'security' );
	$post_id = isset($_POST['comment_post_ID']) ? intval($_POST['comment_post_ID']) : false;
	$product = wc_get_product($post_id);
	$error = false;
	$message = __('Comment Posted Successfully','frozrdash');
	
	if ('no' === get_option( 'woocommerce_enable_review_rating' ) || $post_id && !comments_open($post_id)) {
		wp_send_json(array('message' => __('Something went wrong','frozrdash'),'error' => true,));
		die();
	}
	if (get_option( 'woocommerce_review_rating_verification_required' ) !== 'no' && !wc_customer_bought_product( '', get_current_user_id(), $product->get_id() )) {
		wp_send_json(array('message' => __('Only logged in customers who have purchased this product may leave a review.','frozrdash'),'error' => true,));
		die();
	}
	
	$comment = wp_handle_comment_submission( wp_unslash( $_POST ) );
	
	if ( is_wp_error( $comment ) ) {
		$data = intval( $comment->get_error_data() );
		if ( ! empty( $data ) ) {
			$message = $comment->get_error_message();
			wp_send_json( array('message' => $message,'error' => true,));
		} else {
			wp_send_json( array('message' => __('Something went wrong','frozrdash'),'error' => true,));
		}
		die();
	}

	$user = wp_get_current_user();
	$cookies_consent = ( isset( $_POST['wp-comment-cookies-consent'] ) );

	do_action( 'set_comment_cookies', $comment, $user, $cookies_consent );
	
	$verified = wc_review_is_from_verified_owner( $comment->comment_ID );
	
	if ('0' === $comment->comment_approved) {
		if (isset($_POST['rating'])) {
		$message = __('Your review is awaiting approval','frozrdash');
		} else {
		$message = __('Your comment is awaiting approval','frozrdash');
		}
		wp_send_json( array('message' => $message,'error' => $error,));
		die();
	}
	wp_send_json( array('message' => $message,'error' => $error));
	
	die();
}
/**
 * Read the vendor registration form
 */
add_action( 'wp_ajax_nopriv_frozr_read_reg_form', 'frozr_read_reg_form' );
function frozr_read_reg_form() {
	check_ajax_referer( 'frozr_reg_form', 'security' );
	
	$username	= 'no' == get_option( 'woocommerce_registration_generate_username' ) ? $_POST['frozr_reg_email'] : '';
	$password	= 'no' == get_option( 'woocommerce_registration_generate_password' ) ? $_POST['frozr_reg_password'] : '';
	$email		= $_POST['frozr_reg_email'];
	$redirect	= false;
	$fle_gen_option		= get_option( 'frozr_gen_settings' );
	$new_seller_status	= (! empty( $fle_gen_option['frozr_new_seller_status']) ) ? $fle_gen_option['frozr_new_seller_status'] : false;
	
	try {
		$validation_error = new WP_Error();
		$validation_error = apply_filters( 'woocommerce_process_registration_errors', $validation_error, $username, $password, $email );

		if ( $validation_error->get_error_code() ) {
			throw new Exception( $validation_error->get_error_message() );
		}
		if ( empty($_POST['frozr_vendor_shopname_name']) ) {
			throw new Exception( __('Please enter a valid shop name','frozrdash') );
		}

		$new_vendor = wc_create_new_customer( sanitize_email( $email ), wc_clean( $username ), $password );

		if ( is_wp_error( $new_vendor ) ) {
			throw new Exception( $new_vendor->get_error_message() );
		}

		if ( apply_filters( 'woocommerce_registration_auth_new_customer', true, $new_vendor ) ) {
			wc_set_customer_auth_cookie( $new_vendor );
		}
		
		if ($new_seller_status) {
			$redirect = home_url('/dashboard/home/?tour=yes');
		}
		
		if (!frozr_manual_vendor_online()) {
		$openclosetime = array(
			'Sat' => array('restop'=> wc_clean($_POST['frozr_reg_rest_sat_open']), 'restshifts' => wc_clean($_POST['frozr_reg_rest_sat_shifts']), 'open_one' => wc_clean($_POST['rest_sat_opening_one']), 'close_one' => wc_clean($_POST['frozr_reg_rest_sat_closing_one']), 'open_two' => wc_clean($_POST['frozr_reg_rest_sat_opening_two']), 'close_two' => wc_clean($_POST['frozr_reg_rest_sat_closing_two'])),
			'Sun' => array('restop'=> wc_clean($_POST['frozr_reg_rest_sun_open']), 'restshifts' => wc_clean($_POST['frozr_reg_rest_sun_shifts']), 'open_one' => wc_clean($_POST['rest_sun_opening_one']), 'close_one' => wc_clean($_POST['frozr_reg_rest_sun_closing_one']), 'open_two' => wc_clean($_POST['frozr_reg_rest_sun_opening_two']), 'close_two' => wc_clean($_POST['frozr_reg_rest_sun_closing_two'])),
			'Mon' => array('restop'=> wc_clean($_POST['frozr_reg_rest_mon_open']), 'restshifts' => wc_clean($_POST['frozr_reg_rest_mon_shifts']), 'open_one' => wc_clean($_POST['rest_mon_opening_one']), 'close_one' => wc_clean($_POST['frozr_reg_rest_mon_closing_one']), 'open_two' => wc_clean($_POST['frozr_reg_rest_mon_opening_two']), 'close_two' => wc_clean($_POST['frozr_reg_rest_mon_closing_two'])),
			'Tue' => array('restop'=> wc_clean($_POST['frozr_reg_rest_tue_open']), 'restshifts' => wc_clean($_POST['frozr_reg_rest_tue_shifts']), 'open_one' => wc_clean($_POST['rest_tue_opening_one']), 'close_one' => wc_clean($_POST['frozr_reg_rest_tue_closing_one']), 'open_two' => wc_clean($_POST['frozr_reg_rest_tue_opening_two']), 'close_two' => wc_clean($_POST['frozr_reg_rest_tue_closing_two'])),
			'Wed' => array('restop'=> wc_clean($_POST['frozr_reg_rest_wed_open']), 'restshifts' => wc_clean($_POST['frozr_reg_rest_wed_shifts']), 'open_one' => wc_clean($_POST['rest_wed_opening_one']), 'close_one' => wc_clean($_POST['frozr_reg_rest_wed_closing_one']), 'open_two' => wc_clean($_POST['frozr_reg_rest_wed_opening_two']), 'close_two' => wc_clean($_POST['frozr_reg_rest_wed_closing_two'])),
			'Thu' => array('restop'=> wc_clean($_POST['frozr_reg_rest_thu_open']), 'restshifts' => wc_clean($_POST['frozr_reg_rest_thu_shifts']), 'open_one' => wc_clean($_POST['rest_thu_opening_one']), 'close_one' => wc_clean($_POST['frozr_reg_rest_thu_closing_one']), 'open_two' => wc_clean($_POST['frozr_reg_rest_thu_opening_two']), 'close_two' => wc_clean($_POST['frozr_reg_rest_thu_closing_two'])),
			'Fri' => array('restop'=> wc_clean($_POST['frozr_reg_rest_fri_open']), 'restshifts' => wc_clean($_POST['frozr_reg_rest_fri_shifts']), 'open_one' => wc_clean($_POST['rest_fri_opening_one']), 'close_one' => wc_clean($_POST['frozr_reg_rest_fri_closing_one']), 'open_two' => wc_clean($_POST['frozr_reg_rest_fri_opening_two']), 'close_two' => wc_clean($_POST['frozr_reg_rest_fri_closing_two'])),
		);
		update_user_meta( $new_vendor, 'rest_open_close_time', $openclosetime );
		}
		$accepted_closed_orders = $_POST['frozr_reg_accept_order_types_cl'] == '' ? array() : array_map( 'wc_clean', $_POST['frozr_reg_accept_order_types_cl']);
		$frozr_settings = array(
			'store_name' => sanitize_text_field($_POST['frozr_vendor_shopname_name']),
			'payment' => array(),
			'phone' => esc_attr($_POST['frozr_reg_phone']),
			'accpet_order_type' => ($_POST['frozr_reg_accept_order_types'][0] != '') ? array_map( 'wc_clean', $_POST['frozr_reg_accept_order_types']) : array('pickup'),
			'shipping_fee' => floatval($_POST['frozr_reg_shipping_fee']),
			'deliveryby' => esc_attr($_POST['frozr_reg_deliveryby']),
			'shipping_pro_adtl_cost' => floatval($_POST['frozr_reg_shipping_pro_adtl_cost']),
			'min_order_amt' => floatval($_POST['frozr_reg_min_order_amt']),
		);
		if (!frozr_manual_vendor_online()) {
			$frozr_settings['accpet_order_type_cl'] = $accepted_closed_orders;
			$frozr_settings['allow_ofline_orders'] = !empty($accepted_closed_orders) ? 'yes' : 'no';
		}
		if ( isset( $_POST['settings']['bank'] ) ) {
			$bank = $_POST['settings']['bank'];

			$frozr_settings['payment']['bank'] = apply_filters('frozr_save_bank_payment_settings', array(
				'ac_name' => sanitize_text_field( $bank['ac_name'] ),
				'ac_number' => sanitize_text_field( $bank['ac_number'] ),
				'bank_name' => sanitize_text_field( $bank['bank_name'] ),
				'bank_addr' => sanitize_text_field( $bank['bank_addr'] ),
				'swift' => sanitize_text_field( $bank['swift'] ),
			));
		}

		if ( isset( $_POST['settings']['paypal'] ) ) {
		$frozr_settings['payment']['paypal'] = apply_filters('frozr_save_paypal_payment_settings', array(
			'email' => sanitize_email( $_POST['settings']['paypal']['email'] )
		));
		}

		if ( isset( $_POST['settings']['skrill'] ) ) {
		$frozr_settings['payment']['skrill'] = apply_filters('frozr_save_skrill_payment_settings', array(
			'email' => sanitize_email( $_POST['settings']['skrill']['email'] )
		));
		}
		
		$food_types = is_array($_POST['frozr_reg_rest_food_type']) ? array_map( 'wc_clean', $_POST['frozr_reg_rest_food_type']) : array();
		
		update_user_meta($new_vendor, 'frozr_profile_settings', $frozr_settings );
		update_user_meta($new_vendor, '_rest_meal_types', array_map( 'wc_clean', $_POST['frozr_reg_rest_meal_types']) );
		update_user_meta($new_vendor, '_rest_unavds', array_map( 'wc_clean', $_POST['frozr_reg_rest_unads']) );
		/* update_user_meta($new_vendor, 'frozr_food_type', $food_types ); */
		update_user_meta($new_vendor, 'frozr_vendor_type', esc_attr($_POST['frozr_vendor_type']));

		/*Save vendor addresses*/
		wp_set_object_terms( $new_vendor, wc_clean($_POST['frozr_reg_address']), 'vendor_addresses' );
		$rest_add_geo = !empty($_POST['addressgeo']) ? wc_clean($_POST['addressgeo']) : '';
		update_user_meta( $new_vendor, 'rest_address_geo', $rest_add_geo);

		/*Save vendor tags*/
		$rtvals = explode('-', $_POST['frozr_reg_rest_tags']);
		foreach($rtvals as $key => $val) {
			$rtvals[$key] = trim($val);
		}
		$rt_vals = array_diff($rtvals, array(""));
		$restype = array_map( 'strval', $rt_vals );

		wp_set_object_terms( $new_vendor, $restype, 'vendorclass' );

		/*Save delivery locations*/
		$delunfilterd = array();
		$delivery_locs = !empty($_POST['delivery_locs']) ? explode('/',$_POST['delivery_locs']) : array();
		$delivery_locs_filtered = !empty($_POST['delivery_locs_filtered']) ? explode('/',$_POST['delivery_locs_filtered']) : array();
		update_user_meta($new_vendor, 'delivery_location', $delivery_locs);
		
		if (!empty($delivery_locs_filtered)) {
			foreach ($delivery_locs_filtered as $vals) {
				$delunfilterd[] = explode(',', $vals);
			}
		}
		update_user_meta($new_vendor, 'delivery_location_filtered', $delunfilterd);
		
		$vendor = get_user_by('id', $new_vendor);
		$msg_args = apply_filters('frozr_vendor_register_msg',array (
			'id' => $new_vendor,
			'uemail' => sanitize_email($vendor->user_email),
			'fname' => sanitize_text_field($vendor->first_name),
			'lname' => sanitize_text_field($vendor->last_name),
			'shopname' => sanitize_text_field($_POST['frozr_vendor_shopname_name']),
			'shopurl' => frozr_get_store_url($new_vendor),
			'shopphone' => esc_attr($_POST['frozr_reg_phone']),
		));
		if ($new_seller_status) {
			update_user_meta( $new_vendor, 'frozr_enable_selling', 'yes' );
			$msg_args['type'] = 'new_seller_auto';
			do_action('frozr_send_admin_auto_new_vendor_message', $msg_args);
			$msg_args['to'] = sanitize_email($vendor->user_email);
			$msg_args['type'] = 'to_new_seller_auto';
			do_action('frozr_send_vendor_auto_active_message', $msg_args);
		} else {
			update_user_meta( $new_vendor, 'frozr_enable_selling', 'no' );
			$msg_args['type'] = 'new_seller';
			do_action('frozr_send_admin_new_vendor_message', $msg_args);
			$msg_args['to'] = sanitize_email($vendor->user_email);
			$msg_args['type'] = 'to_new_seller';
			do_action('frozr_send_vendor_registration_message', $msg_args);
		}
		
		wp_send_json( array(
			'redirect' => $redirect,
			'userid' => $new_vendor,
		));
		
		die();

	} catch ( Exception $e ) {
		wp_send_json_error( '<strong>' . __( 'Error:', 'frozrdash' ) . '</strong> ' . $e->getMessage() );
		die(-1);
	}
}
/**
 * Vendor registration form check email
 */
add_action( 'wp_ajax_nopriv_frozr_reg_check_field', 'frozr_reg_check_field' );
function frozr_reg_check_field() {
	check_ajax_referer( 'frozr_reg_form', 'security' );
	
	$input = $_POST['inputval'];
	$type = $_POST['type'];
	$message = __('Available','frozrdash');
	$success = true;
	
	if ($type == 'email') {
	// Check the email address.
	if ( empty( $input ) || ! is_email( $input ) ) {
		$message =__( 'Please provide a valid email address.', 'frozrdash' );
		$success = false;
	}

	if ( email_exists( $input ) ) {
		$message = __( 'Email address exists.', 'frozrdash' ). ' <a href="'.get_permalink( get_option('woocommerce_myaccount_page_id') ).'" class="frozr_login_page_link">'.__('Please login.','frozrdash').'</a>';
		$success = false;
	}
	} else if ($type == 'storename') {
		$store_name = sanitize_title(wp_unslash($input));
		$user = get_user_by( 'slug', $store_name );

		if ($user) {
		$message = __( 'Shop name is not available, please type a different name', 'frozrdash' );
		$success = false;
		}
	}
	
	wp_send_json( array(
		'message' => $message,
		'success' => $success,
	));
	
	die();
}
/**
 * Norsani general user favorites function via ajax
 */
add_action( 'wp_ajax_frozr_ly_gen_fav', 'frozr_ly_gen_fav' );
add_action( 'wp_ajax_nopriv_frozr_ly_gen_fav', 'frozr_ly_gen_fav' );
function frozr_ly_gen_fav() {
	check_ajax_referer( 'frozr_general_fav_sec', 'security' );
	
	/*Results*/
	$products_data = array();
	$items_ids = is_array($_POST['items']) ? array_map('intval', $_POST['items']) : 0;
	
	if ($items_ids != 0) {
	
	/*Get Products*/
	$products_args = array(
		'posts_per_page'	=> -1,
		'offset'			=> 0,
		'include'			=> $items_ids,
		'post_type'			=> 'product',
		'post_status'		=> array('publish','offline'),
	);
	
	$products_array = get_posts( $products_args );
	foreach ( $products_array as $product ) {
		$product_obj = wc_get_product($product->ID);
		$profile_info = frozr_get_store_info($product->post_author);
		/*item cats*/
		$discts = get_terms( 'product_cat', 'fields=names&hide_empty=0' );
		$itemcats = wp_get_post_terms( $product->ID, 'product_cat', array("fields" => "names") );
		$itemcats_slug = array();
		if (is_array($itemcats)) {
			foreach ( $itemcats as $itemcat ) {
				$itemcats_slug[] = $itemcat;
			}
			$item_cats = join( ' ', $itemcats_slug );
		} elseif ( ! empty( $discts ) && ! is_wp_error( $discts )) {
			$item_cats = $itemcats;
		}
		/*item ingredents*/
		$ings = get_terms( 'ingredient', 'fields=names&hide_empty=0' );
		$ingredients = wp_get_post_terms( $product->ID, 'ingredient', array("fields" => "names") );
		$ingredients_slug = array();
		if (is_array($ingredients)) {
			foreach ( $ingredients as $ingredient ) {
				$ingredients_slug[] = $ingredient;
			}
			$ingreds = join( ' ', $ingredients_slug );
		} elseif ( ! empty( $ings ) && ! is_wp_error( $ings )) {
			$ingreds = $ingredients;
		}
		/*menu type*/
		$item_menu = ( null != (get_post_meta( $product->ID, 'product_meal_type', true )) ) ? get_post_meta( $product->ID, 'product_meal_type', true ) : array();
		
		$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($product->ID), 'full');
		
		$unavailable_item = '';
		if ($product->post_status == 'offline') {
			$unavailable_item = '<span class="frozr_product_unavailable">'.__('This product is currently unavailable.','frozrdash').'</span>';
		}
		
		$products_data[] = array(
			'id' => $product->ID,
			'link' => get_permalink($product->ID),
			'author' => $profile_info['store_name'],
			'title' => esc_attr( $product->post_title ),
			'itemstatus' => $unavailable_item,
			'excerpt' => isset( $product->post_excerpt ) ? $product->post_excerpt : '',
			'cats' => $item_cats,
			'ingredients' => $ingreds,
			'item_promotions' => ( null != (get_post_meta( $product->ID, 'item_promotions', true )) ) ? get_post_meta( $product->ID, 'item_promotions', true ) : array(),
			'menu_type' => ( null != (get_post_meta( $product->ID, 'product_meal_type', true )) ) ? get_post_meta( $product->ID, 'product_meal_type', true ) : array(),
			'image' => $large_image_url[0],
			'price' => $product_obj->get_price_html(),
			'rating_html' => frozr_rest_get_item_rating($product),
		);		
	}

	wp_send_json( array(
		'items' => $products_data,
	));
	
	}
	
	die();
}
/**
 * Norsani general search function via ajax
 */

add_action( 'wp_ajax_frozr_ly_gen_src', 'frozr_ly_gen_src' );
add_action( 'wp_ajax_nopriv_frozr_ly_gen_src', 'frozr_ly_gen_src' );
function frozr_ly_gen_src() {
	check_ajax_referer( 'frozr_general_src_sec', 'security' );
	
	$key_word = sanitize_text_field($_POST['keyword']) != '' ? sanitize_text_field($_POST['keyword']): 0;
	
	if(0 < strlen($key_word) && strlen($key_word) < 20) {
		/*Results*/
		$items_result = array();
		$vendors_result = array();
		
		/*Get Vendors*/
		$vendors_data = array();
		$vendors_args = array(
		'role' => 'seller',
		'orderby' => 'registered',
		'order' => 'ASC',
		'meta_query' => array(
			array(
				'key' => 'frozr_enable_selling',
				'value' => 'yes',
				'compare' => '='
			)
		));

		$user_query = new WP_User_Query( $vendors_args );
		$get_sellers = $user_query->get_results();
		foreach($get_sellers as $seller) {
			$profile_info = frozr_get_store_info($seller->ID);
			/*Vendor Cusine*/
			$restypes = wp_get_object_terms( $seller->ID, 'vendorclass', array("fields" => "names") );
			$restype_slug = array();
			if (is_array($restypes)) {
			foreach ( $restypes as $restype ) {
				$restype_slug[] = $restype;
			}
				$grestypes = join( ' ', $restype_slug );
			} else {
				$grestypes = '';
			}
			
			/*Vendor Meals*/
			$meal_types = get_user_meta($seller->ID, '_rest_meal_types', true) ? get_user_meta($seller->ID, '_rest_meal_types', true) : array();

			$rest_name = stripos($profile_info['store_name'],$key_word);
			$rest_cusine = stripos($grestypes,$key_word);
						
			if($rest_name !== false) {
				$vendors_result['name'][$rest_name][] = $seller->ID;
			} elseif ($rest_cusine !== false) {
				$vendors_result['cuisine'][$rest_cusine][] = $seller->ID;
			}
		}
		
		/*Get Products*/
		$products_args = array(
			'posts_per_page'	=> -1,
			'offset'			=> 0,
			'post_type'			=> 'product',
			'post_status'		=> array('publish','offline'),
		);
		
		$products_array = get_posts( $products_args );
		foreach ( $products_array as $product ) {
			$products_data = array();
			$product_obj = wc_get_product($product->ID);
			$profile_info = frozr_get_store_info($product->post_author);
			/*item cats*/
			$discts = get_terms( 'product_cat', 'fields=names&hide_empty=0' );
			$itemcats = wp_get_post_terms( $product->ID, 'product_cat', array("fields" => "names") );
			$itemcats_slug = array();
			if (is_array($itemcats)) {
				foreach ( $itemcats as $itemcat ) {
					$itemcats_slug[] = $itemcat;
				}
				$item_cats = join( ' ', $itemcats_slug );
			} elseif ( ! empty( $discts ) && ! is_wp_error( $discts )) {
				$item_cats = $itemcats;
			}
			/*item ingredents*/
			$ings = get_terms( 'ingredient', 'fields=names&hide_empty=0' );
			$ingredients = wp_get_post_terms( $product->ID, 'ingredient', array("fields" => "names") );
			$ingredients_slug = array();
			if (is_array($ingredients)) {
				foreach ( $ingredients as $ingredient ) {
					$ingredients_slug[] = $ingredient;
				}
				$ingreds = join( ' ', $ingredients_slug );
			} elseif ( ! empty( $ings ) && ! is_wp_error( $ings )) {
				$ingreds = $ingredients;
			}
			/*menu type*/
			$item_menu = ( null != (get_post_meta( $product->ID, 'product_meal_type', true )) ) ? get_post_meta( $product->ID, 'product_meal_type', true ) : array();
			
			$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($product->ID), 'full');
			
			$unavailable_item = '';
			if ($product->post_status == 'offline') {
				$unavailable_item = '<span class="frozr_product_unavailable">'.__('This product is currently unavailable.','frozrdash').'</span>';
			}

			$products_data = array(
				'id' => $product->ID,
				'link' => get_permalink($product->ID),
				'author' => $profile_info['store_name'],
				'itemstatus' => $unavailable_item,
				'author_link' => frozr_get_store_url($product->post_author),
				'title' => esc_attr( $product->post_title ),
				'excerpt' => isset( $product->post_excerpt ) ? $product->post_excerpt : '',
				'cats' => $item_cats,
				'ingredients' => $ingreds,
				'item_promotions' => ( null != (get_post_meta( $product->ID, 'item_promotions', true )) ) ? get_post_meta( $product->ID, 'item_promotions', true ) : array(),
				'menu_type' => ( null != (get_post_meta( $product->ID, 'product_meal_type', true )) ) ? get_post_meta( $product->ID, 'product_meal_type', true ) : array(),
				'image' => $large_image_url[0],
				'price' => $product_obj->get_price_html(),
				'rating_html' => frozr_rest_get_item_rating($product),
			);			
			
			$item_title = stripos(esc_attr( $product->post_title ),$key_word);
			$item_cats = stripos($item_cats,$key_word);
			$item_excerpt = stripos($product->post_excerpt,$key_word);
			$item_content = stripos($product->post_content,$key_word);
			$item_men = stripos(join( ' ', $item_menu ),$key_word);
			$item_ing = stripos($ingreds,$key_word);
			$item_price = stripos($product_obj->get_price_html(),$key_word);
			
			if($item_title !== false) {
				$items_result['title'][$item_title][] = $products_data;
			} elseif ($item_cats !== false) {
				$items_result['cats'][$item_cats][] = $products_data;
			} elseif ($item_excerpt !== false) {
				$items_result['excerpt'][$item_excerpt][] = $products_data;
			} elseif ($item_content !== false) {
				$items_result['content'][$item_content][] = $products_data;
			} elseif ($item_men !== false) {
				$items_result['menu'][$item_men][] = $products_data;
			} elseif ($item_ing !== false) {
				$items_result['ings'][$item_ing][] = $products_data;
			} elseif ($item_price !== false) {
				$items_result['price'][$item_price][] = $products_data;
			}			
		}

		wp_send_json( array(
			'items' => $items_result,
			'vendors' => $vendors_result,
		));

	} else {
		die(-1);
	}
}

/*Add totals to mini cart*/
function frozr_display_minicart_totals() {
	woocommerce_cart_totals();
}
add_action('woocommerce_widget_shopping_cart_before_buttons','frozr_display_minicart_totals');

/*Check theme layout options*/
function frozr_theme_is_one_column() {
$theme_opt = get_theme_mod('page_layout');

if ($theme_opt == 'one-column') {
	return true;
}

return false;
}

/*Get preload page text*/
function frozr_get_preload_text() {
return get_theme_mod('frozr_preload_text',get_bloginfo( 'name' ));
}

/*do some more when installing demo data*/
function frozr_extend_demo_data() {
	
	if (!is_super_admin()) {
		return false;
	}
	
	/*Clear sidebar*/
	update_option('sidebars_widgets', array());
	
	/*install front page*/
	$front_page = get_option('template-home');
	if (!norsani()->admin->frozr_check_page('template-home.php')) {
		$args = array(
			'post_title' => __('Welcome','frozrdash'),
			'post_content' => '<h1>'.__('Welcome to Norsani. Click edit page on the admin bar to edit this content ;)','frozrdash').'</h1>',
			'post_status' => "publish",
			'post_type' => 'page',
			'comment_status' => 'closed',
			'ping_status' => 'closed',
		);
		$front_page = wp_insert_post($args,true);
		if (!is_wp_error($front_page)) {
			update_post_meta( $front_page, '_wp_page_template', 'template-home.php');
		}
	}
	
	$blog_page = get_page_by_title('Blog');

	if (!$blog_page) {
		$args = array(
			'post_title' => __('Blog','frozrdash'),
			'post_content' => __('WordPress posts blog page.','frozrdash'),
			'post_status' => "publish",
			'post_type' => 'page',
			'comment_status' => 'closed',
			'ping_status' => 'closed',
		);
		$blog_page = wp_insert_post($args,true);
	}
	
	/*update WordPress reading settings*/
	if (!is_wp_error($front_page) && !is_wp_error($blog_page)) {
	update_option('show_on_front','page');
	update_option('page_on_front',$front_page);
	update_option('page_for_posts',$blog_page);
	}

}
add_action('frozr_before_demo_data_complete','frozr_extend_demo_data');

/**
 * Implement the Custom Header feature.
 *
 * @since FrozrDash 1.0
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 *
 * @since FrozrDash 1.0
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 *
 * @since FrozrDash 1.0
 */
require get_template_directory() . '/inc/customizer.php';/**

 * frozr custom_post loops
 *
 * @since FrozrDash 1.0
 */
require get_template_directory() . '/inc/custom_loops.php';