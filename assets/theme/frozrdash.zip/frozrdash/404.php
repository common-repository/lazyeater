<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Norsani
 * @subpackage Themes
 * @since FrozrDash 1.0
 */

get_header(); ?>

<div data-role="page" id="not_found" class="content-area">
	<?php frozr_fixed_cart(true); ?>
	<?php frozr_general_search_result(); ?>
	<?php frozr_user_favs(); ?>
	<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo __('Nothing found!', 'frozrdash'); ?></div>
	<main class="site-main" role="main">

		<section class="error-404 not-found">
			<header class="page-header">
				<h1 class="page-title"><?php _e( 'Oops! That page can&rsquo;t be found.', 'frozrdash' ); ?></h1>
			</header><!-- .page-header -->

			<div class="page-content">
				<p><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'frozrdash' ); ?></p>

				<?php get_search_form(); ?>
			</div><!-- .page-content -->
		</section><!-- .error-404 -->

	</main><!-- .site-main -->
</div><!-- .content-area -->
<?php get_footer();