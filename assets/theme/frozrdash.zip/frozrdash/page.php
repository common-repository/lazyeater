<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package Norsani
 * @subpackage Themes
 * @since FrozrDash 1.0
 */

get_header(); ?>

<div data-role="page" id="page<?php echo mt_rand(); ?>" class="content-area">
	<div <?php body_class(); ?> data-id="finde" style="display:none"><?php echo get_the_title($post->ID); ?></div>
	<?php frozr_fixed_cart(true); ?>
	<?php frozr_general_search_result(); ?>
	<?php frozr_user_favs(); ?>
	<main class="site-main" role="main">
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();

		// Include the page content template.
		get_template_part( 'content', 'page' );

		// If comments are open or we have at least one comment, load up the comment template.
		if ( comments_open() || get_comments_number() ) :
			comments_template();
		endif;

	// End the loop.
	endwhile;
	?>

	</main><!-- .site-main -->
</div><!-- .content-area -->
<?php get_footer();