<?php
function frozrdash_child_setup() {
	load_child_theme_textdomain( 'frozrdash', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'frozrdash_child_setup' );

function frozr_dash_child_theme_enqueue_styles() {

	$parent_style = 'frozrdash-style';

	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'frozrdash-child-theme-style',
		get_stylesheet_directory_uri() . '/style.css',
		array( $parent_style ),
		wp_get_theme()->get('Version')
	);
}
add_action( 'wp_enqueue_scripts', 'frozr_dash_child_theme_enqueue_styles' );